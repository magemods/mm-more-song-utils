#ifndef FAULT_DRAWER_H
#define FAULT_DRAWER_H 1

extern u8 sFaultDrawerFont[];
#endif
