#ifndef GFXPRINT_H
#define GFXPRINT_H 1

extern u64 sGfxPrintFontTLUT[];
extern u64 sGfxPrintRainbowTLUT[];
extern u8 sGfxPrintRainbowFont[];
extern u8 sGfxPrintFont[];
#endif
