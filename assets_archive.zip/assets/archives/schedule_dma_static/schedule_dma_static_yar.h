#ifndef SCHEDULE_DMA_STATIC_YAR_H
#define SCHEDULE_DMA_STATIC_YAR_H 1

extern u64 gBombersNotebookPhotoAnjuTex[];
extern u64 gBombersNotebookPhotoKafeiTex[];
extern u64 gBombersNotebookPhotoCuriosityShopManTex[];
extern u64 gBombersNotebookPhotoBombShopLadyTex[];
extern u64 gBombersNotebookPhotoRomaniTex[];
extern u64 gBombersNotebookPhotoCremiaTex[];
extern u64 gBombersNotebookPhotoMayorDotourTex[];
extern u64 gBombersNotebookPhotoMadameAromaTex[];
extern u64 gBombersNotebookPhotoTotoTex[];
extern u64 gBombersNotebookPhotoGormanTex[];
extern u64 gBombersNotebookPhotoPostmanTex[];
extern u64 gBombersNotebookPhotoRosaSistersTex[];
extern u64 gBombersNotebookPhotoToiletHandTex[];
extern u64 gBombersNotebookPhotoAnjusGrandmotherTex[];
extern u64 gBombersNotebookPhotoKamaroTex[];
extern u64 gBombersNotebookPhotoGrogTex[];
extern u64 gBombersNotebookPhotoGormanBrothersTex[];
extern u64 gBombersNotebookPhotoShiroTex[];
extern u64 gBombersNotebookPhotoGuruGuruTex[];
extern u64 gBombersNotebookPhotoBombersTex[];
extern u64 gBombersNotebookPhotoMadameAromaBrightTex[];
extern u64 gBombersNotebookEntryIconExclamationPointLargeTex[];
extern u64 gBombersNotebookEntryIconMaskTex[];
extern u64 gBombersNotebookEntryIconRibbonTex[];
#endif
