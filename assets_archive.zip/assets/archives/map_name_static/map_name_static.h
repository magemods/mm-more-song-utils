#ifndef MAP_NAME_STATIC_H
#define MAP_NAME_STATIC_H 1

extern u64 gMapPointGreatBayENGTex[];
extern u64 gMapPointZoraHallENGTex[];
extern u64 gMapPointRomaniRanchENGTex[];
extern u64 gMapPointDekuPalaceENGTex[];
extern u64 gMapPointWoodfallENGTex[];
extern u64 gMapPointClockTownENGTex[];
extern u64 gMapPointSnowheadENGTex[];
extern u64 gMapPointIkanaGraveyardENGTex[];
extern u64 gMapPointIkanaCanyonENGTex[];
extern u64 gMapPointGoronVillageENGTex[];
extern u64 gMapPointStoneTowerENGTex[];
extern u64 gMapPointGreatBayCoastENGTex[];
extern u64 gMapPointSouthernSwampENGTex[];
extern u64 gMapPointMountainVillageENGTex[];
extern u64 gMapPointMilkRoadENGTex[];
extern u64 gMapPointZoraCapeENGTex[];
#endif
