#ifndef ICON_ITEM_24_STATIC_YAR_H
#define ICON_ITEM_24_STATIC_YAR_H 1

extern u64 gQuestIconGoldSkulltulaTex[];
extern u64 gQuestIconHeartContainerTex[];
extern u64 gQuestIconPieceOfHeartTex[];
extern u64 gQuestIconPieceOfHeart2Tex[];
extern u64 gQuestIconHeartContainer2Tex[];
extern u64 gQuestIconHeartContainer3Tex[];
extern u64 gQuestIconBossKeyTex[];
extern u64 gQuestIconCompassTex[];
extern u64 gQuestIconDungeonMapTex[];
extern u64 gQuestIconGoldSkulltula2Tex[];
extern u64 gQuestIconSmallKeyTex[];
extern u64 gQuestIconSmallMagicJarTex[];
extern u64 gQuestIconBigMagicJarTex[];
extern u64 gQuestIconLinkHumanFaceTex[];
#endif
