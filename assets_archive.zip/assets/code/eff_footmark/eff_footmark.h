#ifndef EFF_FOOTMARK_H
#define EFF_FOOTMARK_H 1

extern Vtx gEffFootprintVtx[];
extern Gfx gEffFootprintMaterialDL[];
extern Gfx gEffFootprintModelDL[];
#endif
