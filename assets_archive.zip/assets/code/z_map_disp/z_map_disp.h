#ifndef Z_MAP_DISP_H
#define Z_MAP_DISP_H 1

extern u64 sWhiteSquareTex[];
#endif
