#ifndef CIRCLE_TEX_H
#define CIRCLE_TEX_H 1

extern u64 sCircleTex[];
#endif
