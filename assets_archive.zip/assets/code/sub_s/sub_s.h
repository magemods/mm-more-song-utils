#ifndef SUB_S_H
#define SUB_S_H 1

extern Vtx codeVtx_120260[];
extern Gfx gShadowMaterialDL[];
extern Gfx gShadowModelDL[];
#endif
