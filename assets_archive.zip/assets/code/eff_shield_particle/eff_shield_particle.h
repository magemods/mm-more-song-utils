#ifndef EFF_SHIELD_PARTICLE_H
#define EFF_SHIELD_PARTICLE_H 1

extern Vtx sEffShieldParticleVtx[];
#endif
