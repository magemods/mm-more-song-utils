#ifndef DEBUG_DISPLAY_H
#define DEBUG_DISPLAY_H 1

extern Vtx sDebugDisplay1Vtx[];
extern Gfx sDebugDisplay1DL[];
extern Vtx sDebugDisplay2Vtx[];
extern Gfx sDebugDisplay2DL[];
extern Vtx sDebugDisplay3Vtx[];
extern Gfx sDebugDisplay3DL[];
extern u64 sDebugDisplayCircleTex[];
extern u64 sDebugDisplayBallTex[];
extern u64 sDebugDisplayCursorTex[];
extern u64 sDebugDisplayCrossTex[];
extern Vtx sDebugDisplaySpriteVtx[];
extern Gfx sDebugDisplaySpriteDL[];
#endif
