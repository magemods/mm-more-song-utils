#ifndef WEEK_STATIC_H
#define WEEK_STATIC_H 1

extern u64 gClockDay1stTex[];
extern u64 gClockDay2ndTex[];
extern u64 gClockDayFinalTex[];
#endif
