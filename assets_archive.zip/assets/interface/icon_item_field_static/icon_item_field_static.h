#ifndef ICON_ITEM_FIELD_STATIC_H
#define ICON_ITEM_FIELD_STATIC_H 1

extern u64 gWorldMapImageTex[];
extern u64 gWorldMapImageTLUT[];
extern u64 gWorldMapDotTex[];
extern u64 gWorldMapAreaBox1Tex[];
extern u64 gWorldMapAreaBox2Tex[];
extern u64 gWorldMapAreaBox3Tex[];
extern u64 gWorldMapAreaBox4Tex[];
extern u64 gWorldMapAreaBox5Tex[];
extern u64 gWorldMapAreaBox6Tex[];
extern u64 gWorldMapAreaBox7Tex[];
extern u64 gWorldMapAreaBox8Tex[];
extern u64 gWorldMapArrowTex[];
extern u64 gWorldMapClockTownCloud1Tex[];
extern u64 gWorldMapClockTownCloud2Tex[];
extern u64 gWorldMapRomaniRanchCloudTex[];
extern u64 gWorldMapGreatBayCloud1Tex[];
extern u64 gWorldMapGreatBayCloud2Tex[];
extern u64 gWorldMapGreatBayCloud3Tex[];
extern u64 gWorldMapGreatBayCloud4Tex[];
extern u64 gWorldMapSnowheadCloud1Tex[];
extern u64 gWorldMapSnowheadCloud2Tex[];
extern u64 gWorldMapSnowheadCloud3Tex[];
extern u64 gWorldMapStoneTowerCloud1Tex[];
extern u64 gWorldMapStoneTowerCloud2Tex[];
extern u64 gWorldMapWoodfallCloud1Tex[];
extern u64 gWorldMapWoodfallCloud2Tex[];
extern u64 gWorldMapWoodfallCloud3Tex[];
extern u64 gWorldMapOwlFaceTex[];
#endif
