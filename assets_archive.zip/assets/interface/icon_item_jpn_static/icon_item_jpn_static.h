#ifndef ICON_ITEM_JPN_STATIC_H
#define ICON_ITEM_JPN_STATIC_H 1

extern u64 gPauseWoodfallTitleENGTex[];
extern u64 gPauseSnowheadTitleENGTex[];
extern u64 gPauseGreatBayTitleENGTex[];
extern u64 gPauseStoneTowerTitleENGTex[];
extern u64 gPauseToEquipENGTex[];
extern u64 gPauseToDecideENGTex[];
extern u64 gPauseToPlayMelodyENGTex[];
extern u64 gPauseToSelectItemENGTex[];
extern u64 gPauseToMapENGTex[];
extern u64 gPauseToQuestStatusENGTex[];
extern u64 gPauseToMasksENGTex[];
extern u64 gPauseToViewNotebookENGTex[];
extern u64 gPauseMasks10ENGTex[];
extern u64 gPauseSelectItem00ENGTex[];
extern u64 gPauseSelectItem10ENGTex[];
extern u64 gPauseSelectItem20ENGTex[];
extern u64 gPauseMap10ENGTex[];
extern u64 gPauseQuestStatus00ENGTex[];
extern u64 gPauseQuestStatus10ENGTex[];
extern u64 gPauseQuestStatus20ENGTex[];
#endif
