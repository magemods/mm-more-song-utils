#ifndef ICON_ITEM_GAMEOVER_STATIC_H
#define ICON_ITEM_GAMEOVER_STATIC_H 1

extern u64 gGameOverP1Tex[];
extern u64 gGameOverP2Tex[];
extern u64 gGameOverP3Tex[];
extern u64 gGameOverMaskTex[];
extern u64 gContinuePlayingJAPTex[];
extern u64 gContinuePlayingNESTex[];
#endif
