#ifndef ICON_ITEM_VTX_STATIC_H
#define ICON_ITEM_VTX_STATIC_H 1

extern Gfx gItemNamePanelDL[];
extern Gfx gZButtonIconDL[];
extern Gfx gRButtonIconDL[];
extern Gfx gCButtonIconsDL[];
extern Gfx gAButtonIconDL[];
extern Gfx gBButtonIconDL[];
extern Gfx gPromptCursorLeftDL[];
extern Gfx gPromptCursorRightDL[];
#endif
