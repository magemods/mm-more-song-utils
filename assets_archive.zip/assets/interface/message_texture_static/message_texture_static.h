#ifndef MESSAGE_TEXTURE_STATIC_H
#define MESSAGE_TEXTURE_STATIC_H 1

extern u64 gMessageXLeftTex[];
extern u64 gMessageXRightTex[];
#endif
