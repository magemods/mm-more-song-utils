#ifndef MESSAGE_STATIC_H
#define MESSAGE_STATIC_H 1

extern u64 gMessageDefaultBackgroundTex[];
extern u64 gMessageSignBackgroundTex[];
extern u64 gMessageNoteStaffBackgroundTex[];
extern u64 gMessageFadingBackgroundTex[];
extern u64 gMessageNotebookBackgroundTex[];
extern u64 gMessageContinueTriangleTex[];
extern u64 gMessageEndSquareTex[];
extern u64 gMessageArrowTex[];
#endif
