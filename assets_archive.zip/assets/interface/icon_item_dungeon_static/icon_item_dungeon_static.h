#ifndef ICON_ITEM_DUNGEON_STATIC_H
#define ICON_ITEM_DUNGEON_STATIC_H 1

extern u64 gDungeonMapBlankFloorButtonTex[];
extern u64 gDungeonMap1FButtonTex[];
extern u64 gDungeonMap2FButtonTex[];
extern u64 gDungeonMap3FButtonTex[];
extern u64 gDungeonMap4FButtonTex[];
extern u64 gDungeonMap5FButtonTex[];
extern u64 gDungeonMap6FButtonTex[];
extern u64 gDungeonMap7FButtonTex[];
extern u64 gDungeonMap8FButtonTex[];
extern u64 gDungeonMapB1ButtonTex[];
extern u64 gDungeonMapB2ButtonTex[];
extern u64 gDungeonMapB3ButtonTex[];
extern u64 gDungeonMapB4ButtonTex[];
extern u64 gDungeonMapB5ButtonTex[];
extern u64 gDungeonMapB6ButtonTex[];
extern u64 gDungeonMapB7ButtonTex[];
extern u64 gDungeonMapB8ButtonTex[];
extern u64 gDungeonMapSkullTex[];
extern u64 gDungeonStrayFairyWoodfallIconTex[];
extern u64 gDungeonStrayFairySnowheadIconTex[];
extern u64 gDungeonStrayFairyGreatBayIconTex[];
extern u64 gDungeonStrayFairyStoneTowerIconTex[];
#endif
