#ifndef OBJECT_YADO_OBJ_H
#define OBJECT_YADO_OBJ_H 1

extern Vtx object_yado_objVtx_000000[];
extern Gfx object_yado_obj_DL_000320[];
extern Gfx object_yado_obj_DL_000430[];
extern u64 object_yado_obj_Tex_0005D8[];
extern u64 object_yado_obj_Tex_0009D8[];
extern u64 object_yado_obj_Tex_000DD8[];
extern u64 object_yado_obj_Tex_000ED8[];
extern AnimatedMatTexScrollParams object_yado_obj_Matanimheader_0012E8TexScrollParams_0012E0[];
extern AnimatedMaterial object_yado_obj_Matanimheader_0012E8[];
#endif
