#ifndef OBJECT_WDOR02_H
#define OBJECT_WDOR02_H 1

extern Vtx object_wdor02Vtx_000000[];
extern Gfx gPostOfficeTradingPostDoorEmptyDL[];
extern Gfx gPostOfficeTradingPostDoorDL[];
extern u64 gPostOfficeTradingPostDoorTex[];
#endif
