#ifndef OBJECT_OYU_H
#define OBJECT_OYU_H 1

extern Vtx object_oyuVtx_000000[];
extern Gfx gGoronGraveyardHotSpringWaterDL[];
extern Gfx gGoronGraveyardHotSpringWaterEmptyDL[];
extern u64 gGoronGraveyardHotSpringWaterTex[];
extern AnimatedMatTexScrollParams gGoronGraveyardHotSpringWaterTexAnimTexScrollParams_000960[];
extern AnimatedMaterial gGoronGraveyardHotSpringWaterTexAnim[];
extern BgCamInfo gGoronGraveyardHotSpringWaterColCamDataList[];
extern WaterBox gGoronGraveyardHotSpringWaterColWaterBoxes[];
extern CollisionHeader gGoronGraveyardHotSpringWaterCol;
#endif
