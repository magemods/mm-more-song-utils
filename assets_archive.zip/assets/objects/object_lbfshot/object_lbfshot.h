#ifndef OBJECT_LBFSHOT_H
#define OBJECT_LBFSHOT_H 1

extern Vtx object_lbfshotVtx_000000[];
extern Gfx object_lbfshot_DL_000220[];
extern Gfx object_lbfshot_DL_000228[];
extern u64 object_lbfshot_Tex_000340[];
extern u64 object_lbfshot_Tex_000B40[];
extern BgCamInfo object_lbfshot_Colheader_0014D8CamDataList[];
extern SurfaceType object_lbfshot_Colheader_0014D8SurfaceType[];
extern CollisionPoly object_lbfshot_Colheader_0014D8Polygons[];
extern Vec3s object_lbfshot_Colheader_0014D8Vertices[];
extern CollisionHeader object_lbfshot_Colheader_0014D8;
#endif
