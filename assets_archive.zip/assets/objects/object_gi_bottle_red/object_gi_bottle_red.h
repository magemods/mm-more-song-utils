#ifndef OBJECT_GI_BOTTLE_RED_H
#define OBJECT_GI_BOTTLE_RED_H 1

extern Vtx object_gi_bottle_redVtx_000000[];
extern Gfx gGiRedPotionBottleDL[];
extern Gfx gGiRedPotionBottleEmptyDL[];
extern u64 gGiRedPotionBottleCorkTex[];
extern u64 gGiRedPotionBottleGlassPotionTex[];
#endif
