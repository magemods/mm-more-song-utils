#ifndef OBJECT_SMTOWER_H
#define OBJECT_SMTOWER_H 1

extern Vtx object_smtowerVtx_000000[];
extern Gfx object_smtower_DL_000520[];
extern u64 object_smtower_Tex_000778[];
extern u64 object_smtower_Tex_000F78[];
extern AnimatedMatTexScrollParams object_smtower_Matanimheader_001788TexScrollParams_001780[];
extern AnimatedMaterial object_smtower_Matanimheader_001788[];
#endif
