#ifndef OBJECT_LAST_OBJ_H
#define OBJECT_LAST_OBJ_H 1

extern Vtx object_last_objVtx_000000[];
extern Gfx object_last_obj_DL_000090[];
extern Gfx object_last_obj_DL_000098[];
extern Vtx object_last_objVtx_000160[];
extern Gfx object_last_obj_DL_0001A0[];
extern Gfx object_last_obj_DL_0001A8[];
extern BgCamInfo object_last_obj_Colheader_000288CamDataList[];
extern SurfaceType object_last_obj_Colheader_000288SurfaceType[];
extern CollisionPoly object_last_obj_Colheader_000288Polygons[];
extern Vec3s object_last_obj_Colheader_000288Vertices[];
extern CollisionHeader object_last_obj_Colheader_000288;
extern u64 object_last_obj_Tex_0002C0[];
extern Vtx object_last_objVtx_0012C0[];
extern Gfx object_last_obj_DL_001310[];
extern Gfx object_last_obj_DL_001318[];
extern BgCamInfo object_last_obj_Colheader_001450CamDataList[];
extern SurfaceType object_last_obj_Colheader_001450SurfaceType[];
extern CollisionPoly object_last_obj_Colheader_001450Polygons[];
extern Vec3s object_last_obj_Colheader_001450Vertices[];
extern CollisionHeader object_last_obj_Colheader_001450;
extern u64 object_last_obj_TLUT_001700[];
extern u64 object_last_obj_Tex_0018A0[];
extern u64 object_last_obj_Tex_0030A0[];
extern Vtx object_last_objVtx_0038A0[];
extern Gfx object_last_obj_DL_0039C0[];
extern u64 object_last_obj_Tex_003B20[];
#endif
