#ifndef OBJECT_MASK_ZACHO_H
#define OBJECT_MASK_ZACHO_H 1

extern Vtx object_mask_zachoVtx_000000[];
extern Gfx object_mask_zacho_DL_000700[];
extern u64 object_mask_zacho_TLUT_000BC8[];
extern u64 object_mask_zacho_Tex_000DC8[];
extern u64 object_mask_zacho_Tex_000FC8[];
extern u64 object_mask_zacho_Tex_001008[];
extern u64 object_mask_zacho_Tex_001048[];
extern u64 object_mask_zacho_Tex_001448[];
extern u64 object_mask_zacho_Tex_001548[];
extern u64 object_mask_zacho_Tex_001648[];
#endif
