#ifndef OBJECT_GI_FIELDMAP_H
#define OBJECT_GI_FIELDMAP_H 1

extern Vtx object_gi_fieldmapVtx_000000[];
extern Gfx gGiTingleMapEmptyDL[];
extern Gfx gGiTingleMapDL[];
extern u64 gGiTingleMapLeftInscriptionsTex[];
extern u64 gGiTingleMapRightInscriptionsTex[];
extern u64 gGiTingleMapScrollHandleTex[];
#endif
