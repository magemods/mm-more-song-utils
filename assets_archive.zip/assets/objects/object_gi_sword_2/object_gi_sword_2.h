#ifndef OBJECT_GI_SWORD_2_H
#define OBJECT_GI_SWORD_2_H 1

extern Vtx object_gi_sword_2Vtx_000000[];
extern Gfx gGiRazorSwordEmptyDL[];
extern Gfx gGiRazorSwordDL[];
extern u64 gGiRazorSwordHiltTex[];
extern u64 gGiRazorSwordBladeTex[];
extern u64 gGiRazorSwordSpotTex[];
#endif
