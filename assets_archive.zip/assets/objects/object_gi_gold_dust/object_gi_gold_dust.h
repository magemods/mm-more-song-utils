#ifndef OBJECT_GI_GOLD_DUST_H
#define OBJECT_GI_GOLD_DUST_H 1

extern Vtx object_gi_gold_dustVtx_000000[];
extern Gfx gGiGoldDustPowderEmptyDL[];
extern Gfx gGiGoldDustPowderDL[];
extern u64 gGiGoldDustPowderClothTex[];
extern u64 gGiGoldDustPowderContentTex[];
#endif
