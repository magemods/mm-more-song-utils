#ifndef OBJECT_GI_BOTTLE_04_H
#define OBJECT_GI_BOTTLE_04_H 1

extern Vtx object_gi_bottle_04Vtx_000000[];
extern Mtx gGiFairyBottleBillboardRotMtx;
extern Gfx gGiFairyBottleContentsDL[];
extern Gfx gGiFairyBottleGlassCorkDL[];
extern Gfx gGiFairyBottleEmptyDL[];
extern u64 gGiFairyBottleCorkTex[];
extern u64 gGiFairyBottleFairyTex[];
extern u64 gGiFairyBottleGlassTex[];
extern F3DPrimColor object_gi_bottle_04TexColorChangingPrimColors_001220[];
extern F3DEnvColor object_gi_bottle_04TexColorChangingEnvColors_001230[];
extern u16 object_gi_bottle_04TexColorChangingFrameData_00123C[];
extern AnimatedMatColorParams gGiFairyBottleTexAnimColorParams_001244;
extern AnimatedMaterial gGiFairyBottleTexAnim[];
#endif
