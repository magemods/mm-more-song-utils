#ifndef OBJECT_MASK_SKJ_H
#define OBJECT_MASK_SKJ_H 1

extern Vtx object_mask_skjVtx_000000[];
extern Gfx object_mask_skj_DL_0009F0[];
extern u64 object_mask_skj_TLUT_000FA0[];
extern u64 object_mask_skj_Tex_0011A0[];
extern u64 object_mask_skj_Tex_0012A0[];
extern u64 object_mask_skj_Tex_001320[];
extern u64 object_mask_skj_Tex_001360[];
extern u64 object_mask_skj_Tex_001460[];
extern u64 object_mask_skj_Tex_001560[];
extern u64 object_mask_skj_Tex_001660[];
#endif
