#ifndef OBJECT_TOKEI_TOBIRA_H
#define OBJECT_TOKEI_TOBIRA_H 1

extern u64 object_tokei_tobira_Tex_000000[];
extern u64 object_tokei_tobira_Tex_000800[];
extern Vtx object_tokei_tobiraVtx_001000[];
extern Gfx object_tokei_tobira_DL_001100[];
extern Gfx object_tokei_tobira_DL_001108[];
extern BgCamInfo object_tokei_tobira_Colheader_0012B0CamDataList[];
extern SurfaceType object_tokei_tobira_Colheader_0012B0SurfaceType[];
extern CollisionPoly object_tokei_tobira_Colheader_0012B0Polygons[];
extern Vec3s object_tokei_tobira_Colheader_0012B0Vertices[];
extern CollisionHeader object_tokei_tobira_Colheader_0012B0;
extern Vtx object_tokei_tobiraVtx_0012E0[];
extern Gfx object_tokei_tobira_DL_0013E0[];
extern Gfx object_tokei_tobira_DL_0013E8[];
extern BgCamInfo object_tokei_tobira_Colheader_001590CamDataList[];
extern SurfaceType object_tokei_tobira_Colheader_001590SurfaceType[];
extern CollisionPoly object_tokei_tobira_Colheader_001590Polygons[];
extern Vec3s object_tokei_tobira_Colheader_001590Vertices[];
extern CollisionHeader object_tokei_tobira_Colheader_001590;
#endif
