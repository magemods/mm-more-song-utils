#ifndef OBJECT_F52_OBJ_H
#define OBJECT_F52_OBJ_H 1

extern Vtx object_f52_objVtx_000000[];
extern Gfx object_f52_obj_DL_000570[];
extern Gfx object_f52_obj_DL_000698[];
extern Gfx object_f52_obj_DL_0007A8[];
extern Gfx object_f52_obj_DL_000840[];
extern Gfx object_f52_obj_DL_0008D0[];
extern Gfx object_f52_obj_DL_000960[];
extern u64 object_f52_obj_Tex_000A10[];
extern u64 object_f52_obj_Tex_000E10[];
extern u64 object_f52_obj_Tex_001010[];
extern u64 object_f52_obj_Tex_001410[];
extern u64 object_f52_obj_Tex_001810[];
extern BgCamInfo object_f52_obj_Colheader_001BA8CamDataList[];
extern SurfaceType object_f52_obj_Colheader_001BA8SurfaceType[];
extern CollisionPoly object_f52_obj_Colheader_001BA8Polygons[];
extern Vec3s object_f52_obj_Colheader_001BA8Vertices[];
extern CollisionHeader object_f52_obj_Colheader_001BA8;
#endif
