#ifndef OBJECT_GI_RESERVE_C_00_H
#define OBJECT_GI_RESERVE_C_00_H 1

extern Vtx object_gi_reserve_c_00Vtx_000000[];
extern Gfx gGiLetterToKafeiInscriptionsDL[];
extern Gfx gGiLetterToKafeiEnvelopeLetterDL[];
extern u64 gGiLetterToKafeiLetterBackgroundTex[];
extern u64 gGiLetterToKafeiLetterInscriptionsTex[];
extern u64 gGiLetterToKafeiEnvelopeInscriptionsTex[];
#endif
