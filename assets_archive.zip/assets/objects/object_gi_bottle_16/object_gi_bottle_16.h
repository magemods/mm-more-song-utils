#ifndef OBJECT_GI_BOTTLE_16_H
#define OBJECT_GI_BOTTLE_16_H 1

extern Vtx object_gi_bottle_16Vtx_000000[];
extern Gfx gGiSeahorseBottleGlassAndCorkDL[];
extern Gfx gGiSeahorseBottleEmptyDL[];
extern u64 gGiSeahorseBottleCorkTex[];
extern u64 gGiSeahorseBottleGlassTex[];
#endif
