#ifndef OBJECT_BOB_H
#define OBJECT_BOB_H 1

typedef enum HylianWoman2Limb {
    /* 0x00 */ HYLIAN_WOMMAN_2_LIMB_NONE,
    /* 0x01 */ HYLIAN_WOMAN_2_LIMB_PELVIS,
    /* 0x02 */ HYLIAN_WOMAN_2_LIMB_LEFT_THIGH,
    /* 0x03 */ HYLIAN_WOMAN_2_LIMB_LEFT_SHIN,
    /* 0x04 */ HYLIAN_WOMAN_2_LIMB_LEFT_FOOT,
    /* 0x05 */ HYLIAN_WOMAN_2_LIMB_RIGHT_THIGH,
    /* 0x06 */ HYLIAN_WOMAN_2_LIMB_RIGHT_SHIN,
    /* 0x07 */ HYLIAN_WOMAN_2_LIMB_RIGHT_FOOT,
    /* 0x08 */ HYLIAN_WOMAN_2_LIMB_TORSO,
    /* 0x09 */ HYLIAN_WOMAN_2_LIMB_LEFT_UPPER_ARM,
    /* 0x0A */ HYLIAN_WOMAN_2_LIMB_LEFT_FOREARM,
    /* 0x0B */ HYLIAN_WOMAN_2_LIMB_LEFT_HAND,
    /* 0x0C */ HYLIAN_WOMAN_2_LIMB_RIGHT_UPPER_ARM,
    /* 0x0D */ HYLIAN_WOMAN_2_LIMB_RIGHT_FOREARM,
    /* 0x0E */ HYLIAN_WOMAN_2_LIMB_RIGHT_HAND,
    /* 0x0F */ HYLIAN_WOMAN_2_LIMB_HEAD,
    /* 0x10 */ HYLIAN_WOMMAN_2_LIMB_MAX
} HylianWoman2Limb;

extern StandardLimb gHylianWoman2PelvisLimb;
extern StandardLimb gHylianWoman2LeftThighLimb;
extern StandardLimb gHylianWoman2LeftShinLimb;
extern StandardLimb gHylianWoman2LeftFootLimb;
extern StandardLimb gHylianWoman2RightThighLimb;
extern StandardLimb gHylianWoman2RightShinLimb;
extern StandardLimb gHylianWoman2RightFootLimb;
extern StandardLimb gHylianWoman2TorsoLimb;
extern StandardLimb gHylianWoman2LeftUpperArmLimb;
extern StandardLimb gHylianWoman2LeftForearmLimb;
extern StandardLimb gHylianWoman2LeftHandLimb;
extern StandardLimb gHylianWoman2RightUpperArmLimb;
extern StandardLimb gHylianWoman2RightForearmLimb;
extern StandardLimb gHylianWoman2RightHandLimb;
extern StandardLimb gHylianWoman2HeadLimb;
extern void* gHylianWoman2SkelLimbs[];
extern FlexSkeletonHeader gHylianWoman2Skel;
extern u64 gHylianWoman2TLUT[];
extern u64 gHylianWoman2SkinTex[];
extern u64 gHylianWoman2HairTex[];
extern u64 gHylianWoman2MouthTex[];
extern u64 gHylianWoman2EarTex[];
extern u64 gHylianWoman2EyeOpenTex[];
extern u64 gHylianWoman2EyeHalfTex[];
extern u64 gHylianWoman2EyeClosedTex[];
extern u64 gHylianWoman2FingersTex[];
extern u64 gHylianWoman2ShirtTex[];
extern u64 gHylianWoman2CollarTex[];
extern u64 gHylianWoman2DressTex[];
extern Vtx object_bobVtx_002308[];
extern Gfx gHylianWoman2HeadDL[];
extern Gfx gHylianWoman2RightHandDL[];
extern Gfx gHylianWoman2RightForearmDL[];
extern Gfx gHylianWoman2RightUpperArmDL[];
extern Gfx gHylianWoman2LeftHandDL[];
extern Gfx gHylianWoman2LeftForearmDL[];
extern Gfx gHylianWoman2LeftUpperArmDL[];
extern Gfx gHylianWoman2TorsoDL[];
extern Gfx gHylianWoman2RightFootDL[];
extern Gfx gHylianWoman2RightShinDL[];
extern Gfx gHylianWoman2RightThighDL[];
extern Gfx gHylianWoman2LeftFootDL[];
extern Gfx gHylianWoman2LeftShinDL[];
extern Gfx gHylianWoman2LeftThighDL[];
extern Gfx gHylianWoman2PelvisDL[];
#endif
