#ifndef OBJECT_DEKUCITY_ANA_OBJ_H
#define OBJECT_DEKUCITY_ANA_OBJ_H 1

extern Vtx object_dekucity_ana_objVtx_000000[];
extern Gfx object_dekucity_ana_obj_DL_000040[];
extern u64 object_dekucity_ana_obj_Tex_000100[];
extern u64 object_dekucity_ana_obj_Tex_000900[];
#endif
