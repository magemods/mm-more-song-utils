#ifndef OBJECT_BIGICICLE_H
#define OBJECT_BIGICICLE_H 1

extern u64 object_bigicicle_Tex_000000[];
extern u64 object_bigicicle_Tex_000800[];
extern Vtx object_bigicicleVtx_000880[];
extern Gfx object_bigicicle_DL_0009B0[];
extern Vtx object_bigicicleVtx_000A60[];
extern Gfx object_bigicicle_DL_000B20[];
extern Vtx object_bigicicleVtx_000BE0[];
extern Gfx object_bigicicle_DL_000D60[];
extern Vtx object_bigicicleVtx_000E40[];
extern Gfx object_bigicicle_DL_000F40[];
extern Vtx object_bigicicleVtx_001000[];
extern Gfx object_bigicicle_DL_0014F0[];
extern AnimatedMatTexScrollParams object_bigicicle_Matanimheader_001678TexScrollParams_001670[];
extern AnimatedMaterial object_bigicicle_Matanimheader_001678[];
extern Vtx object_bigicicleVtx_001680[];
extern Gfx object_bigicicle_DL_001D10[];
extern Vtx object_bigicicleVtx_001E90[];
extern Gfx object_bigicicle_DL_002530[];
extern Vtx object_bigicicleVtx_0026C0[];
extern Gfx object_bigicicle_DL_002C20[];
#endif
