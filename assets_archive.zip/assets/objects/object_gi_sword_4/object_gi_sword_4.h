#ifndef OBJECT_GI_SWORD_4_H
#define OBJECT_GI_SWORD_4_H 1

extern Vtx object_gi_sword_4Vtx_000000[];
extern Gfx gGiGreatFairysSwordHiltEmblemDL[];
extern Gfx gGiGreatFairysSwordBladeDL[];
extern u64 gGiGreatFairysSwordLeafPatternTex[];
extern u64 gGiGreatFairysSwordBladeTex[];
extern u64 gGiGreatFairysSwordEmblemBackgroundTex[];
#endif
