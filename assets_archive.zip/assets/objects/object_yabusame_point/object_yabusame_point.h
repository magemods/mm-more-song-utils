#ifndef OBJECT_YABUSAME_POINT_H
#define OBJECT_YABUSAME_POINT_H 1

extern u64 gYabusamePoint30Tex[];
extern u64 gYabusamePoint60Tex[];
extern u64 gYabusamePoint100Tex[];
extern Vtx object_yabusame_pointVtx_000D80[];
extern Gfx gYabusamePointDL[];
#endif
