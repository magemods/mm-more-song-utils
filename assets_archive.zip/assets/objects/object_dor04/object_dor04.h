#ifndef OBJECT_DOR04_H
#define OBJECT_DOR04_H 1

extern Vtx object_dor04Vtx_000000[];
extern Gfx gMagicHagPotionShopDoorEmptyDL[];
extern Gfx gMagicHagPotionShopDoorDL[];
extern u64 gMagicHagPotionShopDoorTex[];
#endif
