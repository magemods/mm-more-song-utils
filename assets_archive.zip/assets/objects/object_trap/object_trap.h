#ifndef OBJECT_TRAP_H
#define OBJECT_TRAP_H 1

extern u64 object_trap_Tex_000000[];
extern u64 object_trap_Tex_000400[];
extern u64 object_trap_Tex_000800[];
extern Vtx object_trapVtx_000C00[];
extern Gfx object_trap_DL_001400[];
extern Gfx object_trap_DL_001630[];
extern Vtx object_trapVtx_0016C8[];
extern Gfx object_trap_DL_001710[];
extern Vtx object_trapVtx_001878[];
extern u64 object_trap_Tex_001BD8[];
#endif
