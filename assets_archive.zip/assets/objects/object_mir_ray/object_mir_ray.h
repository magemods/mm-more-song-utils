#ifndef OBJECT_MIR_RAY_H
#define OBJECT_MIR_RAY_H 1

extern Vtx object_mir_rayVtx_000000[];
extern Gfx object_mir_ray_DL_000160[];
extern Gfx object_mir_ray_DL_000168[];
extern u64 object_mir_ray_Tex_000270[];
extern u64 object_mir_ray_Tex_0002F0[];
extern AnimatedMatTexScrollParams object_mir_ray_Matanimheader_0003F8TexScrollParams_0003F0[];
extern AnimatedMaterial object_mir_ray_Matanimheader_0003F8[];
extern Vtx object_mir_rayVtx_000400[];
extern Gfx object_mir_ray_DL_0004B0[];
extern Gfx object_mir_ray_DL_000550[];
extern u64 object_mir_ray_Tex_000558[];
#endif
