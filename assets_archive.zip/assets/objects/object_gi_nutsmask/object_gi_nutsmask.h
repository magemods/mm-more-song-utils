#ifndef OBJECT_GI_NUTSMASK_H
#define OBJECT_GI_NUTSMASK_H 1

extern Vtx object_gi_nutsmaskVtx_000000[];
extern Gfx gGiDekuMaskDL[];
extern Gfx gGiDekuMaskEmptyDL[];
extern u64 gGiDekuMaskHairTex[];
extern u64 gGiDekuMaskFaceTex[];
extern u64 gGiDekuMaskEyeTex[];
#endif
