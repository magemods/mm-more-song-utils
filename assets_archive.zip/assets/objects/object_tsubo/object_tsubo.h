#ifndef OBJECT_TSUBO_H
#define OBJECT_TSUBO_H 1

extern u64 gPotWallTex[];
extern u64 gPotRimTex[];
extern u64 gPotShardTex[];
extern Vtx object_tsuboVtx_001400[];
extern Gfx gPotDL[];
extern Vtx object_tsuboVtx_001930[];
extern Gfx gPotShardDL[];
#endif
