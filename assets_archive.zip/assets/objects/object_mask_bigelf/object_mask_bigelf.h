#ifndef OBJECT_MASK_BIGELF_H
#define OBJECT_MASK_BIGELF_H 1

extern Vtx object_mask_bigelfVtx_000000[];
extern Gfx object_mask_bigelf_DL_0016F0[];
extern u64 object_mask_bigelf_TLUT_002130[];
extern u64 object_mask_bigelf_Tex_002330[];
extern u64 object_mask_bigelf_Tex_002370[];
extern u64 object_mask_bigelf_Tex_002770[];
extern u64 object_mask_bigelf_Tex_002F70[];
extern u64 object_mask_bigelf_Tex_003070[];
extern u64 object_mask_bigelf_Tex_0030B0[];
#endif
