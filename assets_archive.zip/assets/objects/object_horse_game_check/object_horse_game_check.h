#ifndef OBJECT_HORSE_GAME_CHECK_H
#define OBJECT_HORSE_GAME_CHECK_H 1

extern Vtx object_horse_game_checkVtx_000008[];
extern u64 object_horse_game_check_Tex_000048[];
extern Gfx object_horse_game_check_DL_001048[];
extern Vtx object_horse_game_checkVtx_0010A0[];
extern Gfx object_horse_game_check_DL_0013A0[];
extern Gfx object_horse_game_check_DL_0014B0[];
extern u64 object_horse_game_check_Tex_001590[];
extern u64 object_horse_game_check_Tex_001D90[];
extern u64 object_horse_game_check_Tex_002590[];
extern BgCamInfo object_horse_game_check_Colheader_002FB8CamDataList[];
extern SurfaceType object_horse_game_check_Colheader_002FB8SurfaceType[];
extern CollisionPoly object_horse_game_check_Colheader_002FB8Polygons[];
extern Vec3s object_horse_game_check_Colheader_002FB8Vertices[];
extern CollisionHeader object_horse_game_check_Colheader_002FB8;
extern Vtx object_horse_game_checkVtx_002FF0[];
extern Gfx object_horse_game_check_DL_003030[];
extern Gfx object_horse_game_check_DL_0030C0[];
extern u64 object_horse_game_check_Tex_0030C8[];
extern BgCamInfo object_horse_game_check_Colheader_003918CamDataList[];
extern SurfaceType object_horse_game_check_Colheader_003918SurfaceType[];
extern CollisionPoly object_horse_game_check_Colheader_003918Polygons[];
extern Vec3s object_horse_game_check_Colheader_003918Vertices[];
extern CollisionHeader object_horse_game_check_Colheader_003918;
#endif
