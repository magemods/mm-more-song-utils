#ifndef OBJECT_GI_STICK_H
#define OBJECT_GI_STICK_H 1

extern Vtx object_gi_stickVtx_000000[];
extern Gfx gGiStickDL[];
#endif
