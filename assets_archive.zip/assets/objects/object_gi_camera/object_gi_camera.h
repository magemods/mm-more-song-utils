#ifndef OBJECT_GI_CAMERA_H
#define OBJECT_GI_CAMERA_H 1

extern Vtx object_gi_cameraVtx_000000[];
extern Gfx gGiPictoBoxBodyAndLensDL[];
extern Gfx gGiPictoBoxFrameDL[];
extern u64 gGiPictoBoxLensZoomRingTex[];
extern u64 gGiPictoBoxFrameTex[];
extern u64 gGiPictoBoxBodyAndLensGlassTex[];
#endif
