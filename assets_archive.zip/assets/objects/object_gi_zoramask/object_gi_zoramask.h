#ifndef OBJECT_GI_ZORAMASK_H
#define OBJECT_GI_ZORAMASK_H 1

extern Vtx object_gi_zoramaskVtx_000000[];
extern Gfx gGiZoraMaskDL[];
extern Gfx gGiZoraMaskEmptyDL[];
extern u64 gGiZoraMaskNoseTex[];
extern u64 gGiZoraMaskSpots1Tex[];
extern u64 gGiZoraMaskEyeTex[];
extern u64 gGiZoraMaskMouthTex[];
extern u64 gGiZoraMaskSpots2Tex[];
#endif
