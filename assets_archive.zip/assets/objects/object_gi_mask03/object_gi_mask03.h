#ifndef OBJECT_GI_MASK03_H
#define OBJECT_GI_MASK03_H 1

extern Vtx object_gi_mask03Vtx_000000[];
extern Gfx gGiFierceDeityMaskHairAndHatDL[];
extern Gfx gGiFierceDeityMaskFaceDL[];
extern u64 gGiFierceDeityMaskMouthAndEarTLUT[];
extern u64 gGiFierceDeityMaskEyeTLUT[];
extern u64 gGiFierceDeityMaskMouthTex[];
extern u64 gGiFierceDeityMaskEarTex[];
extern u64 gGiFierceDeityMaskEyeTex[];
extern u64 gGiFierceDeityMaskHatTex[];
extern u64 gGiFierceDeityMaskHairTex[];
#endif
