#ifndef OBJECT_MAMENOKI_H
#define OBJECT_MAMENOKI_H 1

extern Vtx object_mamenokiVtx_000000[];
extern Gfx object_mamenoki_DL_000090[];
extern Vtx object_mamenokiVtx_000130[];
extern Gfx object_mamenoki_DL_0002D0[];
extern BgCamInfo object_mamenoki_Colheader_0004BCCamDataList[];
extern SurfaceType object_mamenoki_Colheader_0004BCSurfaceType[];
extern CollisionPoly object_mamenoki_Colheader_0004BCPolygons[];
extern Vec3s object_mamenoki_Colheader_0004BCVertices[];
extern CollisionHeader object_mamenoki_Colheader_0004BC;
extern Vtx object_mamenokiVtx_0004F0[];
extern Gfx object_mamenoki_DL_000530[];
extern u64 object_mamenoki_Tex_0005C0[];
extern u64 object_mamenoki_Tex_000DC0[];
extern u64 object_mamenoki_Tex_0011C0[];
extern u64 object_mamenoki_Tex_0019C0[];
extern u64 object_mamenoki_Tex_001DC0[];
extern Vtx object_mamenokiVtx_0021C0[];
extern Gfx object_mamenoki_DL_002200[];
extern Gfx object_mamenoki_DL_002208[];
extern u64 object_mamenoki_Tex_002298[];
#endif
