#ifndef OBJECT_STK3_H
#define OBJECT_STK3_H 1

extern s16 sSkullKidSniffAnimFrameData[];
extern JointIndex sSkullKidSniffAnimJointIndices[];
extern AnimationHeader gSkullKidSniffAnim;
extern s16 sSkullKidLaughAfterSniffAnimFrameData[];
extern JointIndex sSkullKidLaughAfterSniffAnimJointIndices[];
extern AnimationHeader gSkullKidLaughAfterSniffAnim;
extern s16 sSkullKidAshamedStartAnimFrameData[];
extern JointIndex sSkullKidAshamedStartAnimJointIndices[];
extern AnimationHeader gSkullKidAshamedStartAnim;
extern s16 sSkullKidAshamedLoopAnimFrameData[];
extern JointIndex sSkullKidAshamedLoopAnimJointIndices[];
extern AnimationHeader gSkullKidAshamedLoopAnim;
extern s16 sSkullKidLookLeftStartAnimFrameData[];
extern JointIndex sSkullKidLookLeftStartAnimJointIndices[];
extern AnimationHeader gSkullKidLookLeftStartAnim;
extern s16 sSkullKidLookLeftLoopAnimFrameData[];
extern JointIndex sSkullKidLookLeftLoopAnimJointIndices[];
extern AnimationHeader gSkullKidLookLeftLoopAnim;
extern s16 sSkullKidLookUpAtGiantsAnimFrameData[];
extern JointIndex sSkullKidLookUpAtGiantsAnimJointIndices[];
extern AnimationHeader gSkullKidLookUpAtGiantsAnim;
#endif
