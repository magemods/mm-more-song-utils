#ifndef OBJECT_NY_H
#define OBJECT_NY_H 1

extern Vtx object_nyVtx_000000[];
extern Gfx object_ny_DL_000030[];
extern Gfx object_ny_DL_0000B8[];
extern u64 object_ny_Tex_0000C0[];
extern u64 object_ny_Tex_0001C0[];
extern u64 object_ny_Tex_0003C0[];
extern u64 object_ny_Tex_000BC0[];
extern Vtx object_nyVtx_0013C0[];
extern Gfx object_ny_DL_001F90[];
extern Gfx object_ny_DL_002068[];
extern Gfx object_ny_DL_002188[];
#endif
