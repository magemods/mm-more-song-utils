#ifndef OBJECT_GI_MASK11_H
#define OBJECT_GI_MASK11_H 1

extern Vtx object_gi_mask11Vtx_000000[];
extern Gfx gGiCircusLeaderMaskEyebrowsDL[];
extern Gfx gGiCircusLeaderMaskFaceDL[];
extern u64 gGiCircusLeaderMaskFaceTLUT[];
extern u64 gGiCircusLeaderMaskEyebrowTex[];
extern u64 gGiCircusLeaderMaskHairTex[];
extern u64 gGiCircusLeaderMaskEarTex[];
extern u64 gGiCircusLeaderMaskEyeTex[];
extern u64 gGiCircusLeaderMaskHairlineTex[];
extern u64 gGiCircusLeaderMaskSideBurnTex[];
extern u64 gGiCircusLeaderMaskSkinTex[];
#endif
