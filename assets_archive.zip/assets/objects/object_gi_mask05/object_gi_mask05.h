#ifndef OBJECT_GI_MASK05_H
#define OBJECT_GI_MASK05_H 1

extern Vtx object_gi_mask05Vtx_000000[];
extern Gfx gGiKafeiMaskEmptyDL[];
extern Gfx gGiKafeiMaskDL[];
extern u64 gGiKafeiMaskTLUT[];
extern u64 gGiKafeiMaskLowerHairTex[];
extern u64 gGiKafeiMaskUpperHairTex[];
extern u64 gGiKafeiMaskEyeMouthTex[];
extern u64 gGiKafeiMaskEyebrowTex[];
#endif
