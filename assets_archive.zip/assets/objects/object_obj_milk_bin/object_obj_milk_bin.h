#ifndef OBJECT_OBJ_MILK_BIN_H
#define OBJECT_OBJ_MILK_BIN_H 1

extern Vtx object_obj_milk_binVtx_000000[];
extern Gfx gMilkBinMilkJarDL[];
extern u64 object_obj_milk_bin_TLUT_0007C0[];
extern u64 object_obj_milk_bin_Tex_0009C0[];
extern u64 object_obj_milk_bin_Tex_000A00[];
extern u64 object_obj_milk_bin_Tex_001200[];
#endif
