#ifndef OBJECT_GI_MAGICMUSHROOM_H
#define OBJECT_GI_MAGICMUSHROOM_H 1

extern Vtx object_gi_magicmushroomVtx_000000[];
extern Gfx gGiMagicMushroomDL[];
extern Gfx gGiMagicMushroomEmptyDL[];
extern u64 gGiMagicMushroomPinkBackgroundTex[];
extern u64 gGiMagicMushroomBluePatternTex[];
extern u64 gGiMagicMushroomStemTex[];
#endif
