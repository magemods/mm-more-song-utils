#ifndef OBJECT_MEGANEANA_OBJ_H
#define OBJECT_MEGANEANA_OBJ_H 1

extern Vtx object_meganeana_objVtx_000000[];
extern Gfx object_meganeana_obj_DL_000080[];
extern Gfx object_meganeana_obj_DL_000110[];
extern u64 object_meganeana_obj_Tex_0001D0[];
extern u64 object_meganeana_obj_Tex_0005D0[];
extern u64 object_meganeana_obj_Tex_000DD0[];
#endif
