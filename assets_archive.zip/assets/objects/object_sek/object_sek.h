#ifndef OBJECT_SEK_H
#define OBJECT_SEK_H 1

extern Vtx object_sekVtx_000000[];
extern Gfx gOwlStatueClosedDL[];
extern u64 object_sek_Tex_0003F0[];
extern u64 object_sek_Tex_0007F0[];
extern Vtx object_sekVtx_000BF0[];
extern Gfx object_sek_DL_001110[];
extern u64 object_sek_TLUT_001610[];
extern u64 object_sek_Tex_001810[];
extern u64 object_sek_Tex_001C10[];
extern u64 object_sek_Tex_002010[];
extern u64 object_sek_Tex_002410[];
extern u64 object_sek_Tex_002810[];
extern u64 object_sek_Tex_002C10[];
extern Vtx object_sekVtx_003010[];
extern Gfx gOwlStatueOpenedDL[];
extern u64 object_sek_Tex_003A70[];
extern u64 object_sek_Tex_004270[];
#endif
