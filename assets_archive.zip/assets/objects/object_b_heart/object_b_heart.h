#ifndef OBJECT_B_HEART_H
#define OBJECT_B_HEART_H 1

extern Vtx object_b_heartVtx_000000[];
extern Gfx gUnusedHeartContainerDL[];
extern Gfx gUnusedHeartSpriteDL[];
extern u64 gUnusedHeartContainerTex[];
extern u64 gUnusedHeartSpriteTex[];
#endif
