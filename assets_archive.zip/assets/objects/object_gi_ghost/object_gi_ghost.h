#ifndef OBJECT_GI_GHOST_H
#define OBJECT_GI_GHOST_H 1

extern u64 gGiPoeContainerFlameTex[];
extern u64 gGiPoeContainerPatternTex[];
extern Vtx object_gi_ghostVtx_000400[];
extern Gfx gGiPoeContainerPoeColorDL[];
extern Gfx gGiPoeContainerBigPoeColorDL[];
extern Gfx gGiPoeContainerLidDL[];
extern Gfx gGiPoeContainerGlassDL[];
extern Gfx gGiPoeContainerContentsDL[];
#endif
