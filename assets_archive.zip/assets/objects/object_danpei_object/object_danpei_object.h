#ifndef OBJECT_DANPEI_OBJECT_H
#define OBJECT_DANPEI_OBJECT_H 1

extern Vtx object_danpei_objectVtx_000000[];
extern Gfx object_danpei_object_DL_000300[];
extern u64 object_danpei_object_TLUT_000438[];
extern u64 object_danpei_object_Tex_000458[];
extern BgCamInfo object_danpei_object_Colheader_000D60CamDataList[];
extern SurfaceType object_danpei_object_Colheader_000D60SurfaceType[];
extern CollisionPoly object_danpei_object_Colheader_000D60Polygons[];
extern Vec3s object_danpei_object_Colheader_000D60Vertices[];
extern CollisionHeader object_danpei_object_Colheader_000D60;
extern Vtx object_danpei_objectVtx_000D90[];
extern Gfx object_danpei_object_DL_0012C0[];
extern Vtx object_danpei_objectVtx_001BC0[];
extern Gfx object_danpei_object_DL_002110[];
extern u64 object_danpei_object_TLUT_002B10[];
extern u64 object_danpei_object_Tex_002D10[];
extern u64 object_danpei_object_Tex_003510[];
extern u64 object_danpei_object_Tex_003910[];
extern u64 object_danpei_object_Tex_003D10[];
#endif
