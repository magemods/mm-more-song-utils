#ifndef OBJECT_FWALL_H
#define OBJECT_FWALL_H 1

extern Vtx object_fwallVtx_000000[];
extern Gfx object_fwall_DL_000040[];
extern u64 gFireTempleBigVerticalFlame0Tex[];
extern u64 gFireTempleBigVerticalFlame1Tex[];
extern u64 gFireTempleBigVerticalFlame2Tex[];
extern u64 gFireTempleBigVerticalFlame3Tex[];
extern u64 gFireTempleBigVerticalFlame4Tex[];
extern u64 gFireTempleBigVerticalFlame5Tex[];
extern u64 gFireTempleBigVerticalFlame6Tex[];
extern u64 gFireTempleBigVerticalFlame7Tex[];
extern u64 gFwallFireball0Tex[];
extern u64 gFwallFireball1Tex[];
extern u64 gFwallFireball2Tex[];
extern u64 gFwallFireball3Tex[];
extern u64 gFwallFireball4Tex[];
extern u64 gFwallFireball5Tex[];
extern u64 gFwallFireball6Tex[];
extern u64 gFwallFireball7Tex[];
#endif
