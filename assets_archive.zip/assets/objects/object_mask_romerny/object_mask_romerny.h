#ifndef OBJECT_MASK_ROMERNY_H
#define OBJECT_MASK_ROMERNY_H 1

extern Vtx object_mask_romernyVtx_000000[];
extern Gfx object_mask_romerny_DL_0007A0[];
extern u64 object_mask_romerny_TLUT_000B88[];
extern u64 object_mask_romerny_Tex_000D88[];
extern u64 object_mask_romerny_Tex_001588[];
extern u64 object_mask_romerny_Tex_001688[];
extern u64 object_mask_romerny_Tex_001788[];
extern u64 object_mask_romerny_Tex_001988[];
#endif
