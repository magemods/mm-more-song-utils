#ifndef OBJECT_KINSTA1_OBJ_H
#define OBJECT_KINSTA1_OBJ_H 1

extern Vtx object_kinsta1_objVtx_000000[];
extern Gfx gSwampSpiderHouseSlidingDoorEmptyDL[];
extern Gfx gSwampSpiderHouseSlidingDoorDL[];
extern u64 gSwampSpiderHouseSlidingDoorTex[];
#endif
