#ifndef OBJECT_ICICLE_H
#define OBJECT_ICICLE_H 1

extern Vtx object_icicleVtx_000000[];
extern Gfx gIcicleDL[];
extern BgCamInfo gIcicleColCamDataList[];
extern SurfaceType gIcicleColSurfaceType[];
extern CollisionPoly gIcicleColPolygons[];
extern Vec3s gIcicleColVertices[];
extern CollisionHeader gIcicleCol;
extern u64 gIcicleTex[];
#endif
