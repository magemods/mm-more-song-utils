#ifndef OBJECT_GI_M_ARROW_H
#define OBJECT_GI_M_ARROW_H 1

extern Vtx object_gi_m_arrowVtx_000000[];
extern Gfx gGiMagicArrowAmmoDL[];
extern Gfx gGiMagicArrowFireColorDL[];
extern Gfx gGiMagicArrowIceColorDL[];
extern Gfx gGiMagicArrowLightColorDL[];
extern Gfx gGiMagicArrowGlowDL[];
#endif
