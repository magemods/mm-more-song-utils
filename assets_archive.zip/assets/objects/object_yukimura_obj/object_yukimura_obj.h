#ifndef OBJECT_YUKIMURA_OBJ_H
#define OBJECT_YUKIMURA_OBJ_H 1

extern Vtx object_yukimura_objVtx_000000[];
extern Gfx object_yukimura_obj_DL_000640[];
extern Gfx object_yukimura_obj_DL_000758[];
extern Gfx object_yukimura_obj_DL_000870[];
extern Gfx object_yukimura_obj_DL_000890[];
extern Gfx object_yukimura_obj_DL_0008C0[];
extern u64 object_yukimura_obj_Tex_0008D8[];
extern u64 object_yukimura_obj_Tex_0009D8[];
extern Vtx object_yukimura_objVtx_000DE0[];
extern Gfx object_yukimura_obj_DL_000EB0[];
extern Gfx object_yukimura_obj_DL_000F98[];
extern u64 object_yukimura_obj_Tex_001078[];
extern u64 object_yukimura_obj_Tex_001878[];
extern AnimatedMatTexScrollParams object_yukimura_obj_Matanimheader_002090TexScrollParams_002080[];
extern AnimatedMatTexScrollParams object_yukimura_obj_Matanimheader_002090TexScrollParams_002088[];
extern AnimatedMaterial object_yukimura_obj_Matanimheader_002090[];
#endif
