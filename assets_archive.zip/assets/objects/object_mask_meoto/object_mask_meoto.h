#ifndef OBJECT_MASK_MEOTO_H
#define OBJECT_MASK_MEOTO_H 1

extern Vtx object_mask_meotoVtx_000000[];
extern Gfx object_mask_meoto_DL_0005A0[];
extern u64 object_mask_meoto_Tex_0008C8[];
extern u64 object_mask_meoto_Tex_0010C8[];
extern u64 object_mask_meoto_Tex_0018C8[];
extern AnimatedMatTexScrollParams object_mask_meoto_Matanimheader_001CD8TexScrollParams_001CD0[];
extern AnimatedMaterial object_mask_meoto_Matanimheader_001CD8[];
#endif
