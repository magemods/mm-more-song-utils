#ifndef OBJECT_GI_BOMBPOUCH_H
#define OBJECT_GI_BOMBPOUCH_H 1

extern Vtx object_gi_bombpouchVtx_000000[];
extern Gfx gGiBombBag20BagColorDL[];
extern Gfx gGiBombBag30BagColorDL[];
extern Gfx gGiBombBag40BagColorDL[];
extern Gfx gGiBombBag20RingColorDL[];
extern Gfx gGiBombBag30RingColorDL[];
extern Gfx gGiBombBag40RingColorDL[];
extern Gfx gGiBombBagDL[];
extern Gfx gGiBombBagRingDL[];
#endif
