#ifndef OBJECT_GI_LOACH_H
#define OBJECT_GI_LOACH_H 1

extern Vtx object_gi_loachVtx_000000[];
extern Gfx gGiHylianLoachDL[];
extern Gfx gGiHylianLoachEmptyDL[];
extern u64 gGiHylianLoachBodyTex[];
extern u64 gGiHylianLoachSideFinTex[];
extern u64 gGiHylianLoachBackFinTex[];
extern u64 gGiHylianLoachEyeTex[];
#endif
