#ifndef OBJECT_GI_MASK17_H
#define OBJECT_GI_MASK17_H 1

extern Vtx object_gi_mask17Vtx_000000[];
extern Gfx gGiKamaroMaskEmptyDL[];
extern Gfx gGiKamaroMaskDL[];
extern u64 gGiKamaroMaskTLUT[];
extern u64 gGiKamaroMaskStitchesTex[];
extern u64 gGiKamaroMaskEyeTex[];
extern u64 gGiKamaroMaskSpotTex[];
extern u64 gGiKamaroMaskHairChinTex[];
extern u64 gGiKamaroMaskNoseEarTex[];
extern u64 gGiKamaroMaskPonytailTex[];
#endif
