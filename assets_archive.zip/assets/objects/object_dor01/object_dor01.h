#ifndef OBJECT_DOR01_H
#define OBJECT_DOR01_H 1

extern Vtx object_dor01Vtx_000000[];
extern Gfx gObservatoryLabDoorEmptyDL[];
extern Gfx gObservatoryLabDoorDL[];
extern u64 gObservatoryLabDoorTex[];
#endif
