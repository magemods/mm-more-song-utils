#ifndef OBJECT_WARP_UZU_H
#define OBJECT_WARP_UZU_H 1

extern Vtx object_warp_uzuVtx_000000[];
extern Gfx object_warp_uzu_DL_000EC0[];
extern u64 object_warp_uzu_TLUT_0019D0[];
extern u64 object_warp_uzu_Tex_001BD0[];
extern u64 object_warp_uzu_Tex_001FD0[];
extern u64 object_warp_uzu_Tex_002010[];
extern u64 object_warp_uzu_Tex_002410[];
#endif
