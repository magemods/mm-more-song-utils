#ifndef OBJECT_HANA_H
#define OBJECT_HANA_H 1

extern Gfx gGraveyardFlower1DL[];
extern Gfx gGraveyardFlower2DL[];
extern Gfx gGraveyardFlower3DL[];
extern Gfx gGraveyardFlowerLeaf1DL[];
extern Gfx gGraveyardFlowerLeaf2DL[];
extern Gfx gGraveyardFlowerLeaf3DL[];
extern Gfx gGraveyardFlowerLeaf4DL[];
extern Gfx gGraveyardFlowerLeaf5DL[];
extern Gfx gGraveyardFlowersDL[];
extern Vtx object_hanaVtx_000548[];
#endif
