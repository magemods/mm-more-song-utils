#ifndef OBJECT_ENDING_OBJ_H
#define OBJECT_ENDING_OBJ_H 1

extern Vtx object_ending_objVtx_000000[];
extern Gfx object_ending_obj_DL_0003D0[];
extern Gfx object_ending_obj_DL_0005E0[];
extern u64 object_ending_obj_Tex_0005E8[];
extern u64 object_ending_obj_Tex_000DE8[];
extern u64 object_ending_obj_Tex_000FE8[];
extern AnimatedMatTexScrollParams object_ending_obj_Matanimheader_001FF8TexScrollParams_001FF0[];
extern AnimatedMaterial object_ending_obj_Matanimheader_001FF8[];
extern Vtx object_ending_objVtx_002000[];
extern Gfx object_ending_obj_DL_0031A0[];
extern Gfx object_ending_obj_DL_003440[];
extern u64 object_ending_obj_Tex_003958[];
extern u64 object_ending_obj_Tex_004958[];
extern u64 object_ending_obj_Tex_005158[];
extern u64 object_ending_obj_Tex_005958[];
extern u64 object_ending_obj_Tex_005B58[];
extern u64 object_ending_obj_Tex_005D58[];
extern u64 object_ending_obj_Tex_006558[];
extern u64 object_ending_obj_Tex_007558[];
extern u64 object_ending_obj_Tex_0075D8[];
extern u64 object_ending_obj_Tex_007DD8[];
extern u64 object_ending_obj_Tex_0085D8[];
#endif
