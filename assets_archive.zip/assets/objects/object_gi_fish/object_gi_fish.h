#ifndef OBJECT_GI_FISH_H
#define OBJECT_GI_FISH_H 1

extern Vtx object_gi_fishVtx_000000[];
extern Gfx gGiFishContainerDL[];
#endif
