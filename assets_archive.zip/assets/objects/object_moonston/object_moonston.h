#ifndef OBJECT_MOONSTON_H
#define OBJECT_MOONSTON_H 1

extern Vtx object_moonstonVtx_000000[];
extern Gfx gFallingMoonsTearDL[];
extern Gfx gFallingMoonsTearFireDL[];
extern u64 gFallingMoonsTearTex[];
extern u64 gFallingMoonsTearFireTex[];
extern AnimatedMatTexScrollParams gFallingMoonsTearTexAnimTexScrollParams_001210[];
extern AnimatedMatTexScrollParams gFallingMoonsTearTexAnimTexScrollParams_001218[];
extern AnimatedMaterial gFallingMoonsTearTexAnim[];
#endif
