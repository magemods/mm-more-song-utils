#ifndef OBJECT_TANRON3_H
#define OBJECT_TANRON3_H 1

extern Vtx object_tanron3Vtx_000000[];
extern Gfx object_tanron3_DL_0004E0[];
extern Gfx object_tanron3_DL_000710[];
extern Gfx object_tanron3_DL_0007D8[];
extern Gfx object_tanron3_DL_0008A8[];
extern Gfx object_tanron3_DL_000960[];
extern u64 object_tanron3_TLUT_000A18[];
extern u64 object_tanron3_TLUT_000A38[];
extern u64 object_tanron3_TLUT_000A58[];
extern u64 object_tanron3_TLUT_000A78[];
extern u64 object_tanron3_Tex_000A98[];
extern u64 object_tanron3_Tex_000C98[];
extern u64 object_tanron3_Tex_000E98[];
extern u64 object_tanron3_Tex_001098[];
#endif
