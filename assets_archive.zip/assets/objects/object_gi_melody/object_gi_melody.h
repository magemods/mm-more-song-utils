#ifndef OBJECT_GI_MELODY_H
#define OBJECT_GI_MELODY_H 1

extern Vtx object_gi_melodyVtx_000000[];
extern Gfx gGiMinuetColorDL[];
extern Gfx gGiBoleroColorDL[];
extern Gfx gGiSerenadeColorDL[];
extern Gfx gGiRequiemColorDL[];
extern Gfx gGiNocturneColorDL[];
extern Gfx gGiPreludeColorDL[];
extern Gfx gGiSongNoteDL[];
#endif
