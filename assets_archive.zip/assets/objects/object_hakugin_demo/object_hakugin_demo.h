#ifndef OBJECT_HAKUGIN_DEMO_H
#define OBJECT_HAKUGIN_DEMO_H 1

extern s16 sGoronSpringShowAnimFrameData[];
extern JointIndex sGoronSpringShowAnimJointIndices[];
extern AnimationHeader gGoronSpringShowAnim;
extern s16 sGoronSpringShowLoopAnimFrameData[];
extern JointIndex sGoronSpringShowLoopAnimJointIndices[];
extern AnimationHeader gGoronSpringShowLoopAnim;
extern s16 sGoronSpringLookAroundAnimFrameData[];
extern JointIndex sGoronSpringLookAroundAnimJointIndices[];
extern AnimationHeader gGoronSpringLookAroundAnim;
extern s16 sGoronSpringLookAroundLoopAnimFrameData[];
extern JointIndex sGoronSpringLookAroundLoopAnimJointIndices[];
extern AnimationHeader gGoronSpringLookAroundLoopAnim;
#endif
