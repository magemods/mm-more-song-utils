#ifndef OBJECT_BOYO_H
#define OBJECT_BOYO_H 1

extern Vtx object_boyoVtx_000000[];
extern Gfx object_boyo_DL_000300[];
extern u64 object_boyo_Tex_000480[];
extern u64 object_boyo_Tex_000C80[];
extern AnimatedMatTexScrollParams object_boyo_Matanimheader_000E88TexScrollParams_000E80[];
extern AnimatedMaterial object_boyo_Matanimheader_000E88[];
#endif
