#ifndef OBJECT_SINKAI_KABE_H
#define OBJECT_SINKAI_KABE_H 1

extern BgCamInfo gPinnacleRockPythonDenColCamDataList[];
extern SurfaceType gPinnacleRockPythonDenColCamPosData[];
extern CollisionPoly gPinnacleRockPythonDenColPolygons[];
extern Vec3s gPinnacleRockPythonDenColVertices[];
extern CollisionHeader gPinnacleRockPythonDenCol;
#endif
