#ifndef OBJECT_CNE_H
#define OBJECT_CNE_H 1

typedef enum HylianYoungWomanLimb {
    /* 0x00 */ HYLIAN_YOUNG_WOMAN_LIMB_NONE,
    /* 0x01 */ HYLIAN_YOUNG_WOMAN_LIMB_PELVIS,
    /* 0x02 */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_THIGH,
    /* 0x03 */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_SHIN,
    /* 0x04 */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_FOOT,
    /* 0x05 */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_THIGH,
    /* 0x06 */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_SHIN,
    /* 0x07 */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_FOOT,
    /* 0x08 */ HYLIAN_YOUNG_WOMAN_LIMB_TORSO,
    /* 0x09 */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_UPPER_ARM,
    /* 0x0A */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_FOREARM,
    /* 0x0B */ HYLIAN_YOUNG_WOMAN_LIMB_LEFT_HAND,
    /* 0x0C */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_UPPER_ARM,
    /* 0x0D */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_FOREARM,
    /* 0x0E */ HYLIAN_YOUNG_WOMAN_LIMB_RIGHT_HAND,
    /* 0x0F */ HYLIAN_YOUNG_WOMAN_LIMB_HEAD,
    /* 0x10 */ HYLIAN_YOUNG_WOMAN_LIMB_MAX
} HylianYoungWomanLimb;

extern StandardLimb gHylianYoungWomanPelvisLimb;
extern StandardLimb gHylianYoungWomanLeftThighLimb;
extern StandardLimb gHylianYoungWomanLeftShinLimb;
extern StandardLimb gHylianYoungWomanLeftFootLimb;
extern StandardLimb gHylianYoungWomanRightThighLimb;
extern StandardLimb gHylianYoungWomanRightShinLimb;
extern StandardLimb gHylianYoungWomanRightFootLimb;
extern StandardLimb gHylianYoungWomanTorsoLimb;
extern StandardLimb gHylianYoungWomanLeftUpperArmLimb;
extern StandardLimb gHylianYoungWomanLeftForearmLimb;
extern StandardLimb gHylianYoungWomanLeftHandLimb;
extern StandardLimb gHylianYoungWomanRightUpperArmLimb;
extern StandardLimb gHylianYoungWomanRightForearmLimb;
extern StandardLimb gHylianYoungWomanRightHandLimb;
extern StandardLimb gHylianYoungWomanHeadLimb;
extern void* gHylianYoungWomanSkelLimbs[];
extern FlexSkeletonHeader gHylianYoungWomanSkel;
extern u32 gHylianYoungWomanTLUT[];
extern u32 gHylianYoungWomanSkinTex[];
extern u32 gHylianYoungWomanBrownHairTex[];
extern u32 gHylianYoungWomanHandTex[];
extern u32 gHylianYoungWomanBrownHairSkinTex[];
extern u32 gHylianYoungWomanBrownHairFaceTex[];
extern u32 gHylianYoungWomanDressTex[];
extern u32 gHylianYoungWomanDressNeckTex[];
extern Vtx object_cneVtx_000500[];
extern Gfx gHylianYoungWomanHeadBrownHairDL[];
extern Gfx gHylianYoungWomanRightHandDL[];
extern Gfx gHylianYoungWomanRightForearmDL[];
extern Gfx gHylianYoungWomanRightUpperArmDL[];
extern Gfx gHylianYoungWomanLeftHandDL[];
extern Gfx gHylianYoungWomanLeftForearmDL[];
extern Gfx gHylianYoungWomanLeftUpperArmDL[];
extern Gfx gHylianYoungWomanTorsoDL[];
extern Gfx gHylianYoungWomanRightFootDL[];
extern Gfx gHylianYoungWomanRightShinDL[];
extern Gfx gHylianYoungWomanRightThighDL[];
extern Gfx gHylianYoungWomanLeftFootDL[];
extern Gfx gHylianYoungWomanLeftShinDL[];
extern Gfx gHylianYoungWomanLeftThighDL[];
extern Gfx gHylianYoungWomanPelvisDL[];
extern u64 gHylianYoungWomanOrangeHairFaceTex[];
extern u64 gHylianYoungWomanOrangeHairSkinTex[];
extern Vtx object_cneVtx_002550[];
extern Gfx gHylianYoungWomanHeadOrangeHairDL[];
#endif
