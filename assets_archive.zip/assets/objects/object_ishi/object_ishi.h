#ifndef OBJECT_ISHI_H
#define OBJECT_ISHI_H 1

extern Vtx object_ishiVtx_000000[];
extern u64 gSmallRockTex[];
extern Gfx gSmallRockDL[];
#endif
