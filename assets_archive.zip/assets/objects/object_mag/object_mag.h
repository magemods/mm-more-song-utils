#ifndef OBJECT_MAG_H
#define OBJECT_MAG_H 1

extern u64 gTitleScreenZeldaLogoTex[];
extern u64 gTitleScreenMajorasMaskSubtitleTex[];
extern u64 gTitleScreenMajorasMaskSubtitleMaskTex[];
extern u64 gTitleScreenTheLegendOfTextTex[];
extern u64 gTitleScreenDisplayEffectMask00Tex[];
extern u64 gTitleScreenDisplayEffectMask01Tex[];
extern u64 gTitleScreenDisplayEffectMask10Tex[];
extern u64 gTitleScreenDisplayEffectMask11Tex[];
extern u64 gTitleScreenDisplayEffectMask02Tex[];
extern u64 gTitleScreenDisplayEffectMask12Tex[];
extern u64 gTitleScreenAppearEffectMask00Tex[];
extern u64 gTitleScreenAppearEffectMask01Tex[];
extern u64 gTitleScreenAppearEffectMask10Tex[];
extern u64 gTitleScreenAppearEffectMask11Tex[];
extern u64 gTitleScreenAppearEffectMask02Tex[];
extern u64 gTitleScreenAppearEffectMask12Tex[];
extern u64 gTitleScreenFlame0Tex[];
extern u64 gTitleScreenFlame1Tex[];
extern u64 gTitleScreenFlame2Tex[];
extern u64 gTitleScreenFlame3Tex[];
extern u64 gTitleScreenCopyright2000NintendoTex[];
extern u64 gTitleScreenControllerNotConnectedTextTex[];
extern u64 gTitleScreenInsertControllerTextTex[];
extern u64 gTitleScreenMajorasMaskTex[];
#endif
