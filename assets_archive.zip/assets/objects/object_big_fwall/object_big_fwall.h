#ifndef OBJECT_BIG_FWALL_H
#define OBJECT_BIG_FWALL_H 1

extern u64 gRingOfFireTex[];
extern Vtx object_big_fwallVtx_000800[];
extern Gfx gRingOfFireDL[];
#endif
