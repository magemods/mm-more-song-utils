#ifndef OBJECT_GI_SOUL_H
#define OBJECT_GI_SOUL_H 1

extern u64 gGiFairyContainerFairyTex[];
extern Vtx object_gi_soulVtx_000400[];
extern Gfx gGiFairyContainerBaseCapDL[];
extern Gfx gGiFairyContainerGlassDL[];
extern Gfx gGiFairyContainerContentsDL[];
#endif
