#ifndef OBJECT_FU_KAITEN_H
#define OBJECT_FU_KAITEN_H 1

extern Vtx object_fu_kaitenVtx_000000[];
extern Gfx object_fu_kaiten_DL_0005D0[];
extern u64 object_fu_kaiten_TLUT_000858[];
extern u64 object_fu_kaiten_Tex_000878[];
extern u64 object_fu_kaiten_Tex_001078[];
extern u64 object_fu_kaiten_Tex_001878[];
extern u64 object_fu_kaiten_Tex_002078[];
extern BgCamInfo object_fu_kaiten_Colheader_002D30CamDataList[];
extern SurfaceType object_fu_kaiten_Colheader_002D30SurfaceType[];
extern CollisionPoly object_fu_kaiten_Colheader_002D30Polygons[];
extern Vec3s object_fu_kaiten_Colheader_002D30Vertices[];
extern CollisionHeader object_fu_kaiten_Colheader_002D30;
extern Vtx object_fu_kaitenVtx_002D60[];
extern Gfx object_fu_kaiten_DL_002EB0[];
extern Gfx object_fu_kaiten_DL_002FB0[];
extern Gfx object_fu_kaiten_DL_002FC0[];
extern u64 object_fu_kaiten_Tex_002FD0[];
extern AnimatedMatTexScrollParams object_fu_kaiten_Matanimheader_0037D8TexScrollParams_0037D0[];
extern AnimatedMaterial object_fu_kaiten_Matanimheader_0037D8[];
extern BgCamInfo object_fu_kaiten_Colheader_0037F8CamDataList[];
extern WaterBox object_fu_kaiten_Colheader_0037F8WaterBoxes[];
extern CollisionHeader object_fu_kaiten_Colheader_0037F8;
#endif
