#ifndef OBJECT_FU_MATO_H
#define OBJECT_FU_MATO_H 1

extern Vtx object_fu_matoVtx_000000[];
extern Gfx object_fu_mato_DL_0006A0[];
extern Gfx object_fu_mato_DL_000740[];
extern Gfx object_fu_mato_DL_0007E0[];
extern Gfx object_fu_mato_DL_000880[];
extern Gfx object_fu_mato_DL_000920[];
extern Gfx object_fu_mato_DL_0009C0[];
extern u64 object_fu_mato_Tex_000A60[];
extern BgCamInfo object_fu_mato_Colheader_0015C0CamDataList[];
extern SurfaceType object_fu_mato_Colheader_0015C0SurfaceType[];
extern CollisionPoly object_fu_mato_Colheader_0015C0Polygons[];
extern Vec3s object_fu_mato_Colheader_0015C0Vertices[];
extern CollisionHeader object_fu_mato_Colheader_0015C0;
extern Vtx object_fu_matoVtx_0015F0[];
extern Gfx object_fu_mato_DL_001C80[];
extern Gfx object_fu_mato_DL_001D68[];
extern Gfx object_fu_mato_DL_001E50[];
extern Gfx object_fu_mato_DL_001F38[];
extern Gfx object_fu_mato_DL_002020[];
extern Gfx object_fu_mato_DL_002108[];
extern BgCamInfo object_fu_mato_Colheader_0023D4CamDataList[];
extern SurfaceType object_fu_mato_Colheader_0023D4SurfaceType[];
extern CollisionPoly object_fu_mato_Colheader_0023D4Polygons[];
extern Vec3s object_fu_mato_Colheader_0023D4Vertices[];
extern CollisionHeader object_fu_mato_Colheader_0023D4;
extern Vtx object_fu_matoVtx_002400[];
extern Gfx object_fu_mato_DL_002720[];
extern u64 object_fu_mato_Tex_002850[];
extern u64 object_fu_mato_Tex_002A50[];
#endif
