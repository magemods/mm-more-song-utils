#ifndef OBJECT_WDOR05_H
#define OBJECT_WDOR05_H 1

extern Vtx object_wdor05Vtx_000000[];
extern Gfx gMusicBoxHouseEndDL[];
extern Gfx gMusicBoxHouseDoorDL[];
extern u64 gMusicBoxHouseDoorTex[];
#endif
