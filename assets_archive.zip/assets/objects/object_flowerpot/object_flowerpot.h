#ifndef OBJECT_FLOWERPOT_H
#define OBJECT_FLOWERPOT_H 1

extern u64 object_flowerpot_Tex_000000[];
extern u64 object_flowerpot_Tex_000400[];
extern u64 object_flowerpot_Tex_000800[];
extern Vtx object_flowerpotVtx_001000[];
extern Gfx object_flowerpot_DL_0012E0[];
extern Gfx object_flowerpot_DL_001408[];
extern Vtx object_flowerpotVtx_0014C0[];
extern Gfx object_flowerpot_DL_0014F0[];
extern Vtx object_flowerpotVtx_001580[];
extern Gfx object_flowerpot_DL_0015B0[];
#endif
