#ifndef OBJECT_FUNEN_H
#define OBJECT_FUNEN_H 1

extern Vtx object_funenVtx_000000[];
extern Gfx gStoneTowerSmokeDL[];
extern u64 gStoneTowerSmokeTex[];
#endif
