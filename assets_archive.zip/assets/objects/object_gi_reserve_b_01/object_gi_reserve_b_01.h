#ifndef OBJECT_GI_RESERVE_B_01_H
#define OBJECT_GI_RESERVE_B_01_H 1

extern Vtx object_gi_reserve_b_01Vtx_000000[];
extern Gfx gGiLetterToMamaInscriptionsDL[];
extern Gfx gGiLetterToMamaEnvelopeLetterDL[];
extern u64 gGiLetterToMamaPostalAddressTex[];
extern u64 gGiLetterToMamaStampTex[];
extern u64 gGiLetterToMamaPattern1Tex[];
extern u64 gGiLetterToMamaPattern2Tex[];
#endif
