#ifndef OBJECT_BSMASK_H
#define OBJECT_BSMASK_H 1

extern Vtx object_bsmaskVtx_000000[];
extern Gfx gRemainsOdolwaDL[];
extern Vtx object_bsmaskVtx_0009E0[];
extern Gfx gRemainsGyorgDL[];
extern Vtx object_bsmaskVtx_002680[];
extern Gfx gRemainsGohtDL[];
extern Vtx object_bsmaskVtx_004270[];
extern Gfx gRemainsTwinmoldDL[];
extern u64 gRemainsOdolwaFaceTLUT[];
extern u64 gRemainsOdolwaEarTLUT[];
extern u64 gRemainsGyorgSkinTLUT[];
extern u64 gRemainsGyorgMouthTLUT[];
extern u64 gRemainsGyorgToothHornTLUT[];
extern u64 gRemainsTwinmoldSkinTLUT[];
extern u64 gRemainsTwinmoldSnoutTLUT[];
extern u64 gRemainsOdolwaPlumeTex[];
extern u64 gRemainsOdolwaFaceTex[];
extern u64 gRemainsOdolwaEarTex[];
extern u64 gRemainsGyorgTwinmoldEyeTex[];
extern u64 gRemainsGyorgSkinTex[];
extern u64 gRemainsGyorgMouthTex[];
extern u64 gRemainsGyorgToothHornTex[];
extern u64 gRemainsGohtEyeTex[];
extern u64 gRemainsGohtTopPatternTex[];
extern u64 gRemainsGohtTwinmoldPatternTex[];
extern u64 gRemainsGohtSpikeTwinmoldMandibleTex[];
extern u64 gRemainsTwinmoldSkinTex[];
extern u64 gRemainsTwinmoldSnoutTex[];
#endif
