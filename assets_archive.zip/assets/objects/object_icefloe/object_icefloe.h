#ifndef OBJECT_ICEFLOE_H
#define OBJECT_ICEFLOE_H 1

extern Vtx object_icefloeVtx_000000[];
extern Gfx gIcefloeIcePlatformDL[];
extern u64 gIcefloePlatformTex[];
extern BgCamInfo gIcefloePlatformColCamDataList[];
extern SurfaceType gIcefloePlatformColSurfaceType[];
extern CollisionPoly gIcefloePlatformColPolygons[];
extern Vec3s gIcefloePlatformColVertices[];
extern CollisionHeader gIcefloePlatformCol;
#endif
