#ifndef OBJECT_DOR03_H
#define OBJECT_DOR03_H 1

extern Vtx object_dor03Vtx_000000[];
extern Gfx gSwampDoorDL[];
extern u64 gSwampDoorTex[];
#endif
