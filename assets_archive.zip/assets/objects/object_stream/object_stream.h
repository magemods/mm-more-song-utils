#ifndef OBJECT_STREAM_H
#define OBJECT_STREAM_H 1

extern u64 gWaterVortexTex[];
extern Vtx object_streamVtx_000800[];
extern Gfx gWaterVortexDL[];
#endif
