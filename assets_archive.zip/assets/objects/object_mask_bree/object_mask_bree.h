#ifndef OBJECT_MASK_BREE_H
#define OBJECT_MASK_BREE_H 1

extern Vtx object_mask_breeVtx_000000[];
extern Gfx object_mask_bree_DL_0003C0[];
extern u64 object_mask_bree_TLUT_000658[];
extern u64 object_mask_bree_Tex_000858[];
extern u64 object_mask_bree_Tex_000C58[];
extern u64 object_mask_bree_Tex_000D58[];
extern u64 object_mask_bree_Tex_000D98[];
#endif
