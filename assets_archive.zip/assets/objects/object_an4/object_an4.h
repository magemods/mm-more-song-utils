#ifndef OBJECT_AN4_H
#define OBJECT_AN4_H 1

extern s16 sAnju4CombineMasks2AnimFrameData[];
extern JointIndex sAnju4CombineMasks2AnimJointIndices[];
extern AnimationHeader gAnju4CombineMasks2Anim;
extern s16 sAnju4HugAnimFrameData[];
extern JointIndex sAnju4HugAnimJointIndices[];
extern AnimationHeader gAnju4HugAnim;
extern s16 sAnju4HugLoopAnimFrameData[];
extern JointIndex sAnju4HugLoopAnimJointIndices[];
extern AnimationHeader gAnju4HugLoopAnim;
extern s16 sAnju4HugReleaseAnimFrameData[];
extern JointIndex sAnju4HugReleaseAnimJointIndices[];
extern AnimationHeader gAnju4HugReleaseAnim;
extern s16 sAnju4HugReleaseLoopAnimFrameData[];
extern JointIndex sAnju4HugReleaseLoopAnimJointIndices[];
extern AnimationHeader gAnju4HugReleaseLoopAnim;
extern s16 sAnju4LookUpAnimFrameData[];
extern JointIndex sAnju4LookUpAnimJointIndices[];
extern AnimationHeader gAnju4LookUpAnim;
extern s16 sAnju4LookUpLoopAnimFrameData[];
extern JointIndex sAnju4LookUpLoopAnimJointIndices[];
extern AnimationHeader gAnju4LookUpLoopAnim;
extern s16 sAnju4CombineMasks1AnimFrameData[];
extern JointIndex sAnju4CombineMasks1AnimJointIndices[];
extern AnimationHeader gAnju4CombineMasks1Anim;
extern s16 sAnju4MaskStandLoopAnimFrameData[];
extern JointIndex sAnju4MaskStandLoopAnimJointIndices[];
extern AnimationHeader gAnju4MaskStandLoopAnim;
extern s16 sAnju4MaskKneelAnimFrameData[];
extern JointIndex sAnju4MaskKneelAnimJointIndices[];
extern AnimationHeader gAnju4MaskKneelAnim;
extern s16 sAnju4MaskKneelLoopAnimFrameData[];
extern JointIndex sAnju4MaskKneelLoopAnimJointIndices[];
extern AnimationHeader gAnju4MaskKneelLoopAnim;
#endif
