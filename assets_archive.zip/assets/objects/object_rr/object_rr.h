#ifndef OBJECT_RR_H
#define OBJECT_RR_H 1

extern Vtx object_rrVtx_000000[];
extern Gfx gLikeLikeDL[];
extern u64 gLikeLikeBodyPattern1Tex[];
extern u64 gLikeLikeBodyPattern2Tex[];
extern u64 gLikeLikeHoleTex[];
#endif
