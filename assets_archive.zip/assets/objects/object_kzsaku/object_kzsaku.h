#ifndef OBJECT_KZSAKU_H
#define OBJECT_KZSAKU_H 1

extern Vtx object_kzsakuVtx_000000[];
extern Gfx gUnderwaterGrateDL[];
extern u64 gUnderwaterGrateTex[];
extern BgCamInfo gUnderwaterGrateColCamDataList[];
extern SurfaceType gUnderwaterGrateColSurfaceType[];
extern CollisionPoly gUnderwaterGrateColPolygons[];
extern Vec3s gUnderwaterGrateColVertices[];
extern CollisionHeader gUnderwaterGrateCol;
#endif
