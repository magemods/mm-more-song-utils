#ifndef OBJECT_RACETSUBO_H
#define OBJECT_RACETSUBO_H 1

extern Vtx object_racetsuboVtx_000000[];
extern Gfx gMagicPotEmpty1DL[];
extern Gfx gMagicPotDL[];
extern u64 gMagicPotWallTex[];
extern u64 gMagicPotRimTex[];
extern Vtx object_racetsuboVtx_0015E0[];
extern Gfx gMagicPotShardDL[];
extern Gfx gMagicPotEmpty2DL[];
extern u64 gMagicPotShardTex[];
#endif
