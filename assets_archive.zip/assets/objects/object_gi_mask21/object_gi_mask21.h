#ifndef OBJECT_GI_MASK21_H
#define OBJECT_GI_MASK21_H 1

extern Vtx object_gi_mask21Vtx_000000[];
extern Gfx gGiBlastMaskDL[];
extern Gfx gGiBlastMaskEmptyDL[];
extern u64 gGiBlastMaskSkullTex[];
extern u64 gGiBlastMaskBombTex[];
#endif
