#ifndef OBJECT_DORA_H
#define OBJECT_DORA_H 1

extern Vtx object_doraVtx_000000[];
extern Gfx gKendoKanbanDL[];
extern u64 gKendoKanbanFrontTex[];
extern u64 gKendoKanbanSideTex[];
extern Vtx object_doraVtx_001A80[];
extern Gfx gKendoKanbanTopRightDL[];
extern Gfx gKendoKanbanTopLeftDL[];
extern Gfx gKendoKanbanBottomLeftDL[];
extern Gfx gKendoKanbanBottomRightDL[];
extern u64 gKendoKanbanSplitFrontTex[];
extern u64 gKendoKanbanSplitSideTex[];
extern Vtx object_doraVtx_003C80[];
extern Gfx gDoraGongDL[];
extern Gfx gDoraChainDL[];
extern u64 gDoraGongTex[];
extern u64 gDoraChainTex[];
#endif
