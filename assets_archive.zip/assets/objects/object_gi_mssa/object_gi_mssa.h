#ifndef OBJECT_GI_MSSA_H
#define OBJECT_GI_MSSA_H 1

extern Vtx object_gi_mssaVtx_000000[];
extern Gfx gGiSunMaskEyesSidePatternsDL[];
extern Gfx gGiSunMaskFaceDL[];
extern u64 gGiSunMaskEyeTex[];
extern u64 gGiSunMaskSidePatternsTex[];
extern u64 gGiSunMaskFacePatternsTex[];
extern u64 gGiSunMaskManeSwirlTex[];
#endif
