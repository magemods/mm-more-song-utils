#ifndef OBJECT_MARUTA_H
#define OBJECT_MARUTA_H 1

extern u64 object_maruta_Tex_000000[];
extern u64 object_maruta_Tex_000800[];
extern u64 object_maruta_Tex_001000[];
extern Vtx object_marutaVtx_001800[];
extern Gfx object_maruta_DL_002220[];
extern Gfx object_maruta_DL_0023D0[];
extern Gfx object_maruta_DL_002568[];
extern Gfx object_maruta_DL_002660[];
extern Gfx object_maruta_DL_002758[];
extern Gfx object_maruta_DL_002850[];
extern Gfx object_maruta_DL_002948[];
extern Gfx object_maruta_DL_002AE0[];
extern Vtx object_marutaVtx_002C80[];
extern Gfx object_maruta_DL_002EC0[];
#endif
