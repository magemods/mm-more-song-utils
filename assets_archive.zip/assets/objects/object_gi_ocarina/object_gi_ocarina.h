#ifndef OBJECT_GI_OCARINA_H
#define OBJECT_GI_OCARINA_H 1

extern u64 gGiOcarinaOfTimeHoleTex[];
extern Vtx object_gi_ocarinaVtx_000100[];
extern Gfx gGiOcarinaOfTimeDL[];
extern Gfx gGiOcarinaOfTimeHolesDL[];
#endif
