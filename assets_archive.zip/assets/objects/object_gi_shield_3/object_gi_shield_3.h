#ifndef OBJECT_GI_SHIELD_3_H
#define OBJECT_GI_SHIELD_3_H 1

extern Vtx object_gi_shield_3Vtx_000000[];
extern Gfx gGiMirrorShieldDL[];
extern Gfx gGiMirrorShieldEmptyDL[];
extern u64 gGiMirrorShieldHandleTex[];
extern u64 gGiMirrorShieldFaceSymbolTex[];
extern u64 gGiMirrorShieldFaceBackgroundTex[];
extern u64 gGiMirrorShieldPatternTex[];
#endif
