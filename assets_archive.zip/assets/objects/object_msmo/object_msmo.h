#ifndef OBJECT_MSMO_H
#define OBJECT_MSMO_H 1

extern Vtx object_msmoVtx_000000[];
extern Gfx gMoonMaskDL[];
extern u64 gMoonMaskEyeTex[];
extern u64 gMoonMaskPatternTex[];
extern u64 gMoonMaskSilverTex[];
extern u64 gMoonMaskGoldTex[];
#endif
