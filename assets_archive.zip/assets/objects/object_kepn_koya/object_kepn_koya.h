#ifndef OBJECT_KEPN_KOYA_H
#define OBJECT_KEPN_KOYA_H 1

extern Vtx object_kepn_koyaVtx_000000[];
extern Gfx object_kepn_koya_DL_003470[];
extern Gfx object_kepn_koya_DL_003478[];
extern u64 object_kepn_koya_TLUT_005118[];
extern u64 object_kepn_koya_Tex_005318[];
extern u64 object_kepn_koya_Tex_005418[];
extern u64 object_kepn_koya_Tex_005C18[];
extern u64 object_kepn_koya_Tex_006418[];
extern u64 object_kepn_koya_Tex_006618[];
extern u64 object_kepn_koya_Tex_006818[];
extern u64 object_kepn_koya_Tex_006A18[];
extern u64 object_kepn_koya_Tex_006E18[];
extern u64 object_kepn_koya_Tex_007218[];
extern u64 object_kepn_koya_Tex_007298[];
extern BgCamInfo object_kepn_koya_Colheader_00805CCamDataList[];
extern SurfaceType object_kepn_koya_Colheader_00805CSurfaceType[];
extern CollisionPoly object_kepn_koya_Colheader_00805CPolygons[];
extern Vec3s object_kepn_koya_Colheader_00805CVertices[];
extern CollisionHeader object_kepn_koya_Colheader_00805C;
#endif
