#ifndef OBJECT_TOKEI_STEP_H
#define OBJECT_TOKEI_STEP_H 1

extern Vtx object_tokei_stepVtx_000000[];
extern Gfx gClocktowerPanelEmptyDL[];
extern Gfx gClocktowerPanelDL[];
extern u64 gClocktowerPanelTex[];
extern BgCamInfo gClocktowerPanelColCamDataList[];
extern SurfaceType gClocktowerPanelColSurfaceType[];
extern CollisionPoly gClocktowerPanelColPolygons[];
extern Vec3s gClocktowerPanelColVertices[];
extern CollisionHeader gClocktowerPanelCol;
#endif
