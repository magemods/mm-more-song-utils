#ifndef OBJECT_EFC_STAR_FIELD_H
#define OBJECT_EFC_STAR_FIELD_H 1

extern Vtx object_efc_star_fieldVtx_000000[];
extern Gfx object_efc_star_field_DL_000080[];
extern u64 object_efc_star_field_Tex_000108[];
extern Vtx object_efc_star_fieldVtx_000510[];
extern Gfx object_efc_star_field_DL_000DE0[];
extern u64 object_efc_star_field_Tex_000FD0[];
#endif
