#ifndef OBJECT_MASK_KYOJIN_H
#define OBJECT_MASK_KYOJIN_H 1

extern Vtx object_mask_kyojinVtx_000000[];
extern Gfx object_mask_kyojin_DL_000380[];
extern u64 object_mask_kyojin_Tex_000498[];
#endif
