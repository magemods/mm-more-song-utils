#ifndef OBJECT_OBJ_DINNER_H
#define OBJECT_OBJ_DINNER_H 1

extern Vtx object_obj_dinnerVtx_000000[];
extern Gfx object_obj_dinner_DL_0011E0[];
extern Gfx object_obj_dinner_DL_001AA0[];
extern u64 object_obj_dinner_Tex_001B38[];
extern u64 object_obj_dinner_Tex_001C38[];
extern u64 object_obj_dinner_Tex_001E38[];
extern u64 object_obj_dinner_Tex_002038[];
extern u64 object_obj_dinner_Tex_002238[];
#endif
