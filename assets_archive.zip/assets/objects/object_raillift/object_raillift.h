#ifndef OBJECT_RAILLIFT_H
#define OBJECT_RAILLIFT_H 1

extern Vtx object_railliftVtx_000000[];
extern Gfx object_raillift_DL_000200[];
extern Gfx object_raillift_DL_000208[];
extern u64 object_raillift_Tex_000370[];
extern u64 object_raillift_Tex_000B70[];
extern u64 object_raillift_Tex_001370[];
extern Vtx object_railliftVtx_001B70[];
extern Gfx object_raillift_DL_001DB0[];
extern Gfx object_raillift_DL_001E40[];
extern u64 object_raillift_Tex_001FC8[];
extern u64 object_raillift_Tex_0027C8[];
extern u64 object_raillift_Tex_002FC8[];
extern u64 object_raillift_Tex_0037C8[];
extern BgCamInfo object_raillift_Colheader_0048D0CamDataList[];
extern SurfaceType object_raillift_Colheader_0048D0SurfaceType[];
extern CollisionPoly object_raillift_Colheader_0048D0Polygons[];
extern Vec3s object_raillift_Colheader_0048D0Vertices[];
extern CollisionHeader object_raillift_Colheader_0048D0;
extern Vtx object_railliftVtx_004900[];
extern Gfx object_raillift_DL_004BF0[];
extern BgCamInfo object_raillift_Colheader_004FF8CamDataList[];
extern SurfaceType object_raillift_Colheader_004FF8SurfaceType[];
extern CollisionPoly object_raillift_Colheader_004FF8Polygons[];
extern Vec3s object_raillift_Colheader_004FF8Vertices[];
extern CollisionHeader object_raillift_Colheader_004FF8;
extern u64 object_raillift_Tex_005030[];
extern u64 object_raillift_Tex_005830[];
extern u64 object_raillift_Tex_006030[];
extern u64 object_raillift_Tex_006830[];
extern Vtx object_railliftVtx_007030[];
extern Gfx object_raillift_DL_0071B0[];
extern Gfx object_raillift_DL_0071B8[];
extern u64 object_raillift_Tex_0072B0[];
extern u64 object_raillift_Tex_007AB0[];
#endif
