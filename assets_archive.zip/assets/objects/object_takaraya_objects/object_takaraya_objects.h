#ifndef OBJECT_TAKARAYA_OBJECTS_H
#define OBJECT_TAKARAYA_OBJECTS_H 1

extern u64 gTreasureChestShopWallWhiteTLUT[];
extern u64 gTreasureChestShopWallBlackTex[];
extern u64 gTreasureChestShopWallWhiteTex[];
extern Vtx object_takaraya_objectsVtx_000A20[];
extern Gfx gTreasureChestShopWallBlackDL[];
extern Vtx object_takaraya_objectsVtx_000C30[];
extern Gfx gTreasureChestShopWallWhiteDL[];
#endif
