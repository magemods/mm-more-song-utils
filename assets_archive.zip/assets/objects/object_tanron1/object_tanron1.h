#ifndef OBJECT_TANRON1_H
#define OBJECT_TANRON1_H 1

extern Gfx gTanron1EmptyDL[];
#endif
