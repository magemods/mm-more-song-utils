#ifndef OBJECT_GI_MASK20_H
#define OBJECT_GI_MASK20_H 1

extern Vtx object_gi_mask20Vtx_000000[];
extern Gfx gGiBremenMaskEmptyDL[];
extern Gfx gGiBremenMaskDL[];
extern u64 gGiBremenMaskTLUT[];
extern u64 gGiBremenMaskFeathersTex[];
extern u64 gGiBremenMaskBeakBaseTex[];
extern u64 gGiBremenMaskBeakNostrilTex[];
extern u64 gGiBremenMaskEyeTex[];
#endif
