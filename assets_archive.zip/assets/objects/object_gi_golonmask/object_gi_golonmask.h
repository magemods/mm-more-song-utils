#ifndef OBJECT_GI_GOLONMASK_H
#define OBJECT_GI_GOLONMASK_H 1

extern Vtx object_gi_golonmaskVtx_000000[];
extern Gfx gGiGoronMaskDL[];
extern Gfx gGiGoronMaskEmptyDL[];
extern u64 gGiGoronMaskEyeTex[];
extern u64 gGiGoronMaskMouthTex[];
extern u64 gGiGoronMaskNoseEyebrowTex[];
#endif
