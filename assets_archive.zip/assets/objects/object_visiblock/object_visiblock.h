#ifndef OBJECT_VISIBLOCK_H
#define OBJECT_VISIBLOCK_H 1

extern Vtx object_visiblockVtx_000000[];
extern Gfx gLensOfTruthPlatformDL[];
extern Gfx gLensOfTruthPlatformEmptyDL[];
extern u64 gLensOfTruthPlatformTex[];
extern BgCamInfo gLensOfTruthPlatformColCamDataList[];
extern SurfaceType gLensOfTruthPlatformColSurfaceType[];
extern CollisionPoly gLensOfTruthPlatformColPolygons[];
extern Vec3s gLensOfTruthPlatformColVertices[];
extern CollisionHeader gLensOfTruthPlatformCol;
#endif
