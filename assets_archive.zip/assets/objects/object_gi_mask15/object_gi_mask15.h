#ifndef OBJECT_GI_MASK15_H
#define OBJECT_GI_MASK15_H 1

extern Vtx object_gi_mask15Vtx_000000[];
extern Gfx gGiGibdoMaskDL[];
extern Gfx gGiGibdoMaskEmptyDL[];
extern u64 gGiGibdoMaskWrapPattern1Tex[];
extern u64 gGiGibdoMaskWrapPattern2Tex[];
extern u64 gGiGibdoMaskEyeTex[];
#endif
