#ifndef OBJECT_GI_MASK18_H
#define OBJECT_GI_MASK18_H 1

extern Vtx object_gi_mask18Vtx_000000[];
extern Gfx gGiCaptainsHatFaceDL[];
extern Gfx gGiCaptainsHatBodyDL[];
extern u64 gGiCaptainsHatBodyTLUT[];
extern u64 gGiCaptainsHatHoodTex[];
extern u64 gGiCaptainsHatHandTex[];
extern u64 gGiCaptainsHatArmTex[];
extern u64 gGiCaptainsHatRibTex[];
extern u64 gGiCaptainsHatFaceTex[];
#endif
