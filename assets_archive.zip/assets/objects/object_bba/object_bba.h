#ifndef OBJECT_BBA_H
#define OBJECT_BBA_H 1

typedef enum BombShopLadyLimb {
    /* 0x00 */ BOMB_SHOP_LADY_LIMB_NONE,
    /* 0x01 */ BOMB_SHOP_LADY_LIMB_UPPER_LEGS,
    /* 0x02 */ BOMB_SHOP_LADY_LIMB_MIDDLE_LEGS,
    /* 0x03 */ BOMB_SHOP_LADY_LIMB_LOWER_LEGS,
    /* 0x04 */ BOMB_SHOP_LADY_LIMB_FEET,
    /* 0x05 */ BOMB_SHOP_LADY_LIMB_UPPER_ROOT,
    /* 0x06 */ BOMB_SHOP_LADY_LIMB_NECK,
    /* 0x07 */ BOMB_SHOP_LADY_LIMB_HEAD,
    /* 0x08 */ BOMB_SHOP_LADY_LIMB_BAG,
    /* 0x09 */ BOMB_SHOP_LADY_LIMB_TORSO,
    /* 0x0A */ BOMB_SHOP_LADY_LIMB_LEFT_UPPER_ARM,
    /* 0x0B */ BOMB_SHOP_LADY_LIMB_LEFT_LOWER_ARM_ROOT,
    /* 0x0C */ BOMB_SHOP_LADY_LIMB_LEFT_FOREARM,
    /* 0x0D */ BOMB_SHOP_LADY_LIMB_LEFT_HAND,
    /* 0x0E */ BOMB_SHOP_LADY_LIMB_RIGHT_UPPER_ARM,
    /* 0x0F */ BOMB_SHOP_LADY_LIMB_RIGHT_LOWER_ARM_ROOT,
    /* 0x10 */ BOMB_SHOP_LADY_LIMB_RIGHT_FOREARM,
    /* 0x11 */ BOMB_SHOP_LADY_LIMB_RIGHT_HAND,
    /* 0x12 */ BOMB_SHOP_LADY_LIMB_MAX
} BombShopLadyLimb;

extern Vtx object_bbaVtx_000000[];
extern Gfx gBombShopLadyUpperLegsDL[];
extern Gfx gBombShopLadyRightHandDL[];
extern Gfx gBombShopLadyRightForearmDL[];
extern Gfx gBombShopLadyRightUpperArmDL[];
extern Gfx gBombShopLadyLeftHandDL[];
extern Gfx gBombShopLadyLeftForearmDL[];
extern Gfx gBombShopLadyLeftUpperArmDL[];
extern Gfx gBombShopLadyTorsoDL[];
extern Gfx gBombShopLadyBagDL[];
extern Gfx gBombShopLadyNeckDL[];
extern Gfx gBombShopLadyHeadDL[];
extern Gfx gBombShopLadyMiddleLegsDL[];
extern Gfx gBombShopLadyLowerLegsDL[];
extern Gfx gBombShopLadyFeetDL[];
extern s16 sBombShopLadySwayAnimFrameData[];
extern JointIndex sBombShopLadySwayAnimJointIndices[];
extern AnimationHeader gBombShopLadySwayAnim;
extern s16 sBombShopLadyKnockedOverAnimFrameData[];
extern JointIndex sBombShopLadyKnockedOverAnimJointIndices[];
extern AnimationHeader gBombShopLadyKnockedOverAnim;
extern s16 sBombShopLadyLyingDownAnimFrameData[];
extern JointIndex sBombShopLadyLyingDownAnimJointIndices[];
extern AnimationHeader gBombShopLadyLyingDownAnim;
extern s16 sBombShopLadyIdleHoldingBagAnimFrameData[];
extern JointIndex sBombShopLadyIdleHoldingBagAnimJointIndices[];
extern AnimationHeader gBombShopLadyIdleHoldingBagAnim;
extern StandardLimb gBombShopLadyUpperLegsLimb;
extern StandardLimb gBombShopLadyMiddleLegsLimb;
extern StandardLimb gBombShopLadyLowerLegsLimb;
extern StandardLimb gBombShopLadyFeetLimb;
extern StandardLimb gBombShopLadyUpperRootLimb;
extern StandardLimb gBombShopLadyNeckLimb;
extern StandardLimb gBombShopLadyHeadLimb;
extern StandardLimb gBombShopLadyBagLimb;
extern StandardLimb gBombShopLadyTorsoLimb;
extern StandardLimb gBombShopLadyLeftUpperArmLimb;
extern StandardLimb gBombShopLadyLeftLowerArmRootLimb;
extern StandardLimb gBombShopLadyLeftForearmLimb;
extern StandardLimb gBombShopLadyLeftHandLimb;
extern StandardLimb gBombShopLadyRightUpperArmLimb;
extern StandardLimb gBombShopLadyRightLowerArmRootLimb;
extern StandardLimb gBombShopLadyRightForearmLimb;
extern StandardLimb gBombShopLadyRightHandLimb;
extern void* gBombShopLadySkelLimbs[];
extern FlexSkeletonHeader gBombShopLadySkel;
extern s16 sBombShopLadyIdleAnimFrameData[];
extern JointIndex sBombShopLadyIdleAnimJointIndices[];
extern AnimationHeader gBombShopLadyIdleAnim;
extern s16 sBombShopLadyWalkingHoldingBagAnimFrameData[];
extern JointIndex sBombShopLadyWalkingHoldingBagAnimJointIndices[];
extern AnimationHeader gBombShopLadyWalkingHoldingBagAnim;
extern u64 gBombShopLadyTLUT[];
extern u64 gBombShopLadyHairSkin2Tex[];
extern u64 gBombShopLadyEar2Tex[];
extern u64 gBombShopLadyNostril2Tex[];
extern u64 gBombShopLadyEye2Tex[];
extern u64 gBombShopLadyWrinkles2Tex[];
extern u64 gBombShopLadyCheek2Tex[];
extern u64 gBombShopLadySkin2Tex[];
extern u64 gBombShopLadyForehead2Tex[];
extern u64 gBombShopLadyFingers2Tex[];
extern u64 gBombShopLadyShirt2Tex[];
extern u64 gBombShopLadyBag2Tex[];
extern u64 gBombShopLadySkirt2Tex[];
extern u64 gBombShopLadySkinTex[];
extern u64 gBombShopLadyWrinklesTex[];
extern u64 gBombShopLadyHairSkinTex[];
extern u64 gBombShopLadyNostrilTex[];
extern u64 gBombShopLadyEarTex[];
extern u64 gBombShopLadyFingersTex[];
extern u64 gBombShopLadyBagTex[];
extern u64 gBombShopLadySkirtTex[];
extern u64 gBombShopLadyEyeTex[];
extern u64 gBombShopLadyCheekTex[];
extern u64 gBombShopLadyForeheadTex[];
extern u64 gBombShopLadyShirtTex[];
#endif
