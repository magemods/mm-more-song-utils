#ifndef OBJECT_CHA_H
#define OBJECT_CHA_H 1

extern Vtx object_chaVtx_000000[];
extern Gfx object_cha_DL_000710[];
extern Gfx object_cha_DL_000958[];
extern u64 object_cha_TLUT_000B08[];
extern u64 object_cha_Tex_000D08[];
extern u64 object_cha_Tex_001108[];
extern u64 object_cha_Tex_001508[];
extern u64 object_cha_Tex_001608[];
extern u64 object_cha_Tex_001A08[];
#endif
