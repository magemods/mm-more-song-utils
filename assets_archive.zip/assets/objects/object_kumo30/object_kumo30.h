#ifndef OBJECT_KUMO30_H
#define OBJECT_KUMO30_H 1

extern Vtx object_kumo30Vtx_000000[];
extern Gfx object_kumo30_DL_000A50[];
extern Gfx object_kumo30_DL_000C98[];
extern u64 object_kumo30_Tex_000E80[];
extern u64 object_kumo30_Tex_001E80[];
extern u64 object_kumo30_Tex_002080[];
extern AnimatedMatTexScrollParams object_kumo30_Matanimheader_002890TexScrollParams_002880[];
extern AnimatedMatTexScrollParams object_kumo30_Matanimheader_002890TexScrollParams_002888[];
extern AnimatedMaterial object_kumo30_Matanimheader_002890[];
extern Vtx object_kumo30Vtx_0028A0[];
extern Gfx object_kumo30_DL_002A40[];
extern u64 object_kumo30_Tex_002B58[];
extern u64 object_kumo30_Tex_002F58[];
extern AnimatedMatTexScrollParams object_kumo30_Matanimheader_003368TexScrollParams_003360[];
extern AnimatedMaterial object_kumo30_Matanimheader_003368[];
#endif
