#ifndef OBJECT_MASK_NUTS_H
#define OBJECT_MASK_NUTS_H 1

extern u64 object_mask_nuts_Tex_000000[];
extern u64 object_mask_nuts_Tex_000800[];
extern u64 object_mask_nuts_Tex_000A00[];
extern Vtx object_mask_nutsVtx_001200[];
extern Gfx object_mask_nuts_DL_001D90[];
#endif
