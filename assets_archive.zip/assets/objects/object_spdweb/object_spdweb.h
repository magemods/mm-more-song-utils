#ifndef OBJECT_SPDWEB_H
#define OBJECT_SPDWEB_H 1

extern Vtx object_spdwebVtx_000000[];
extern Gfx object_spdweb_DL_000060[];
extern Gfx object_spdweb_DL_000130[];
extern u64 object_spdweb_Tex_000138[];
extern u64 object_spdweb_Tex_000938[];
extern BgCamInfo object_spdweb_Colheader_0011C0CamDataList[];
extern SurfaceType object_spdweb_Colheader_0011C0SurfaceType[];
extern CollisionPoly object_spdweb_Colheader_0011C0Polygons[];
extern Vec3s object_spdweb_Colheader_0011C0Vertices[];
extern CollisionHeader object_spdweb_Colheader_0011C0;
extern Vtx object_spdwebVtx_0011F0[];
extern Gfx object_spdweb_DL_0012F0[];
extern Gfx object_spdweb_DL_001400[];
extern u64 object_spdweb_Tex_001408[];
extern BgCamInfo object_spdweb_Colheader_002678CamDataList[];
extern SurfaceType object_spdweb_Colheader_002678SurfaceType[];
extern CollisionPoly object_spdweb_Colheader_002678Polygons[];
extern Vec3s object_spdweb_Colheader_002678Vertices[];
extern CollisionHeader object_spdweb_Colheader_002678;
#endif
