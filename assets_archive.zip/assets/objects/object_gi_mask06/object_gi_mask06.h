#ifndef OBJECT_GI_MASK06_H
#define OBJECT_GI_MASK06_H 1

extern Vtx object_gi_mask06Vtx_000000[];
extern Gfx gGiAllNightMaskFaceDL[];
extern Gfx gGiAllNightMaskEyesDL[];
extern u64 gGiAllNightMaskEyeTLUT[];
extern u64 gGiAllNightMaskEyeTex[];
extern u64 gGiAllNightMaskFacePattern1Tex[];
extern u64 gGiAllNightMaskFacePattern2Tex[];
#endif
