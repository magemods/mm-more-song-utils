#ifndef OBJECT_LODMOON_H
#define OBJECT_LODMOON_H 1

extern Vtx object_lodmoonVtx_000000[];
extern Gfx gLodmoonEyesDL[];
extern Gfx gLodmoonMoonDL[];
extern u64 gLodmoonFaceTLUT[];
extern u64 gLodmoonFarSideTLUT[];
extern u64 gLodmoonEyesTex[];
extern u64 gLodmoonTeethTex[];
extern u64 gLodmoonFaceTex[];
extern u64 gLodmoonFarSideTex[];
#endif
