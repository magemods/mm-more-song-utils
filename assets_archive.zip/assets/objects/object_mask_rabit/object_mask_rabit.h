#ifndef OBJECT_MASK_RABIT_H
#define OBJECT_MASK_RABIT_H 1

extern Vtx object_mask_rabitVtx_000000[];
extern Gfx object_mask_rabit_DL_000610[];
extern u64 object_mask_rabit_Tex_0009A0[];
extern u64 object_mask_rabit_Tex_000BA0[];
extern u64 object_mask_rabit_Tex_000FA0[];
#endif
