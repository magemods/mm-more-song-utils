#ifndef OBJECT_GI_MASK12_H
#define OBJECT_GI_MASK12_H 1

extern Vtx object_gi_mask12Vtx_000000[];
extern Gfx gGiPostmanHatBunnyLogoDL[];
extern Gfx gGiPostmanHatCapDL[];
extern u64 gGiPostmanHatBunnyLogoTex[];
extern u64 gGiPostmanHatCapTex[];
#endif
