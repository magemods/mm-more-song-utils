#ifndef OBJECT_GI_MASK09_H
#define OBJECT_GI_MASK09_H 1

extern Vtx object_gi_mask09Vtx_000000[];
extern Gfx gGiGarosMaskFaceDL[];
extern Gfx gGiGarosMaskCloakDL[];
extern u64 gGiGarosMaskCloakTLUT[];
extern u64 gGiGarosMaskEyeTex[];
extern u64 gGiGarosMaskUpperSidePatternTex[];
extern u64 gGiGarosMaskFrontPatternTex[];
extern u64 gGiGarosMaskLowerSidePatternTex[];
extern u64 gGiGarosMaskTopPatternTex[];
#endif
