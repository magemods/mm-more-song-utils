#ifndef OBJECT_MASK_GORON_H
#define OBJECT_MASK_GORON_H 1

extern u64 object_mask_goron_TLUT_000000[];
extern u64 object_mask_goron_Tex_000200[];
extern u64 object_mask_goron_Tex_000A00[];
extern u64 object_mask_goron_Tex_000A40[];
extern u64 object_mask_goron_Tex_000B40[];
extern Vtx object_mask_goronVtx_000F40[];
extern Gfx object_mask_goron_DL_0014A0[];
#endif
