#ifndef OBJECT_MASK_ZORA_H
#define OBJECT_MASK_ZORA_H 1

extern u64 object_mask_zora_TLUT_000000[];
extern u64 object_mask_zora_Tex_000200[];
extern u64 object_mask_zora_Tex_000600[];
extern u64 object_mask_zora_Tex_000800[];
extern u64 object_mask_zora_Tex_000840[];
extern Vtx object_mask_zoraVtx_000A40[];
extern Gfx object_mask_zora_DL_000DB0[];
#endif
