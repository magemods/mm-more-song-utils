#ifndef OBJECT_KINSTA2_OBJ_H
#define OBJECT_KINSTA2_OBJ_H 1

extern Vtx object_kinsta2_objVtx_000000[];
extern Gfx gOceansideSpiderHouseDoorDL[];
extern u64 gOceansideSpiderHouseDoorTex[];
#endif
