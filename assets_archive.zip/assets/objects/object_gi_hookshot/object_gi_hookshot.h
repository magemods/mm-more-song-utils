#ifndef OBJECT_GI_HOOKSHOT_H
#define OBJECT_GI_HOOKSHOT_H 1

extern Vtx object_gi_hookshotVtx_000000[];
extern Gfx gGiHookshotDL[];
extern Gfx gGiHookshotEmptyDL[];
extern u64 gGiHookshot1Tex[];
extern u64 gGiHookshot2Tex[];
#endif
