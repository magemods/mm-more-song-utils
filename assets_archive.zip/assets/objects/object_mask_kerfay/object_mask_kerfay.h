#ifndef OBJECT_MASK_KERFAY_H
#define OBJECT_MASK_KERFAY_H 1

extern Vtx object_mask_kerfayVtx_000000[];
extern Gfx gKafeisMaskDL[];
extern u64 gKafeisMaskTLUT[];
extern u64 gKafeisMaskHoleTex[];
extern u64 gKafeisMaskHairTex[];
extern u64 gKafeisMaskHairPartAndUndersideTex[];
extern u64 gKafeisMaskEyebrowTex[];
#endif
