#ifndef OBJECT_MASK_KI_TAN_H
#define OBJECT_MASK_KI_TAN_H 1

extern Vtx object_mask_ki_tanVtx_000000[];
extern Gfx object_mask_ki_tan_DL_0004A0[];
extern u64 object_mask_ki_tan_TLUT_000688[];
extern u64 object_mask_ki_tan_Tex_000888[];
extern u64 object_mask_ki_tan_Tex_000A88[];
#endif
