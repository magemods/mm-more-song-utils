#ifndef OBJECT_MBAR_OBJ_H
#define OBJECT_MBAR_OBJ_H 1

extern Vtx object_mbar_objVtx_000000[];
extern Gfx object_mbar_obj_DL_000280[];
extern Gfx object_mbar_obj_DL_000288[];
extern u64 object_mbar_obj_Tex_000408[];
extern u64 object_mbar_obj_Tex_000C08[];
extern u64 object_mbar_obj_Tex_001008[];
extern BgCamInfo object_mbar_obj_Colheader_0019B4CamDataList[];
extern SurfaceType object_mbar_obj_Colheader_0019B4SurfaceType[];
extern CollisionPoly object_mbar_obj_Colheader_0019B4Polygons[];
extern Vec3s object_mbar_obj_Colheader_0019B4Vertices[];
extern CollisionHeader object_mbar_obj_Colheader_0019B4;
#endif
