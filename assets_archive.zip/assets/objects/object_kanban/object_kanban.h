#ifndef OBJECT_KANBAN_H
#define OBJECT_KANBAN_H 1

extern Vtx object_kanbanVtx_000000[];
extern Gfx gSignMaterialDL[];
extern Gfx gSignUpperSideLeftModelDL[];
extern Gfx gSignLeftSideUpperModelDL[];
extern Gfx gSignLeftSideLowerModelDL[];
extern Gfx gSignRightSideUpperModelDL[];
extern Gfx gSignRightSideLowerModelDL[];
extern Gfx gSignLowerSideLeftModelDL[];
extern Gfx gSignUpperSideRightModelDL[];
extern Gfx gSignLowerSideRightModelDL[];
extern Gfx gSignPostUpperModelDL[];
extern Gfx gSignPostLowerModelDL[];
extern Gfx gSignPostStandModelDL[];
extern Vtx object_kanbanVtx_001600[];
extern Gfx gSignParticleDL[];
extern u64 gSignParticleTex[];
#endif
