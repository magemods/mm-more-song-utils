#ifndef OBJECT_OMOYA_OBJ_H
#define OBJECT_OMOYA_OBJ_H 1

extern Vtx object_omoya_objVtx_000000[];
extern Gfx object_omoya_obj_DL_0001A0[];
extern u64 object_omoya_obj_TLUT_0002D8[];
extern u64 object_omoya_obj_Tex_0002F8[];
extern u64 object_omoya_obj_Tex_0012F8[];
#endif
