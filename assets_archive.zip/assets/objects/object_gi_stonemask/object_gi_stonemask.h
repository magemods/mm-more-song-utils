#ifndef OBJECT_GI_STONEMASK_H
#define OBJECT_GI_STONEMASK_H 1

extern Vtx object_gi_stonemaskVtx_000000[];
extern Gfx gGiStoneMaskDL[];
extern Gfx gGiStoneMaskEmptyDL[];
extern u64 gGiStoneMaskFaceTex[];
extern u64 gGiStoneMaskEyeTex[];
#endif
