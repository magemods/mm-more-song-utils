#ifndef OBJECT_GI_MASK22_H
#define OBJECT_GI_MASK22_H 1

extern Vtx object_gi_mask22Vtx_000000[];
extern Gfx gGiMaskOfScentsTeethDL[];
extern Gfx gGiMaskOfScentsFaceDL[];
extern u64 gGiMaskOfScentsTLUT[];
extern u64 gGiMaskOfScentsSpotTex[];
extern u64 gGiMaskOfScentsEyeShadowTex[];
extern u64 gGiMaskOfScentsNostrilTex[];
extern u64 gGiMaskOfScentsMouthTex[];
extern u64 gGiMaskOfScentsEyeTex[];
extern u64 gGiMaskOfScentsToothTex[];
#endif
