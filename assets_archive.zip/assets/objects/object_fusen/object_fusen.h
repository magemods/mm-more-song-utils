#ifndef OBJECT_FUSEN_H
#define OBJECT_FUSEN_H 1

extern Vtx object_fusenVtx_000000[];
extern Gfx gMajoraBalloonDL[];
extern Gfx gMajoraBalloonKnotDL[];
extern u64 object_fusen_Tex_000E08[];
extern BgCamInfo object_fusen_Colheader_002420CamDataList[];
extern SurfaceType object_fusen_Colheader_002420SurfaceType[];
extern CollisionPoly object_fusen_Colheader_002420Polygons[];
extern Vec3s object_fusen_Colheader_002420Vertices[];
extern CollisionHeader object_fusen_Colheader_002420;
#endif
