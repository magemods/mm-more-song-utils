#ifndef OBJECT_SPIDERTENT_H
#define OBJECT_SPIDERTENT_H 1

extern Vtx object_spidertentVtx_000000[];
extern Gfx object_spidertent_DL_000070[];
extern Gfx object_spidertent_DL_000108[];
extern u64 object_spidertent_Tex_000110[];
extern BgCamInfo object_spidertent_Colheader_0011ACCamDataList[];
extern SurfaceType object_spidertent_Colheader_0011ACSurfaceType[];
extern CollisionPoly object_spidertent_Colheader_0011ACPolygons[];
extern Vec3s object_spidertent_Colheader_0011ACVertices[];
extern CollisionHeader object_spidertent_Colheader_0011AC;
extern Vtx object_spidertentVtx_0011E0[];
extern Gfx object_spidertent_DL_001250[];
extern Gfx object_spidertent_DL_0012E8[];
extern u64 object_spidertent_Tex_0012F0[];
extern BgCamInfo object_spidertent_Colheader_00238CCamDataList[];
extern SurfaceType object_spidertent_Colheader_00238CSurfaceType[];
extern CollisionPoly object_spidertent_Colheader_00238CPolygons[];
extern Vec3s object_spidertent_Colheader_00238CVertices[];
extern CollisionHeader object_spidertent_Colheader_00238C;
#endif
