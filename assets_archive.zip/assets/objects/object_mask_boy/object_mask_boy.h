#ifndef OBJECT_MASK_BOY_H
#define OBJECT_MASK_BOY_H 1

extern Vtx object_mask_boyVtx_000000[];
extern Gfx object_mask_boy_DL_000900[];
extern u64 object_mask_boy_TLUT_000D50[];
extern u64 object_mask_boy_Tex_000F50[];
extern u64 object_mask_boy_Tex_001350[];
extern u64 object_mask_boy_Tex_001B50[];
extern u64 object_mask_boy_Tex_001F50[];
extern u64 object_mask_boy_Tex_002050[];
#endif
