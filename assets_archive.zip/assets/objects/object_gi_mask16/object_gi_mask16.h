#ifndef OBJECT_GI_MASK16_H
#define OBJECT_GI_MASK16_H 1

extern Vtx object_gi_mask16Vtx_000000[];
extern Gfx gGiDonGeroMaskBodyDL[];
extern Gfx gGiDonGeroMaskFaceDL[];
extern u64 gGiDonGeroMaskToesTex[];
extern u64 gGiDonGeroMaskFrillsTex[];
extern u64 gGiDonGeroMaskEyeTex[];
extern u64 gGiDonGeroMaskNostrilTex[];
extern u64 gGiDonGeroMaskMouthTex[];
#endif
