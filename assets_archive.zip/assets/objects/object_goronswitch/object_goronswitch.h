#ifndef OBJECT_GORONSWITCH_H
#define OBJECT_GORONSWITCH_H 1

extern Vtx object_goronswitchVtx_000000[];
extern Gfx object_goronswitch_DL_000260[];
extern Gfx object_goronswitch_DL_000268[];
extern BgCamInfo object_goronswitch_Colheader_0005C8CamDataList[];
extern SurfaceType object_goronswitch_Colheader_0005C8SurfaceType[];
extern CollisionPoly object_goronswitch_Colheader_0005C8Polygons[];
extern Vec3s object_goronswitch_Colheader_0005C8Vertices[];
extern CollisionHeader object_goronswitch_Colheader_0005C8;
extern Vtx object_goronswitchVtx_000600[];
extern Gfx object_goronswitch_DL_0007D0[];
extern Gfx object_goronswitch_DL_0007D8[];
extern u64 object_goronswitch_TLUT_000970[];
extern u64 object_goronswitch_TLUT_000990[];
extern u64 object_goronswitch_Tex_0009B0[];
extern u64 object_goronswitch_Tex_0019B0[];
extern u64 object_goronswitch_Tex_0021B0[];
#endif
