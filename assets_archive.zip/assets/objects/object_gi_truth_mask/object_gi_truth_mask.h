#ifndef OBJECT_GI_TRUTH_MASK_H
#define OBJECT_GI_TRUTH_MASK_H 1

extern u64 gGiMaskOfTruthEyebrowTriangleTex[];
extern u64 gGiMaskOfTruthSideEtchingTex[];
extern Vtx object_gi_truth_maskVtx_000800[];
extern Gfx gGiMaskOfTruthDL[];
extern Gfx gGiMaskOfTruthAccentsDL[];
#endif
