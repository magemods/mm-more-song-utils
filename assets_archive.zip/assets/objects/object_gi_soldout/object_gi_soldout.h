#ifndef OBJECT_GI_SOLDOUT_H
#define OBJECT_GI_SOLDOUT_H 1

extern u64 gGiSoldOutTex[];
extern Vtx object_gi_soldoutVtx_000400[];
extern Gfx gGiSoldOutDL[];
#endif
