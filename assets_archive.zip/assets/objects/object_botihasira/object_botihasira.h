#ifndef OBJECT_BOTIHASIRA_H
#define OBJECT_BOTIHASIRA_H 1

extern Vtx object_botihasiraVtx_000000[];
extern Gfx object_botihasira_DL_0004A0[];
extern Gfx object_botihasira_DL_000628[];
extern Gfx object_botihasira_DL_000638[];
extern u64 object_botihasira_Tex_000648[];
extern u64 object_botihasira_Tex_001648[];
extern AnimatedMaterial object_botihasira_Matanimheader_001A48[];
extern BgCamInfo object_botihasira_Colheader_001BD8CamDataList[];
extern SurfaceType object_botihasira_Colheader_001BD8SurfaceType[];
extern CollisionPoly object_botihasira_Colheader_001BD8Polygons[];
extern Vec3s object_botihasira_Colheader_001BD8Vertices[];
extern CollisionHeader object_botihasira_Colheader_001BD8;
#endif
