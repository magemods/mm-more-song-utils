#ifndef OBJECT_SNOWWD_H
#define OBJECT_SNOWWD_H 1

extern Vtx object_snowwdVtx_000000[];
extern Gfx gSnowTreeEmptyDL[];
extern Gfx gSnowTreeDL[];
extern u64 gSnowTreeLeavesTex[];
extern u64 gSnowTreeBodyTex[];
extern u64 gSnowTreeSnowLeavesTex[];
#endif
