#ifndef OBJECT_OBJ_DANPEILIFT_H
#define OBJECT_OBJ_DANPEILIFT_H 1

extern Vtx object_obj_danpeiliftVtx_000000[];
extern Gfx object_obj_danpeilift_DL_000180[];
extern u64 object_obj_danpeilift_Tex_000298[];
extern BgCamInfo object_obj_danpeilift_Colheader_000BA0CamDataList[];
extern SurfaceType object_obj_danpeilift_Colheader_000BA0SurfaceType[];
extern CollisionPoly object_obj_danpeilift_Colheader_000BA0Polygons[];
extern Vec3s object_obj_danpeilift_Colheader_000BA0Vertices[];
extern CollisionHeader object_obj_danpeilift_Colheader_000BA0;
#endif
