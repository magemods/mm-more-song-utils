#ifndef OBJECT_GI_BIGBOMB_H
#define OBJECT_GI_BIGBOMB_H 1

extern Vtx object_gi_bigbombVtx_000000[];
extern Gfx gGiPowderKegGoronSkullAndFuseDL[];
extern Gfx gGiPowderKegBarrelDL[];
extern u64 gGiPowderKegBarrelTLUT[];
extern u64 gGiPowderKegGoronSkullTex[];
extern u64 gGiPowderKegBarrelTex[];
extern u64 gGiPowderKegFuseTex[];
#endif
