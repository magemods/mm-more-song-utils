#ifndef OBJECT_GI_BOW_H
#define OBJECT_GI_BOW_H 1

extern Vtx object_gi_bowVtx_000000[];
extern Gfx gGiBowHandleDL[];
extern Gfx gGiBowStringDL[];
extern u64 gGiBowHandleTex[];
extern u64 gGiBowStringTex[];
#endif
