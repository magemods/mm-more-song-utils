#ifndef OBJECT_KIBAKO_H
#define OBJECT_KIBAKO_H 1

extern u64 gSmallCrateTex[];
extern Vtx object_kibakoVtx_001000[];
extern Gfx gSmallCrateDL[];
extern u64 gSmallCrateFragmentTex[];
extern Vtx object_kibakoVtx_001A40[];
extern Gfx gSmallCrateFragmentDL[];
#endif
