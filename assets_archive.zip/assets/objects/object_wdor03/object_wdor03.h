#ifndef OBJECT_WDOR03_H
#define OBJECT_WDOR03_H 1

extern Vtx object_wdor03Vtx_000000[];
extern Gfx gInnSchoolDoorEmptyDL[];
extern Gfx gInnSchoolDoorDL[];
extern u64 gInnScoolDoorTex[];
#endif
