#ifndef OBJECT_GI_RESERVE01_H
#define OBJECT_GI_RESERVE01_H 1

extern Vtx object_gi_reserve01Vtx_000000[];
extern Gfx gGiTitleDeedSealAndRibbonDL[];
extern Gfx gGiTitleDeedPaperDL[];
extern Gfx gGiTitleDeedLandColorDL[];
extern Gfx gGiTitleDeedSwampColorDL[];
extern Gfx gGiTitleDeedMountainColorDL[];
extern Gfx gGiTitleDeedOceanColorDL[];
extern Gfx gGiTitleDeedEmptyDL[];
extern u64 gGiTitleDeedRightInscriptionsTex[];
extern u64 gGiTitleDeedLeftInscriptionsTex[];
extern u64 gGiTitleDeedSealAndRibbonTex[];
#endif
