#ifndef OBJECT_GI_MASK23_H
#define OBJECT_GI_MASK23_H 1

extern Vtx object_gi_mask23Vtx_000000[];
extern Gfx gGiGiantMaskDL[];
extern Gfx gGiGiantMaskEmptyDL[];
extern u64 gGiGiantMaskEyeTex[];
extern u64 gGiGiantMaskMouthTex[];
#endif
