#ifndef OBJECT_GI_MASK10_H
#define OBJECT_GI_MASK10_H 1

extern Vtx object_gi_mask10Vtx_000000[];
extern Gfx gGiRomaniMaskNoseEyeDL[];
extern Gfx gGiRomaniMaskCapDL[];
extern u64 gGiRomaniMaskSpotsTex[];
extern u64 gGiRomaniMaskPlainTex[];
extern u64 gGiRomaniMaskNoseTex[];
extern u64 gGiRomaniMaskEyeTex[];
#endif
