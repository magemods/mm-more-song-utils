#ifndef OBJECT_OBJ_USIYANE_H
#define OBJECT_OBJ_USIYANE_H 1

extern Vtx object_obj_usiyaneVtx_000000[];
extern Gfx object_obj_usiyane_DL_000090[];
extern Gfx object_obj_usiyane_DL_000098[];
extern u64 object_obj_usiyane_Tex_000130[];
extern Vtx object_obj_usiyaneVtx_000530[];
extern Gfx object_obj_usiyane_DL_000830[];
extern Gfx object_obj_usiyane_DL_000838[];
extern u64 object_obj_usiyane_TLUT_0009C8[];
extern u64 object_obj_usiyane_Tex_0009E8[];
extern u64 object_obj_usiyane_Tex_0011E8[];
extern BgCamInfo object_obj_usiyane_Colheader_0022ACCamDataList[];
extern SurfaceType object_obj_usiyane_Colheader_0022ACSurfaceType[];
extern CollisionPoly object_obj_usiyane_Colheader_0022ACPolygons[];
extern Vec3s object_obj_usiyane_Colheader_0022ACVertices[];
extern CollisionHeader object_obj_usiyane_Colheader_0022AC;
#endif
