#ifndef OBJECT_LASTDAY_H
#define OBJECT_LASTDAY_H 1

extern Vtx object_lastday_Vtx_000000[];
extern Gfx object_lastday_DL_000060[];
extern AnimatedMatTexScrollParams object_lastday_Matanimheader_000148TexScrollParams_000140[];
extern AnimatedMaterial object_lastday_Matanimheader_000148[];
extern Vtx object_lastdayVtx_000150[];
extern Gfx object_lastday_DL_000210[];
extern AnimatedMatTexScrollParams object_lastday_Matanimheader_000308TexScrollParams_000300[];
extern AnimatedMaterial object_lastday_Matanimheader_000308[];
extern Vtx object_lastdayVtx_000310[];
extern Gfx object_lastday_DL_000370[];
extern AnimatedMatTexScrollParams object_lastday_Matanimheader_000448TexScrollParams_000440[];
extern AnimatedMaterial object_lastday_Matanimheader_000448[];
extern Vtx object_lastdayVtx_000450[];
extern Gfx object_lastday_DL_000510[];
extern AnimatedMatTexScrollParams object_lastday_Matanimheader_000608TexScrollParams_000600[];
extern AnimatedMaterial object_lastday_Matanimheader_000608[];
extern u64 object_lastday_Tex_000610[];
extern u64 object_lastday_Tex_000E10[];
extern u64 object_lastday_Tex_001610[];
extern u64 object_lastday_Tex_001E10[];
extern u64 object_lastday_Tex_002210[];
#endif
