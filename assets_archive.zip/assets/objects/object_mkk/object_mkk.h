#ifndef OBJECT_MKK_H
#define OBJECT_MKK_H 1

extern Vtx object_mkkVtx_000000[];
extern Gfx gBlackBoeBodyMaterialDL[];
extern Gfx gBlackBoeBodyModelDL[];
extern Gfx gBlackBoeEndDL[];
extern Vtx object_mkkVtx_0000E0[];
extern Gfx gBlackBoeEyesDL[];
extern Vtx object_mkkVtx_0001C0[];
extern Gfx gWhiteBoeBodyMaterialDL[];
extern Gfx gWhiteBoeBodyModelDL[];
extern Gfx gWhiteBoeEndDL[];
extern Vtx object_mkkVtx_0002B0[];
extern Gfx gWhiteBoeEyesDL[];
extern u64 gBlackBoeTex[];
extern u64 gWhiteBoeTex[];
extern u64 gBoeEyeTex[];
#endif
