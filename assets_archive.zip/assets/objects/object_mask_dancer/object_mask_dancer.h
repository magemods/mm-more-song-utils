#ifndef OBJECT_MASK_DANCER_H
#define OBJECT_MASK_DANCER_H 1

extern Vtx object_mask_dancerVtx_000000[];
extern Gfx object_mask_dancer_DL_000EF0[];
extern u64 object_mask_dancer_TLUT_001548[];
extern u64 object_mask_dancer_Tex_001748[];
extern u64 object_mask_dancer_Tex_001848[];
extern u64 object_mask_dancer_Tex_001888[];
extern u64 object_mask_dancer_Tex_001988[];
extern u64 object_mask_dancer_Tex_0019C8[];
extern u64 object_mask_dancer_Tex_001AC8[];
#endif
