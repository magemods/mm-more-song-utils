#ifndef OBJECT_GI_RESERVE_C_01_H
#define OBJECT_GI_RESERVE_C_01_H 1

extern Vtx object_gi_reserve_c_01Vtx_000000[];
extern Gfx gGiPendantOfMemoriesDL[];
extern Gfx gGiPendantOfMemoriesEmptyDL[];
extern u64 gGiPendantOfMemoriesBlankTex[];
extern u64 gGiPendantOfMemoriesBackgroundTex[];
#endif
