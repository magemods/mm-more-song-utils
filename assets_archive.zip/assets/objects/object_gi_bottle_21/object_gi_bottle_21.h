#ifndef OBJECT_GI_BOTTLE_21_H
#define OBJECT_GI_BOTTLE_21_H 1

extern Vtx object_gi_bottle_21Vtx_000000[];
extern Gfx gGiChateauRomaniBottleDL[];
extern Gfx gGiChateauRomaniBottleEmptyDL[];
extern u64 gGiChateauRomaniBottleCorkTex[];
extern u64 gGiChateauRomaniBottleLabelTex[];
extern u64 gGiChateauRomaniBottleGlassTex[];
#endif
