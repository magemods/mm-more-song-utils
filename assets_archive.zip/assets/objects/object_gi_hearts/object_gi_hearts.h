#ifndef OBJECT_GI_HEARTS_H
#define OBJECT_GI_HEARTS_H 1

extern Vtx object_gi_heartsVtx_000000[];
extern Gfx gGiHeartBorderDL[];
extern Gfx gGiHeartContainerDL[];
extern Gfx gGiHeartPieceDL[];
#endif
