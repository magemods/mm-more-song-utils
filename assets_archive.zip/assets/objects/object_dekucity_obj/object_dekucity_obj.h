#ifndef OBJECT_DEKUCITY_OBJ_H
#define OBJECT_DEKUCITY_OBJ_H 1

extern BgCamInfo object_dekucity_obj_Colheader_0002ACCamDataList[];
extern SurfaceType object_dekucity_obj_Colheader_0002ACCamPosData[];
extern CollisionPoly object_dekucity_obj_Colheader_0002ACPolygons[];
extern Vec3s object_dekucity_obj_Colheader_0002ACVertices[];
extern CollisionHeader object_dekucity_obj_Colheader_0002AC;
extern Vtx object_dekucity_objVtx_0002E0[];
extern Gfx object_dekucity_obj_DL_0004E0[];
extern Gfx object_dekucity_obj_DL_000610[];
extern u64 object_dekucity_obj_Tex_000618[];
extern AnimatedMatTexScrollParams object_dekucity_obj_Matanimheader_000E28TexScrollParams_000E20[];
extern AnimatedMaterial object_dekucity_obj_Matanimheader_000E28[];
extern Vtx object_dekucity_objVtx_000E30[];
extern Gfx object_dekucity_obj_DL_001030[];
extern Gfx object_dekucity_obj_DL_001160[];
extern u64 object_dekucity_obj_Tex_001168[];
extern AnimatedMatTexScrollParams object_dekucity_obj_Matanimheader_001978TexScrollParams_001970[];
extern AnimatedMaterial object_dekucity_obj_Matanimheader_001978[];
extern Vtx object_dekucity_objVtx_001980[];
extern Gfx object_dekucity_obj_DL_001D80[];
extern Gfx object_dekucity_obj_DL_001ED8[];
extern u64 object_dekucity_obj_Tex_002008[];
extern u64 object_dekucity_obj_Tex_002808[];
extern u64 object_dekucity_obj_Tex_003008[];
extern AnimatedMatTexScrollParams object_dekucity_obj_Matanimheader_003820TexScrollParams_003810[];
extern AnimatedMatTexScrollParams object_dekucity_obj_Matanimheader_003820TexScrollParams_003818[];
extern AnimatedMaterial object_dekucity_obj_Matanimheader_003820[];
extern Vtx object_dekucity_objVtx_003830[];
extern Gfx object_dekucity_obj_DL_003990[];
extern Gfx object_dekucity_obj_DL_003998[];
extern u64 object_dekucity_obj_Tex_003AC0[];
extern u64 object_dekucity_obj_Tex_003EC0[];
#endif
