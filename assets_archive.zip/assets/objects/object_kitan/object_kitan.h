#ifndef OBJECT_KITAN_H
#define OBJECT_KITAN_H 1

typedef enum KeatonLimb {
    /* 0x00 */ KEATON_LIMB_NONE,
    /* 0x01 */ KEATON_LIMB_LOWER_BODY,
    /* 0x02 */ KEATON_LIMB_UPPER_BODY,
    /* 0x03 */ KEATON_LIMB_HEAD,
    /* 0x04 */ KEATON_LIMB_LEFT_SHOULDER,
    /* 0x05 */ KEATON_LIMB_LEFT_ARM,
    /* 0x06 */ KEATON_LIMB_RIGHT_SHOULDER,
    /* 0x07 */ KEATON_LIMB_RIGHT_ARM,
    /* 0x08 */ KEATON_LIMB_RIGHT_LEG,
    /* 0x09 */ KEATON_LIMB_RIGHT_FOOT,
    /* 0x0A */ KEATON_LIMB_LEFT_LEG,
    /* 0x0B */ KEATON_LIMB_LEFT_FOOT,
    /* 0x0C */ KEATON_LIMB_RIGHT_TAIL_BASE,
    /* 0x0D */ KEATON_LIMB_RIGHT_TAIL_MID,
    /* 0x0E */ KEATON_LIMB_RIGHT_TAIL_END,
    /* 0x0F */ KEATON_LIMB_MIDDLE_TAIL_BASE,
    /* 0x10 */ KEATON_LIMB_MIDDLE_TAIL_MID,
    /* 0x11 */ KEATON_LIMB_MIDDLE_TAIL_END,
    /* 0x12 */ KEATON_LIMB_LEFT_TAIL_BASE,
    /* 0x13 */ KEATON_LIMB_LEFT_TAIL_MID,
    /* 0x14 */ KEATON_LIMB_LEFT_TAIL_END,
    /* 0x15 */ KEATON_LIMB_MAX
} KeatonLimb;

extern s16 sKeatonChuckleAnimFrameData[];
extern JointIndex sKeatonChuckleAnimJointIndices[];
extern AnimationHeader gKeatonChuckleAnim;
extern s16 sKeatonCelebrateAnimFrameData[];
extern JointIndex sKeatonCelebrateAnimJointIndices[];
extern AnimationHeader gKeatonCelebrateAnim;
extern s16 sKeatonIdleAnimFrameData[];
extern JointIndex sKeatonIdleAnimJointIndices[];
extern AnimationHeader gKeatonIdleAnim;
extern Vtx object_kitanVtx_002780[];
extern Gfx object_kitan_DL_004C40[];
extern Gfx object_kitan_DL_004DF0[];
extern Gfx object_kitan_DL_005160[];
extern Gfx object_kitan_DL_005628[];
extern Gfx object_kitan_DL_005928[];
extern Gfx object_kitan_DL_005B48[];
extern Gfx object_kitan_DL_005E48[];
extern Gfx object_kitan_DL_006068[];
extern Gfx object_kitan_DL_0063E8[];
extern Gfx object_kitan_DL_0065E0[];
extern Gfx object_kitan_DL_0066A8[];
extern Gfx object_kitan_DL_006810[];
extern Gfx object_kitan_DL_006990[];
extern Gfx object_kitan_DL_006A58[];
extern Gfx object_kitan_DL_006BC0[];
extern Gfx object_kitan_DL_006D40[];
extern Gfx object_kitan_DL_006E08[];
extern Gfx object_kitan_DL_006F70[];
extern Gfx object_kitan_DL_0070F0[];
extern Gfx object_kitan_DL_007470[];
extern u64 object_kitan_TLUT_007668[];
extern u64 object_kitan_Tex_007868[];
extern u64 object_kitan_Tex_007A68[];
extern u64 object_kitan_Tex_007B68[];
extern u64 object_kitan_Tex_007C68[];
extern u64 object_kitan_Tex_007D68[];
extern StandardLimb gKeatonLowerBodyLimb;
extern StandardLimb gKeatonUpperBodyLimb;
extern StandardLimb gKeatonHeadLimb;
extern StandardLimb gKeatonLeftShoulderLimb;
extern StandardLimb gKeatonLeftArmLimb;
extern StandardLimb gKeatonRightShoulderLimb;
extern StandardLimb gKeatonRightArmLimb;
extern StandardLimb gKeatonRightLegLimb;
extern StandardLimb gKeatonRightFootLimb;
extern StandardLimb gKeatonLeftLegLimb;
extern StandardLimb gKeatonLeftFootLimb;
extern StandardLimb gKeatonRightTailBaseLimb;
extern StandardLimb gKeatonRightTailMidLimb;
extern StandardLimb gKeatonRightTailEndLimb;
extern StandardLimb gKeatonMiddleTailBaseLimb;
extern StandardLimb gKeatonMiddleTailMidLimb;
extern StandardLimb gKeatonMiddleTailEndLimb;
extern StandardLimb gKeatonLeftTailBaseLimb;
extern StandardLimb gKeatonLeftTailMidLimb;
extern StandardLimb gKeatonLeftTailEndLimb;
extern void* gKeatonSkelLimbs[];
extern FlexSkeletonHeader gKeatonSkel;
#endif
