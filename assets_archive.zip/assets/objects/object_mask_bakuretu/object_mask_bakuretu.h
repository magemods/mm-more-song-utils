#ifndef OBJECT_MASK_BAKURETU_H
#define OBJECT_MASK_BAKURETU_H 1

extern Vtx object_mask_bakuretuVtx_000000[];
extern Gfx object_mask_bakuretu_DL_000440[];
extern Gfx object_mask_bakuretu_DL_0005C0[];
extern u64 object_mask_bakuretu_Tex_0007B0[];
extern u64 object_mask_bakuretu_Tex_000BB0[];
extern u64 object_mask_bakuretu_Tex_000BF0[];
extern u64 object_mask_bakuretu_Tex_000DF0[];
extern AnimatedMatTexScrollParams object_mask_bakuretu_Matanimheader_0011F8TexScrollParams_0011F0[];
extern AnimatedMaterial object_mask_bakuretu_Matanimheader_0011F8[];
#endif
