#ifndef OBJECT_MASK_YOFUKASI_H
#define OBJECT_MASK_YOFUKASI_H 1

extern Vtx object_mask_yofukasiVtx_000000[];
extern Gfx object_mask_yofukasi_DL_000490[];
extern u64 object_mask_yofukasi_Tex_0006A0[];
extern u64 object_mask_yofukasi_Tex_000EA0[];
extern u64 object_mask_yofukasi_Tex_0012A0[];
#endif
