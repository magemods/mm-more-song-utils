#ifndef OBJECT_BAT_H
#define OBJECT_BAT_H 1

extern Vtx object_batVtx_000000[];
extern Gfx gBadBatSetupDL[];
extern Gfx gBadBatBodyDL[];
extern Vtx object_batVtx_000130[];
extern Gfx gBadBatWingsFrame0DL[];
extern Vtx object_batVtx_000220[];
extern Gfx gBadBatWingsFrame1DL[];
extern Vtx object_batVtx_000310[];
extern Gfx gBadBatWingsFrame2DL[];
extern Vtx object_batVtx_000400[];
extern Gfx gBadBatWingsFrame3DL[];
extern Vtx object_batVtx_0004F0[];
extern Gfx gBadBatWingsFrame4DL[];
extern Vtx object_batVtx_0005E0[];
extern Gfx gBadBatWingsFrame5DL[];
extern Vtx object_batVtx_0006D0[];
extern Gfx gBadBatWingsFrame6DL[];
extern Vtx object_batVtx_0007C0[];
extern Gfx gBadBatWingsFrame7DL[];
extern Vtx object_batVtx_0008B0[];
extern Gfx gBadBatWingsFrame8DL[];
extern u64 gBadBatWingTex[];
extern u64 gBatBatBodyTex[];
#endif
