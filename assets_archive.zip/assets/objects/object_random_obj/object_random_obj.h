#ifndef OBJECT_RANDOM_OBJ_H
#define OBJECT_RANDOM_OBJ_H 1

extern Vtx object_random_objVtx_000000[];
extern Gfx gSecretShrineSlidingDoorDL[];
extern u64 gSecretShrineSlidingDoorTex[];
#endif
