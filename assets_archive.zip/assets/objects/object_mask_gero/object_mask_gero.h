#ifndef OBJECT_MASK_GERO_H
#define OBJECT_MASK_GERO_H 1

extern Vtx object_mask_geroVtx_000000[];
extern Gfx gDonGeroMaskDL[];
extern u64 gDonGeroMaskTLUT[];
extern u64 gDonGeroMaskBottomTex[];
extern u64 gDonGeroMaskToesTex[];
extern u64 gDonGeroMaskTopTex[];
extern u64 gDonGeroMaskNostrilTex[];
extern u64 gDonGeroMaskMouthTex[];
extern u64 gDonGeroMaskFrillsTex[];
extern u64 gDonGeroMaskEyeTex[];
#endif
