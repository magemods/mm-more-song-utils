#ifndef OBJECT_UMAJUMP_H
#define OBJECT_UMAJUMP_H 1

extern u64 object_umajump_Tex_000000[];
extern u64 object_umajump_Tex_000800[];
extern Vtx object_umajumpVtx_001000[];
extern Gfx gHorseJumpFenceDL[];
extern BgCamInfo object_umajump_Colheader_001438CamDataList[];
extern SurfaceType object_umajump_Colheader_001438SurfaceType[];
extern CollisionPoly object_umajump_Colheader_001438Polygons[];
extern Vec3s object_umajump_Colheader_001438Vertices[];
extern CollisionHeader object_umajump_Colheader_001438;
extern BgCamInfo object_umajump_Colheader_001558CamDataList[];
extern SurfaceType object_umajump_Colheader_001558SurfaceType[];
extern CollisionPoly object_umajump_Colheader_001558Polygons[];
extern Vec3s object_umajump_Colheader_001558Vertices[];
extern CollisionHeader object_umajump_Colheader_001558;
#endif
