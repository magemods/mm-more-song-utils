#ifndef OBJECT_NNH_H
#define OBJECT_NNH_H 1

extern Vtx object_nnhVtx_000000[];
extern Gfx gButlerSonMainBodyDL[];
extern u64 gButlerSonTLUT[];
extern u64 gButlerSonRootTex[];
extern u64 gButlerSonMainBodyTex[];
extern u64 gButlerSonWholeLeafTex[];
extern u64 gButlerSonCutoutLeafTex[];
#endif
