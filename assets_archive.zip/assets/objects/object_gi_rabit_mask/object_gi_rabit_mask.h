#ifndef OBJECT_GI_RABIT_MASK_H
#define OBJECT_GI_RABIT_MASK_H 1

extern u64 gGiBunnyHoodEyeTex[];
extern Vtx object_gi_rabit_maskVtx_000100[];
extern Gfx gGiBunnyHoodDL[];
extern Gfx gGiBunnyHoodEyesDL[];
#endif
