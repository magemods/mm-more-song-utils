#ifndef OBJECT_ASTR_OBJ_H
#define OBJECT_ASTR_OBJ_H 1

extern u64 object_astr_obj_TLUT_000000[];
extern u64 object_astr_obj_Tex_000020[];
extern u64 object_astr_obj_Tex_000820[];
extern u64 object_astr_obj_Tex_001020[];
extern Vtx object_astr_objVtx_002020[];
extern Gfx object_astr_obj_DL_002170[];
extern Gfx object_astr_obj_DL_002178[];
extern Vtx object_astr_objVtx_002230[];
extern Gfx object_astr_obj_DL_0022E0[];
extern Gfx object_astr_obj_DL_002380[];
extern BgCamInfo object_astr_obj_Colheader_002498CamDataList[];
extern SurfaceType object_astr_obj_Colheader_002498SurfaceType[];
extern CollisionPoly object_astr_obj_Colheader_002498Polygons[];
extern Vec3s object_astr_obj_Colheader_002498Vertices[];
extern CollisionHeader object_astr_obj_Colheader_002498;
#endif
