#ifndef OBJECT_GI_SCHEDULE_H
#define OBJECT_GI_SCHEDULE_H 1

extern Vtx object_gi_scheduleVtx_000000[];
extern Gfx gGiBombersNotebookDL[];
extern Gfx gGiBombersNotebookEmptyDL[];
extern u64 gGiBombersNotebookPagesTex[];
extern u64 gGiBombersNotebookCoverBorderTex[];
extern u64 gGiBombersNotebookCoverTex[];
extern u64 gGiBombersNotebookLabelTex[];
extern u64 gGiBombersNotebookBindingsTex[];
#endif
