#ifndef OBJECT_YUKIYAMA_H
#define OBJECT_YUKIYAMA_H 1

extern Vtx object_yukiyamaVtx_000000[];
extern Gfx object_yukiyama_DL_001250[];
extern Gfx object_yukiyama_DL_0013A8[];
extern u64 object_yukiyama_Tex_001A60[];
extern u64 object_yukiyama_Tex_001C60[];
extern u64 object_yukiyama_Tex_002C60[];
extern u64 object_yukiyama_Tex_003C60[];
extern u64 object_yukiyama_Tex_004460[];
extern u64 object_yukiyama_Tex_004C60[];
extern u64 object_yukiyama_Tex_005060[];
extern u64 object_yukiyama_Tex_005860[];
extern u64 object_yukiyama_Tex_006060[];
extern AnimatedMatTexScrollParams object_yukiyama_Matanimheader_006868TexScrollParams_006860[];
extern AnimatedMaterial object_yukiyama_Matanimheader_006868[];
#endif
