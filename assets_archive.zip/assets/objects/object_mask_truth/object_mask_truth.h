#ifndef OBJECT_MASK_TRUTH_H
#define OBJECT_MASK_TRUTH_H 1

extern Vtx object_mask_truthVtx_000000[];
extern Gfx object_mask_truth_DL_0001A0[];
extern u64 object_mask_truth_Tex_000298[];
#endif
