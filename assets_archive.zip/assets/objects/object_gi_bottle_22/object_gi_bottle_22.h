#ifndef OBJECT_GI_BOTTLE_22_H
#define OBJECT_GI_BOTTLE_22_H 1

extern Vtx object_gi_bottle_22Vtx_000000[];
extern Gfx gGiHylianLoachBottleGlassCorkWaterDL[];
extern Gfx gGiHylianLoachBottleContentsDL[];
extern u64 gGiHylianLoachBottleCorkTex[];
extern u64 gGiHylianLoachBottleLoachTex[];
extern u64 gGiHylianLoachBottleGlassTex[];
extern u64 gGiHylianLoachBottleWaterTex[];
#endif
