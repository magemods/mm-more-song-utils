#ifndef OBJECT_GI_RESERVE00_H
#define OBJECT_GI_RESERVE00_H 1

extern Vtx object_gi_reserve00Vtx_000000[];
extern Mtx gGiMoonsTearIdentityMtx;
extern Gfx gGiMoonsTearGlowDL[];
extern Gfx gGiMoonsTearItemDL[];
extern u64 gGiMoonsTearItem1Tex[];
extern u64 gGiMoonsTearItem2Tex[];
extern u64 gGiMoonsTearGlowTex[];
extern AnimatedMatTexScrollParams gGiMoonsTearTexAnimTexScrollParams_001C50[];
extern AnimatedMatTexScrollParams gGiMoonsTearTexAnimTexScrollParams_001C58[];
extern AnimatedMaterial gGiMoonsTearTexAnim[];
#endif
