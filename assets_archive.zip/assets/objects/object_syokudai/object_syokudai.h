#ifndef OBJECT_SYOKUDAI_H
#define OBJECT_SYOKUDAI_H 1

extern Vtx object_syokudaiVtx_000000[];
extern Gfx gObjectSyokudaiTypeSwitchCausesFlameDL[];
extern Vtx object_syokudaiVtx_000570[];
extern Gfx gObjectSyokudaiTypeNoSwitchDL[];
extern Vtx object_syokudaiVtx_0009D0[];
extern Gfx gObjectSyokudaiTypeFlameCausesSwitchDL[];
extern u64 object_syokudai_Tex_000C90[];
extern u64 object_syokudai_Tex_001490[];
extern u64 object_syokudai_Tex_002490[];
extern u64 object_syokudai_Tex_002C90[];
extern u64 object_syokudai_Tex_003490[];
#endif
