#ifndef OBJECT_WDOR01_H
#define OBJECT_WDOR01_H 1

extern Vtx object_wdor01Vtx_000000[];
extern Gfx gLotteryCuriosityShopMayorHouseDoorEmptyDL[];
extern Gfx gLotteryCuriosityShopMayorHouseDoorDL[];
extern u64 gLotteryCuriosityShopMayorHouseDoorTex[];
#endif
