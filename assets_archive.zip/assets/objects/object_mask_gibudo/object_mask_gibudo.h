#ifndef OBJECT_MASK_GIBUDO_H
#define OBJECT_MASK_GIBUDO_H 1

extern Vtx object_mask_gibudoVtx_000000[];
extern Gfx object_mask_gibudo_DL_000250[];
extern u64 object_mask_gibudo_Tex_000398[];
extern u64 object_mask_gibudo_Tex_000B98[];
#endif
