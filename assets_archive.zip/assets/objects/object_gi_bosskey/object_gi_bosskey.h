#ifndef OBJECT_GI_BOSSKEY_H
#define OBJECT_GI_BOSSKEY_H 1

extern Vtx object_gi_bosskeyVtx_000000[];
extern Gfx gGiBossKeyDL[];
extern Gfx gGiBossKeyGemDL[];
#endif
