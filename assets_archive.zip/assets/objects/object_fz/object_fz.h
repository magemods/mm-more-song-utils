#ifndef OBJECT_FZ_H
#define OBJECT_FZ_H 1

extern Vtx object_fzVtx_000000[];
extern Gfx object_fz_DL_001130[];
extern Vtx object_fzVtx_0013F0[];
extern Gfx object_fz_DL_0021A0[];
extern Vtx object_fzVtx_0023F0[];
extern Gfx object_fz_DL_002CA0[];
extern u64 object_fz_Tex_002E70[];
extern Vtx object_fzVtx_003070[];
extern Gfx object_fz_DL_0030A0[];
extern Gfx object_fz_DL_003158[];
extern Vtx object_fzVtx_003180[];
extern Gfx object_fz_DL_003260[];
extern Vtx object_fzVtx_003310[];
extern Gfx object_fz_DL_0033F0[];
#endif
