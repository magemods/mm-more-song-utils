#ifndef OBJECT_GI_SWORD_1_H
#define OBJECT_GI_SWORD_1_H 1

extern Vtx object_gi_sword_1Vtx_000000[];
extern Gfx gGiKokiriSwordGuardDL[];
extern Gfx gGiKokiriSwordBladeHiltDL[];
extern u64 gGiKokiriSwordGuardTex[];
extern u64 gGiKokiriSwordHiltTex[];
extern u64 gGiKokiriSwordBladeTex[];
#endif
