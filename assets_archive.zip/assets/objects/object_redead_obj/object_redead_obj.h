#ifndef OBJECT_REDEAD_OBJ_H
#define OBJECT_REDEAD_OBJ_H 1

extern Vtx object_redead_objVtx_000000[];
extern Gfx gBeneathTheWellSlidingDoorDL[];
extern u64 gBeneathTheWellSlidingDoorTLUT[];
extern u64 gBeneathTheWellSlidingDoorTex[];
#endif
