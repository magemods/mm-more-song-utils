#ifndef OBJECT_OBJ_CHAN_H
#define OBJECT_OBJ_CHAN_H 1

extern Vtx object_obj_chanVtx_000000[];
extern Gfx gChandelierPotHolderDL[];
extern Gfx gChandelierCenterDL[];
extern u64 gChandelierCenterBottomTex[];
extern u64 gChandelierCenterTopTex[];
extern u64 gChandelierChainTex[];
extern u64 gChandelierPotHolderTex[];
extern Vtx object_obj_chanVtx_001F80[];
extern Gfx gChandelierEmptyDL[];
extern Gfx gChandelierPotDL[];
extern u64 gChandelierPotTex[];
#endif
