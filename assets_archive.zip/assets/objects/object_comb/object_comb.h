#ifndef OBJECT_COMB_H
#define OBJECT_COMB_H 1

extern u64 gBeehiveTex[];
extern Vtx object_combVtx_000800[];
extern Gfx gBeehiveDL[];
extern u64 gBeehiveFragmentTex[];
extern Vtx object_combVtx_001010[];
extern Gfx gBeehiveFragmentDL[];
#endif
