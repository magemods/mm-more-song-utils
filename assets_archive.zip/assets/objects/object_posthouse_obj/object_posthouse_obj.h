#ifndef OBJECT_POSTHOUSE_OBJ_H
#define OBJECT_POSTHOUSE_OBJ_H 1

extern Vtx object_posthouse_objVtx_000000[];
extern Gfx object_posthouse_obj_DL_000A50[];
extern u64 object_posthouse_obj_Tex_000DA8[];
extern u64 object_posthouse_obj_Tex_000E28[];
extern u64 object_posthouse_obj_Tex_001028[];
extern Vtx object_posthouse_objVtx_001830[];
extern Gfx object_posthouse_obj_DL_001870[];
extern u64 object_posthouse_obj_Tex_001900[];
extern BgCamInfo object_posthouse_obj_Colheader_002948CamDataList[];
extern SurfaceType object_posthouse_obj_Colheader_002948SurfaceType[];
extern CollisionPoly object_posthouse_obj_Colheader_002948Polygons[];
extern Vec3s object_posthouse_obj_Colheader_002948Vertices[];
extern CollisionHeader object_posthouse_obj_Colheader_002948;
#endif
