#ifndef OBJECT_TAB_H
#define OBJECT_TAB_H 1

typedef enum BartenLimb {
    /* 0x00 */ BARTEN_LIMB_NONE,
    /* 0x01 */ BARTEN_LIMB_PELVIS,
    /* 0x02 */ BARTEN_LIMB_RIGHT_THIGH,
    /* 0x03 */ BARTEN_LIMB_RIGHT_LEG,
    /* 0x04 */ BARTEN_LIMB_RIGHT_FOOT,
    /* 0x05 */ BARTEN_LIMB_LEFT_THIGH,
    /* 0x06 */ BARTEN_LIMB_LEFT_LEG,
    /* 0x07 */ BARTEN_LIMB_LEFT_FOOT,
    /* 0x08 */ BARTEN_LIMB_CHEST,
    /* 0x09 */ BARTEN_LIMB_HEAD,
    /* 0x0A */ BARTEN_LIMB_RIGHT_UPPER_ARM,
    /* 0x0B */ BARTEN_LIMB_RIGHT_FOREARM_ROOT,
    /* 0x0C */ BARTEN_LIMB_RIGHT_FOREARM,
    /* 0x0D */ BARTEN_LIMB_RIGHT_HAND,
    /* 0x0E */ BARTEN_LIMB_LEFT_ARM_ROOT,
    /* 0x0F */ BARTEN_LIMB_LEFT_UPPER_ARM,
    /* 0x10 */ BARTEN_LIMB_LEFT_FOREARM,
    /* 0x11 */ BARTEN_LIMB_LEFT_HAND_ROOT,
    /* 0x12 */ BARTEN_LIMB_LEFT_BROOM,
    /* 0x13 */ BARTEN_LIMB_LEFT_HAND,
    /* 0x14 */ BARTEN_LIMB_MAX
} BartenLimb;

extern s16 sBartenIdleAnimFrameData[];
extern JointIndex sBartenIdleAnimJointIndices[];
extern AnimationHeader gBartenIdleAnim;
extern Vtx object_tabVtx_000770[];
extern Gfx gBartenPelvisDL[];
extern Gfx gBartenLeftHandDL[];
extern Gfx gBartenLeftBroomDL[];
extern Gfx gBartenLeftForearmDL[];
extern Gfx gBartenLeftUpperArmDL[];
extern Gfx gBartenRightHandDL[];
extern Gfx gBartenRightForearmDL[];
extern Gfx gBartenRightUpperArmDL[];
extern Gfx gBartenChestDL[];
extern Gfx gBartenHeadDL[];
extern Gfx gBartenLeftThighDL[];
extern Gfx gBartenLeftLegDL[];
extern Gfx gBartenLeftFootDL[];
extern Gfx gBartenRightThighDL[];
extern Gfx gBartenRightLegDL[];
extern Gfx gBartenRightFootDL[];
extern u64 gBartenTLUT[];
extern u64 gBartenEyeTLUT[];
extern u64 gBartenBeardTex[];
extern u64 gBartenArmTex[];
extern u64 gBartenMouthTex[];
extern u64 gBartenHairTex[];
extern u64 gBartenEarTex[];
extern u64 gBartenEyeOpenTex[];
extern u64 gBartenHandTex[];
extern u64 gBartenEyeHalfOpenTex[];
extern u64 gBartenEyeClosedTex[];
extern u64 gBartenBroomTex[];
extern u64 gBartenBroomHeadTex[];
extern u64 gBartenPantsTex[];
extern u64 gBartenBowtieTex[];
extern u64 gBartenSkinTex[];
extern u64 gBartenCollarTex[];
extern u64 gBartenSleeveTex[];
extern u64 gBartenJacketTex[];
extern u64 gBartenFootTex[];
extern StandardLimb gBartenPelvisLimb;
extern StandardLimb gBartenRightThighLimb;
extern StandardLimb gBartenRightLegLimb;
extern StandardLimb gBartenRightFootLimb;
extern StandardLimb gBartenLeftThighLimb;
extern StandardLimb gBartenLeftLegLimb;
extern StandardLimb gBartenLeftFootLimb;
extern StandardLimb gBartenChestLimb;
extern StandardLimb gBartenHeadLimb;
extern StandardLimb gBartenRightUpperArmLimb;
extern StandardLimb gBartenRightForearmRootLimb;
extern StandardLimb gBartenRightForearmLimb;
extern StandardLimb gBartenRightHandLimb;
extern StandardLimb gBartenLeftArmRootLimb;
extern StandardLimb gBartenLeftUpperArmLimb;
extern StandardLimb gBartenLeftForearmLimb;
extern StandardLimb gBartenLeftHandRootLimb;
extern StandardLimb gBartenLeftBroomLimb;
extern StandardLimb gBartenLeftHandLimb;
extern void* gBartenSkelLimbs[];
extern FlexSkeletonHeader gBartenSkel;
extern s16 sBartenIdleBarCounterAnimFrameData[];
extern JointIndex sBartenIdleBarCounterAnimJointIndices[];
extern AnimationHeader gBartenIdleBarCounterAnim;
#endif
