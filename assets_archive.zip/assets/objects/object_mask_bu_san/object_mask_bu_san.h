#ifndef OBJECT_MASK_BU_SAN_H
#define OBJECT_MASK_BU_SAN_H 1

extern Vtx object_mask_bu_sanVtx_000000[];
extern Gfx object_mask_bu_san_DL_000710[];
extern u64 object_mask_bu_san_TLUT_000B68[];
extern u64 object_mask_bu_san_Tex_000D68[];
extern u64 object_mask_bu_san_Tex_000DA8[];
extern u64 object_mask_bu_san_Tex_000EA8[];
extern u64 object_mask_bu_san_Tex_000FA8[];
extern u64 object_mask_bu_san_Tex_0011A8[];
extern u64 object_mask_bu_san_Tex_0011E8[];
#endif
