#ifndef OBJECT_SECOM_OBJ_H
#define OBJECT_SECOM_OBJ_H 1

extern Vtx object_secom_objVtx_000000[];
extern Gfx object_secom_obj_DL_000080[];
extern BgCamInfo object_secom_obj_Colheader_0001C0CamDataList[];
extern SurfaceType object_secom_obj_Colheader_0001C0SurfaceType[];
extern CollisionPoly object_secom_obj_Colheader_0001C0Polygons[];
extern Vec3s object_secom_obj_Colheader_0001C0Vertices[];
extern CollisionHeader object_secom_obj_Colheader_0001C0;
extern u64 object_secom_obj_Tex_0001F0[];
extern Vtx object_secom_objVtx_0011F0[];
extern Gfx object_secom_obj_DL_001230[];
extern Vtx object_secom_objVtx_0012C0[];
extern Gfx object_secom_obj_DL_001300[];
extern u64 object_secom_obj_Tex_001390[];
extern u64 object_secom_obj_Tex_001750[];
extern Vtx object_secom_objVtx_001950[];
extern Gfx object_secom_obj_DL_001A50[];
extern Gfx object_secom_obj_DL_001A58[];
extern u64 object_secom_obj_Tex_001B08[];
extern BgCamInfo object_secom_obj_Colheader_002CB8CamDataList[];
extern SurfaceType object_secom_obj_Colheader_002CB8SurfaceType[];
extern CollisionPoly object_secom_obj_Colheader_002CB8Polygons[];
extern Vec3s object_secom_obj_Colheader_002CB8Vertices[];
extern CollisionHeader object_secom_obj_Colheader_002CB8;
#endif
