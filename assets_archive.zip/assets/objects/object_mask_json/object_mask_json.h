#ifndef OBJECT_MASK_JSON_H
#define OBJECT_MASK_JSON_H 1

extern Vtx object_mask_jsonVtx_000000[];
extern Gfx object_mask_json_DL_0004C0[];
extern u64 object_mask_json_TLUT_0008A0[];
extern u64 object_mask_json_Tex_000AA0[];
extern u64 object_mask_json_Tex_000CA0[];
extern u64 object_mask_json_Tex_000D20[];
extern u64 object_mask_json_Tex_000F20[];
extern u64 object_mask_json_Tex_001320[];
#endif
