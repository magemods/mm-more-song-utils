#ifndef OBJECT_MASK_STONE_H
#define OBJECT_MASK_STONE_H 1

extern Vtx object_mask_stoneVtx_000000[];
extern Gfx object_mask_stone_DL_000820[];
extern u64 object_mask_stone_Tex_000B40[];
extern u64 object_mask_stone_Tex_000C40[];
#endif
