#ifndef OBJECT_KNIGHT_H
#define OBJECT_KNIGHT_H 1

typedef enum IgosLimb {
    /* 0x00 */ IGOS_LIMB_NONE,
    /* 0x01 */ IGOS_LIMB_ROOT,
    /* 0x02 */ IGOS_LIMB_SPINE_BASE,
    /* 0x03 */ IGOS_LIMB_SPINE_UPPER,
    /* 0x04 */ IGOS_LIMB_LEFT_UPPER_ARM,
    /* 0x05 */ IGOS_LIMB_LEFT_FOREARM,
    /* 0x06 */ IGOS_LIMB_SHIELD,
    /* 0x07 */ IGOS_LIMB_LEFT_HAND,
    /* 0x08 */ IGOS_LIMB_LEFT_SHOULDER,
    /* 0x09 */ IGOS_LIMB_RIGHT_UPPER_ARM,
    /* 0x0A */ IGOS_LIMB_RIGHT_FOREARM,
    /* 0x0B */ IGOS_LIMB_SWORD,
    /* 0x0C */ IGOS_LIMB_RIGHT_HAND,
    /* 0x0D */ IGOS_LIMB_RIGHT_SHOULDER,
    /* 0x0E */ IGOS_LIMB_COLLAR,
    /* 0x0F */ IGOS_LIMB_NECK,
    /* 0x10 */ IGOS_LIMB_10,
    /* 0x11 */ IGOS_LIMB_11,
    /* 0x12 */ IGOS_LIMB_JAW,
    /* 0x13 */ IGOS_LIMB_HEAD,
    /* 0x14 */ IGOS_LIMB_TORSO,
    /* 0x15 */ IGOS_LIMB_PELVIS,
    /* 0x16 */ IGOS_LIMB_16,
    /* 0x17 */ IGOS_LIMB_LEFT_LEG_UPPER,
    /* 0x18 */ IGOS_LIMB_LEFT_LEG_LOWER,
    /* 0x19 */ IGOS_LIMB_LEFT_FOOT,
    /* 0x1A */ IGOS_LIMB_RIGHT_LEG_UPPER,
    /* 0x1B */ IGOS_LIMB_RIGHT_LEG_LOWER,
    /* 0x1C */ IGOS_LIMB_RIGHT_FOOT,
    /* 0x1D */ IGOS_LIMB_MAX
} IgosLimb;

typedef enum KnightLimb {
    /* 0x00 */ KNIGHT_LIMB_NONE,
    /* 0x01 */ KNIGHT_LIMB_ROOT,
    /* 0x02 */ KNIGHT_LIMB_SPINE_BASE,
    /* 0x03 */ KNIGHT_LIMB_SPINE_UPPER,
    /* 0x04 */ KNIGHT_LIMB_LEFT_UPPER_ARM,
    /* 0x05 */ KNIGHT_LIMB_LEFT_FOREARM,
    /* 0x06 */ KNIGHT_LIMB_SHIELD,
    /* 0x07 */ KNIGHT_LIMB_LEFT_HAND,
    /* 0x08 */ KNIGHT_LIMB_LEFT_SHOULDER,
    /* 0x09 */ KNIGHT_LIMB_RIGHT_UPPER_ARM,
    /* 0x0A */ KNIGHT_LIMB_RIGHT_FOREARM,
    /* 0x0B */ KNIGHT_LIMB_SWORD,
    /* 0x0C */ KNIGHT_LIMB_RIGHT_HAND,
    /* 0x0D */ KNIGHT_LIMB_RIGHT_SHOULDER,
    /* 0x0E */ KNIGHT_LIMB_COLLAR,
    /* 0x0F */ KNIGHT_LIMB_NECK,
    /* 0x10 */ KNIGHT_LIMB_10,
    /* 0x11 */ KNIGHT_LIMB_11,
    /* 0x12 */ KNIGHT_LIMB_JAW,
    /* 0x13 */ KNIGHT_LIMB_HEAD,
    /* 0x14 */ KNIGHT_LIMB_TORSO,
    /* 0x15 */ KNIGHT_LIMB_PELVIS,
    /* 0x16 */ KNIGHT_LIMB_16,
    /* 0x17 */ KNIGHT_LIMB_LEFT_LEG_UPPER,
    /* 0x18 */ KNIGHT_LIMB_LEFT_LEG_LOWER,
    /* 0x19 */ KNIGHT_LIMB_LEFT_FOOT,
    /* 0x1A */ KNIGHT_LIMB_RIGHT_LEG_UPPER,
    /* 0x1B */ KNIGHT_LIMB_RIGHT_LEG_LOWER,
    /* 0x1C */ KNIGHT_LIMB_RIGHT_FOOT,
    /* 0x1D */ KNIGHT_LIMB_MAX
} KnightLimb;

extern s16 sKnightIgosCurtainReactionShockedAnimFrameData[];
extern JointIndex sKnightIgosCurtainReactionShockedAnimJointIndices[];
extern AnimationHeader gKnightIgosCurtainReactionShockedAnim;
extern s16 sKnightIgosCurtainReactionAngryAnimFrameData[];
extern JointIndex sKnightIgosCurtainReactionAngryAnimJointIndices[];
extern AnimationHeader gKnightIgosCurtainReactionAngryAnim;
extern s16 sKnightDamagedBackAnimFrameData[];
extern JointIndex sKnightDamagedBackAnimJointIndices[];
extern AnimationHeader gKnightDamagedBackAnim;
extern s16 sKnightFallBackwardsAnimFrameData[];
extern JointIndex sKnightFallBackwardsAnimJointIndices[];
extern AnimationHeader gKnightFallBackwardsAnim;
extern s16 sKnightJumpBackAnimFrameData[];
extern JointIndex sKnightJumpBackAnimJointIndices[];
extern AnimationHeader gKnightJumpBackAnim;
extern s16 sKnightIgosRemoveHeadAnimFrameData[];
extern JointIndex sKnightIgosRemoveHeadAnimJointIndices[];
extern AnimationHeader gKnightIgosRemoveHeadAnim;
extern s16 sKnightFastBlockStandingAnimFrameData[];
extern JointIndex sKnightFastBlockStandingAnimJointIndices[];
extern AnimationHeader gKnightFastBlockStandingAnim;
extern s16 sKnightFastWalkShieldingAnimFrameData[];
extern JointIndex sKnightFastWalkShieldingAnimJointIndices[];
extern AnimationHeader gKnightFastWalkShieldingAnim;
extern s16 sKnightIdleAnimFrameData[];
extern JointIndex sKnightIdleAnimJointIndices[];
extern AnimationHeader gKnightIdleAnim;
extern s16 sKnightSlowWalkShieldingAnimFrameData[];
extern JointIndex sKnightSlowWalkShieldingAnimJointIndices[];
extern AnimationHeader gKnightSlowWalkShieldingAnim;
extern s16 sKnightDamagedFrontAnimFrameData[];
extern JointIndex sKnightDamagedFrontAnimJointIndices[];
extern AnimationHeader gKnightDamagedFrontAnim;
extern s16 sKnightFallForwardsAnimFrameData[];
extern JointIndex sKnightFallForwardsAnimJointIndices[];
extern AnimationHeader gKnightFallForwardsAnim;
extern s16 sKnightIgosShrugAnimFrameData[];
extern JointIndex sKnightIgosShrugAnimJointIndices[];
extern AnimationHeader gKnightIgosShrugAnim;
extern s16 sKnightCaptainsHatCSIgosShockedStandingAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSIgosShockedStandingAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSIgosShockedStandingAnim;
extern s16 sKnightCaptainsHatCSIgosShockedSittingAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSIgosShockedSittingAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSIgosShockedSittingAnim;
extern s16 sKnightIgosPutHeadBackOnAnimFrameData[];
extern JointIndex sKnightIgosPutHeadBackOnAnimJointIndices[];
extern AnimationHeader gKnightIgosPutHeadBackOnAnim;
extern s16 sKnightIgosLaughAnimFrameData[];
extern JointIndex sKnightIgosLaughAnimJointIndices[];
extern AnimationHeader gKnightIgosLaughAnim;
extern s16 sKnightFastBlockSittingAnimFrameData[];
extern JointIndex sKnightFastBlockSittingAnimJointIndices[];
extern AnimationHeader gKnightFastBlockSittingAnim;
extern s16 sKnightEndBlockAndSitAnimFrameData[];
extern JointIndex sKnightEndBlockAndSitAnimJointIndices[];
extern AnimationHeader gKnightEndBlockAndSitAnim;
extern s16 sKnightIgosBreathAttackAnimFrameData[];
extern JointIndex sKnightIgosBreathAttackAnimJointIndices[];
extern AnimationHeader gKnightIgosBreathAttackAnim;
extern s16 sKnightIgosBreathAttackStartAnimFrameData[];
extern JointIndex sKnightIgosBreathAttackStartAnimJointIndices[];
extern AnimationHeader gKnightIgosBreathAttackStartAnim;
extern s16 sKnightIgosStandAndDrawAnimFrameData[];
extern JointIndex sKnightIgosStandAndDrawAnimJointIndices[];
extern AnimationHeader gKnightIgosStandAndDrawAnim;
extern s16 sKnightIgosSitDownAnimFrameData[];
extern JointIndex sKnightIgosSitDownAnimJointIndices[];
extern AnimationHeader gKnightIgosSitDownAnim;
extern s16 sKnightCaptainsHatCSIgosSteppingAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSIgosSteppingAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSIgosSteppingAnim;
extern s16 sKnightJumpAnimFrameData[];
extern JointIndex sKnightJumpAnimJointIndices[];
extern AnimationHeader gKnightJumpAnim;
extern s16 sKnightJumpAttackBeginAnimFrameData[];
extern JointIndex sKnightJumpAttackBeginAnimJointIndices[];
extern AnimationHeader gKnightJumpAttackBeginAnim;
extern s16 sKnightJumpAttackEndAnimFrameData[];
extern JointIndex sKnightJumpAttackEndAnimJointIndices[];
extern AnimationHeader gKnightJumpAttackEndAnim;
extern s16 sKnightLeftSwingAnimFrameData[];
extern JointIndex sKnightLeftSwingAnimJointIndices[];
extern AnimationHeader gKnightLeftSwingAnim;
extern s16 sKnightRightSwingAnimFrameData[];
extern JointIndex sKnightRightSwingAnimJointIndices[];
extern AnimationHeader gKnightRightSwingAnim;
extern s16 sKnightCaptainsHatCSIgosShockedAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSIgosShockedAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSIgosShockedAnim;
extern s16 sKnightLaugh1AnimFrameData[];
extern JointIndex sKnightLaugh1AnimJointIndices[];
extern AnimationHeader gKnightLaugh1Anim;
extern s16 sKnightLaugh2AnimFrameData[];
extern JointIndex sKnightLaugh2AnimJointIndices[];
extern AnimationHeader gKnightLaugh2Anim;
extern s16 sKnightMarchAnimFrameData[];
extern JointIndex sKnightMarchAnimJointIndices[];
extern AnimationHeader gKnightMarchAnim;
extern s16 sKnightIgosBreathAttackStopAnimFrameData[];
extern JointIndex sKnightIgosBreathAttackStopAnimJointIndices[];
extern AnimationHeader gKnightIgosBreathAttackStopAnim;
extern s16 sKnightStruckByLightRayAnimFrameData[];
extern JointIndex sKnightStruckByLightRayAnimJointIndices[];
extern AnimationHeader gKnightStruckByLightRayAnim;
extern s16 sKnightCaptainsHatCSBeginStandingAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSBeginStandingAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSBeginStandingAnim;
extern s16 sKnightCaptainsHatCSBeginSittingAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSBeginSittingAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSBeginSittingAnim;
extern s16 sKnightStrafeAnimFrameData[];
extern JointIndex sKnightStrafeAnimJointIndices[];
extern AnimationHeader gKnightStrafeAnim;
extern s16 sKnightUppercutAnimFrameData[];
extern JointIndex sKnightUppercutAnimJointIndices[];
extern AnimationHeader gKnightUppercutAnim;
extern s16 sKnightIgosSittingAnimFrameData[];
extern JointIndex sKnightIgosSittingAnimJointIndices[];
extern AnimationHeader gKnightIgosSittingAnim;
extern s16 sKnightCaptainsHatCSSitBackDownAnimFrameData[];
extern JointIndex sKnightCaptainsHatCSSitBackDownAnimJointIndices[];
extern AnimationHeader gKnightCaptainsHatCSSitBackDownAnim;
extern s16 sKnightIntroSitDownAnimFrameData[];
extern JointIndex sKnightIntroSitDownAnimJointIndices[];
extern AnimationHeader gKnightIntroSitDownAnim;
extern s16 sKnightHeavyAttackAnimFrameData[];
extern JointIndex sKnightHeavyAttackAnimJointIndices[];
extern AnimationHeader gKnightHeavyAttackAnim;
extern s16 sKnightBeginTelegraphHeavyAttackAnimFrameData[];
extern JointIndex sKnightBeginTelegraphHeavyAttackAnimJointIndices[];
extern AnimationHeader gKnightBeginTelegraphHeavyAttackAnim;
extern Vtx object_knightVtx_011AC0[];
extern Gfx gKnightWideHeadDL[];
extern u64 object_knight_Tex_012760[];
extern u64 object_knight_Tex_012960[];
extern u64 object_knight_Tex_012B60[];
extern u64 object_knight_Tex_012BE0[];
extern Vtx object_knightVtx_012C60[];
extern Gfx gKnightWideJawDL[];
extern u64 object_knight_Tex_012EC0[];
extern u64 object_knight_Tex_012FC0[];
extern Vtx object_knightVtx_012FE0[];
extern Gfx gKnightWideNeckDL[];
extern Vtx object_knightVtx_0130B0[];
extern Gfx object_knight_DL_0153E0[];
extern Gfx object_knight_DL_0154B0[];
extern Gfx object_knight_DL_0155A0[];
extern Gfx object_knight_DL_015660[];
extern Gfx object_knight_DL_015730[];
extern Gfx object_knight_DL_015820[];
extern Gfx object_knight_DL_0158E0[];
extern Gfx object_knight_DL_015A40[];
extern Gfx object_knight_DL_015AE0[];
extern Gfx object_knight_DL_015B88[];
extern Gfx object_knight_DL_015D78[];
extern Gfx object_knight_DL_015E38[];
extern Gfx object_knight_DL_015ED8[];
extern Gfx object_knight_DL_016310[];
extern Gfx object_knight_DL_0163C8[];
extern Gfx object_knight_DL_016478[];
extern Gfx object_knight_DL_016530[];
extern Gfx object_knight_DL_0165F0[];
extern Gfx object_knight_DL_0166D8[];
extern Gfx object_knight_DL_016810[];
extern Gfx object_knight_DL_0169C8[];
extern Gfx object_knight_DL_016AD0[];
extern Gfx object_knight_DL_016B90[];
extern Gfx object_knight_DL_016C78[];
extern Gfx object_knight_DL_016DB0[];
extern Gfx object_knight_DL_016F70[];
extern u64 object_knight_Tex_017078[];
extern u64 object_knight_Tex_017278[];
extern u64 object_knight_Tex_017298[];
extern u64 object_knight_Tex_0172D8[];
extern u64 object_knight_Tex_017358[];
extern u64 object_knight_Tex_017558[];
extern u64 object_knight_Tex_0175D8[];
extern u64 object_knight_Tex_0176D8[];
extern u64 object_knight_Tex_0178D8[];
extern u64 object_knight_Tex_017AD8[];
extern u64 object_knight_Tex_017BD8[];
extern u64 object_knight_Tex_017DD8[];
extern u64 object_knight_Tex_017FD8[];
extern u64 object_knight_Tex_018018[];
extern u64 object_knight_Tex_018098[];
extern Vtx object_knightVtx_018898[];
extern Gfx gKnightBlureState2DL[];
extern Vtx object_knightVtx_0189B0[];
extern Gfx gKnightBlureState1DL[];
extern Vtx object_knightVtx_018AA0[];
extern Gfx gKnightBlureState0DL[];
extern F3DPrimColor object_knightTexColorChangingPrimColors_018BA0[];
extern F3DEnvColor object_knightTexColorChangingEnvColors_018BAC[];
extern AnimatedMatColorParams gKnightBlureTexAnimColorParams_018BB4;
extern AnimatedMaterial gKnightBlureTexAnim[];
extern Vtx gIkanaThroneRoomLightRayVtx[];
extern Gfx gIkanaThroneRoomLightRayDL[];
extern Gfx gIkanaThroneRoomLightOnFloorDL[];
extern Gfx object_knight_DL_018E50[];
extern u64 object_knight_Tex_018E58[];
extern u64 object_knight_Tex_018F58[];
extern AnimatedMatTexScrollParams gIkanaThroneRoomLightRayTexAnimTexScrollParams_019358[];
extern AnimatedMaterial gIkanaThroneRoomLightRayTexAnim[];
extern Vtx object_knightVtx_019368[];
extern Gfx object_knight_DL_0193A8[];
extern Gfx gIkanaThroneRoomCurtainDL[];
extern u64 object_knight_TLUT_019470[];
extern u64 gIkanaThroneRoomCurtainTex[];
extern Vtx object_knightVtx_019C90[];
extern Gfx object_knight_DL_01D380[];
extern Gfx object_knight_DL_01D4C0[];
extern Gfx object_knight_DL_01D650[];
extern Gfx object_knight_DL_01D710[];
extern Gfx object_knight_DL_01D870[];
extern Gfx object_knight_DL_01DA00[];
extern Gfx object_knight_DL_01DAC0[];
extern Gfx object_knight_DL_01DC00[];
extern Gfx object_knight_DL_01DCA0[];
extern Gfx object_knight_DL_01DD48[];
extern Gfx object_knight_DL_01DF88[];
extern Gfx object_knight_DL_01E050[];
extern Gfx object_knight_DL_01E0A0[];
extern Gfx object_knight_DL_01E878[];
extern Gfx object_knight_DL_01EAA8[];
extern Gfx object_knight_DL_01EB40[];
extern Gfx object_knight_DL_01EBD8[];
extern Gfx object_knight_DL_01EC98[];
extern Gfx object_knight_DL_01EDE0[];
extern Gfx object_knight_DL_01EF68[];
extern Gfx object_knight_DL_01F188[];
extern Gfx object_knight_DL_01F248[];
extern Gfx object_knight_DL_01F308[];
extern Gfx object_knight_DL_01F3C0[];
extern Gfx object_knight_DL_01F5C0[];
extern Gfx object_knight_DL_01F828[];
extern u64 object_knight_Tex_01F8E8[];
extern u64 object_knight_Tex_01F9E8[];
extern u64 object_knight_Tex_01FAE8[];
extern u64 object_knight_Tex_01FBE8[];
extern u64 object_knight_Tex_01FCE8[];
extern u64 object_knight_Tex_01FDE8[];
extern StandardLimb object_knight_Standardlimb_01FFE8;
extern StandardLimb object_knight_Standardlimb_01FFF4;
extern StandardLimb object_knight_Standardlimb_020000;
extern StandardLimb object_knight_Standardlimb_02000C;
extern StandardLimb object_knight_Standardlimb_020018;
extern StandardLimb object_knight_Standardlimb_020024;
extern StandardLimb object_knight_Standardlimb_020030;
extern StandardLimb object_knight_Standardlimb_02003C;
extern StandardLimb object_knight_Standardlimb_020048;
extern StandardLimb object_knight_Standardlimb_020054;
extern StandardLimb object_knight_Standardlimb_020060;
extern StandardLimb object_knight_Standardlimb_02006C;
extern StandardLimb object_knight_Standardlimb_020078;
extern StandardLimb object_knight_Standardlimb_020084;
extern StandardLimb object_knight_Standardlimb_020090;
extern StandardLimb object_knight_Standardlimb_02009C;
extern StandardLimb object_knight_Standardlimb_0200A8;
extern StandardLimb object_knight_Standardlimb_0200B4;
extern StandardLimb object_knight_Standardlimb_0200C0;
extern StandardLimb object_knight_Standardlimb_0200CC;
extern StandardLimb object_knight_Standardlimb_0200D8;
extern StandardLimb object_knight_Standardlimb_0200E4;
extern StandardLimb object_knight_Standardlimb_0200F0;
extern StandardLimb object_knight_Standardlimb_0200FC;
extern StandardLimb object_knight_Standardlimb_020108;
extern StandardLimb object_knight_Standardlimb_020114;
extern StandardLimb object_knight_Standardlimb_020120;
extern StandardLimb object_knight_Standardlimb_02012C;
extern void* gIgosSkelLimbs[];
extern FlexSkeletonHeader gIgosSkel;
extern StandardLimb object_knight_Standardlimb_0201B4;
extern StandardLimb object_knight_Standardlimb_0201C0;
extern StandardLimb object_knight_Standardlimb_0201CC;
extern StandardLimb object_knight_Standardlimb_0201D8;
extern StandardLimb object_knight_Standardlimb_0201E4;
extern StandardLimb object_knight_Standardlimb_0201F0;
extern StandardLimb object_knight_Standardlimb_0201FC;
extern StandardLimb object_knight_Standardlimb_020208;
extern StandardLimb object_knight_Standardlimb_020214;
extern StandardLimb object_knight_Standardlimb_020220;
extern StandardLimb object_knight_Standardlimb_02022C;
extern StandardLimb object_knight_Standardlimb_020238;
extern StandardLimb object_knight_Standardlimb_020244;
extern StandardLimb object_knight_Standardlimb_020250;
extern StandardLimb object_knight_Standardlimb_02025C;
extern StandardLimb object_knight_Standardlimb_020268;
extern StandardLimb object_knight_Standardlimb_020274;
extern StandardLimb object_knight_Standardlimb_020280;
extern StandardLimb object_knight_Standardlimb_02028C;
extern StandardLimb object_knight_Standardlimb_020298;
extern StandardLimb object_knight_Standardlimb_0202A4;
extern StandardLimb object_knight_Standardlimb_0202B0;
extern StandardLimb object_knight_Standardlimb_0202BC;
extern StandardLimb object_knight_Standardlimb_0202C8;
extern StandardLimb object_knight_Standardlimb_0202D4;
extern StandardLimb object_knight_Standardlimb_0202E0;
extern StandardLimb object_knight_Standardlimb_0202EC;
extern StandardLimb object_knight_Standardlimb_0202F8;
extern void* gKnightSkelLimbs[];
extern FlexSkeletonHeader gKnightSkel;
extern s16 sKnightTelegraphHeavyAttackAnimFrameData[];
extern JointIndex sKnightTelegraphHeavyAttackAnimJointIndices[];
extern AnimationHeader gKnightTelegraphHeavyAttackAnim;
extern s16 sKnightIgosShrugStopAnimFrameData[];
extern JointIndex sKnightIgosShrugStopAnimJointIndices[];
extern AnimationHeader gKnightIgosShrugStopAnim;
extern s16 sKnightIntroWalkAnimFrameData[];
extern JointIndex sKnightIntroWalkAnimJointIndices[];
extern AnimationHeader gKnightIntroWalkAnim;
extern s16 sKnightIgosShrugStartAnimFrameData[];
extern JointIndex sKnightIgosShrugStartAnimJointIndices[];
extern AnimationHeader gKnightIgosShrugStartAnim;
extern s16 sKnightLowSwingAnimFrameData[];
extern JointIndex sKnightLowSwingAnimJointIndices[];
extern AnimationHeader gKnightLowSwingAnim;
extern s16 sKnightLowSwingEndAnimFrameData[];
extern JointIndex sKnightLowSwingEndAnimJointIndices[];
extern AnimationHeader gKnightLowSwingEndAnim;
#endif
