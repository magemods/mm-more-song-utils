#ifndef OBJECT_GI_SEAHORSE_H
#define OBJECT_GI_SEAHORSE_H 1

extern Vtx object_gi_seahorseVtx_000000[];
extern Mtx gGiSeahorseBillboardRotMtx;
extern Gfx gGiSeahorseGlowDL[];
extern Gfx gGiSeahorseBodyDL[];
extern Gfx gGiSeahorseEmptyDL[];
extern u64 gGiSeahorseEyeTex[];
extern u64 gGiSeahorseGlowTex[];
extern u64 gGiSeahorseTorsoTailTex[];
extern u64 gGiSeahorseFinTex[];
#endif
