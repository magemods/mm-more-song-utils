#ifndef OBJECT_GI_BOTTLE_15_H
#define OBJECT_GI_BOTTLE_15_H 1

extern Vtx object_gi_bottle_15Vtx_000000[];
extern Gfx gGiZoraEggBottleGlassAndCorkDL[];
extern Gfx gGiZoraEggBottleContentsDL[];
extern u64 gGiZoraEggBottleCorkTex[];
extern u64 gGiZoraEggBottleContentsTex[];
extern u64 gGiZoraEggBottleGlass1Tex[];
extern u64 gGiZoraEggBottleGlass2Tex[];
#endif
