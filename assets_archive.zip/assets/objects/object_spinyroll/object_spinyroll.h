#ifndef OBJECT_SPINYROLL_H
#define OBJECT_SPINYROLL_H 1

extern Vtx object_spinyrollVtx_000000[];
extern Gfx object_spinyroll_DL_000460[];
extern u64 object_spinyroll_Tex_0005C0[];
extern BgCamInfo object_spinyroll_Colheader_000E68CamDataList[];
extern SurfaceType object_spinyroll_Colheader_000E68SurfaceType[];
extern CollisionPoly object_spinyroll_Colheader_000E68Polygons[];
extern Vec3s object_spinyroll_Colheader_000E68Vertices[];
extern CollisionHeader object_spinyroll_Colheader_000E68;
extern BgCamInfo object_spinyroll_Colheader_000F80CamDataList[];
extern SurfaceType object_spinyroll_Colheader_000F80SurfaceType[];
extern CollisionPoly object_spinyroll_Colheader_000F80Polygons[];
extern Vec3s object_spinyroll_Colheader_000F80Vertices[];
extern CollisionHeader object_spinyroll_Colheader_000F80;
#endif
