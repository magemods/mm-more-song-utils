#ifndef OBJECT_HSSTUMP_H
#define OBJECT_HSSTUMP_H 1

extern Vtx object_hsstumpVtx_000000[];
extern Gfx object_hsstump_DL_0003B0[];
extern Gfx object_hsstump_DL_0003B8[];
extern u64 object_hsstump_Tex_0005A0[];
extern u64 object_hsstump_TLUT_0007A0[];
extern u64 object_hsstump_Tex_0007C0[];
extern BgCamInfo object_hsstump_Colheader_0011B0CamDataList[];
extern SurfaceType object_hsstump_Colheader_0011B0SurfaceType[];
extern CollisionPoly object_hsstump_Colheader_0011B0Polygons[];
extern Vec3s object_hsstump_Colheader_0011B0Vertices[];
extern CollisionHeader object_hsstump_Colheader_0011B0;
#endif
