#ifndef OBJECT_GI_RESERVE_B_00_H
#define OBJECT_GI_RESERVE_B_00_H 1

extern Vtx object_gi_reserve_b_00Vtx_000000[];
extern Gfx gGiRoomKeyDL[];
extern Gfx gGiRoomKeyEmptyDL[];
extern u64 gGiRoomKeyInscriptionsTex[];
extern u64 gGiRoomKeyBackgroundTex[];
#endif
