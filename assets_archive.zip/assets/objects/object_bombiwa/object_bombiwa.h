#ifndef OBJECT_BOMBIWA_H
#define OBJECT_BOMBIWA_H 1

extern u64 object_bombiwa_TLUT_000000[];
extern u64 object_bombiwa_Tex_000020[];
extern Vtx object_bombiwaVtx_000820[];
extern Gfx object_bombiwa_DL_0009E0[];
extern Gfx object_bombiwa_DL_000AF0[];
extern u64 object_bombiwa_Tex_000C00[];
extern Vtx object_bombiwaVtx_001400[];
extern Gfx object_bombiwa_DL_001700[];
extern Gfx object_bombiwa_DL_001800[];
extern Gfx object_bombiwa_DL_001820[];
extern Vtx object_bombiwaVtx_001830[];
extern Gfx object_bombiwa_DL_001990[];
extern u64 object_bombiwa_Tex_001A70[];
extern u64 object_bombiwa_Tex_002270[];
extern Vtx object_bombiwaVtx_002A70[];
extern Gfx object_bombiwa_DL_002F60[];
extern Gfx object_bombiwa_DL_003110[];
extern u64 object_bombiwa_Tex_0031C0[];
extern u64 object_bombiwa_Tex_0032C0[];
extern u64 object_bombiwa_Tex_003AC0[];
extern Vtx object_bombiwaVtx_0042C0[];
extern Gfx object_bombiwa_DL_004560[];
extern Gfx object_bombiwa_DL_004688[];
extern u64 object_bombiwa_Tex_004730[];
extern u64 object_bombiwa_Tex_004830[];
extern u64 object_bombiwa_Tex_005030[];
extern Vtx object_bombiwaVtx_005830[];
extern Gfx object_bombiwa_DL_005990[];
extern u64 object_bombiwa_Tex_005A70[];
extern u64 object_bombiwa_Tex_006270[];
#endif
