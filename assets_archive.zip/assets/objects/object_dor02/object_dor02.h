#ifndef OBJECT_DOR02_H
#define OBJECT_DOR02_H 1

extern Vtx object_dor02Vtx_000000[];
extern Gfx gZoraHallDoorEmptyDL[];
extern Gfx gZoraHallDoorDL[];
extern u64 gZoraHallDoorTex[];
#endif
