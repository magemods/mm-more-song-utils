#ifndef OBJECT_TANRON2_H
#define OBJECT_TANRON2_H 1

extern Vtx object_tanron2Vtx_000000[];
extern Gfx object_tanron2_DL_0004E0[];
extern Gfx object_tanron2_DL_000710[];
extern Gfx object_tanron2_DL_0007D8[];
extern Gfx object_tanron2_DL_0008A8[];
extern Gfx object_tanron2_DL_000960[];
extern u64 object_tanron2_TLUT_000A18[];
extern u64 object_tanron2_TLUT_000A38[];
extern u64 object_tanron2_TLUT_000A58[];
extern u64 object_tanron2_TLUT_000A78[];
extern u64 object_tanron2_Tex_000A98[];
extern u64 object_tanron2_Tex_000C98[];
extern u64 object_tanron2_Tex_000E98[];
extern u64 object_tanron2_Tex_001098[];
#endif
