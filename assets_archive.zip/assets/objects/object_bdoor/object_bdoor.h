#ifndef OBJECT_BDOOR_H
#define OBJECT_BDOOR_H 1

extern Vtx object_bdoorVtx_000000[];
extern Gfx gBossDoorDL[];
extern Vtx object_bdoorVtx_000180[];
extern Gfx gBossDoorLockDL[];
extern Vtx object_bdoorVtx_0004F0[];
extern Gfx gBossDoorChainDL[];
extern u64 gBossDoorSnowheadTex[];
extern Vtx object_bdoorVtx_0015C0[];
extern Gfx gBossDoorUnusedDoor1LeftDL[];
extern Gfx gBossDoorUnusedDoor1RightDL[];
extern u64 gBossDoorUnusedDoor1Tex[];
extern Vtx object_bdoorVtx_002910[];
extern Gfx gBossDoorUnusedDoor2LeftDL[];
extern Gfx gBossDoorUnusedDoor2RightDL[];
extern u64 gBossDoorUnusedDoor2Tex[];
extern u64 gBossDoorStoneTowerTex[];
extern u64 gBossDoorGreatBayTex[];
extern u64 gBossDoorWoodfallTex[];
extern u64 gBossDoorDefaultTex[];
#endif
