#ifndef OBJECT_GI_BOMB_1_H
#define OBJECT_GI_BOMB_1_H 1

extern Vtx object_gi_bomb_1Vtx_000000[];
extern Gfx gGiBombDL[];
#endif
