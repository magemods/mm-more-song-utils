#ifndef OBJECT_F53_OBJ_H
#define OBJECT_F53_OBJ_H 1

extern Vtx object_f53_objVtx_000000[];
extern Gfx object_f53_obj_DL_000090[];
extern Gfx object_f53_obj_DL_000148[];
extern Gfx object_f53_obj_DL_000158[];
extern u64 object_f53_obj_Tex_000168[];
extern Vtx object_f53_objVtx_001170[];
extern Gfx gBankShutterDL[];
extern u64 object_f53_obj_Tex_001278[];
extern Gfx object_f53_obj_DL_001AF0[];
extern Gfx object_f53_obj_DL_001BF0[];
extern Gfx object_f53_obj_DL_001C00[];
extern u64 object_f53_obj_Tex_001C10[];
extern Vtx object_f53_objVtx_002010[];
extern Gfx object_f53_obj_DL_0023B0[];
extern Gfx object_f53_obj_DL_0024C8[];
extern Gfx object_f53_obj_DL_0024D8[];
extern Gfx object_f53_obj_DL_0024E8[];
extern Gfx object_f53_obj_DL_002648[];
extern Gfx object_f53_obj_DL_002658[];
extern u64 object_f53_obj_Tex_002668[];
extern u64 object_f53_obj_Tex_002E68[];
extern u64 object_f53_obj_Tex_003268[];
#endif
