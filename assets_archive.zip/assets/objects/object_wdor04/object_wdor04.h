#ifndef OBJECT_WDOR04_H
#define OBJECT_WDOR04_H 1

extern Vtx object_wdor04Vtx_000000[];
extern Gfx gMilkBarDoorEndDL[];
extern Gfx gMilkBarDoorDL[];
extern u64 gMilkBarDoorTex[];
#endif
