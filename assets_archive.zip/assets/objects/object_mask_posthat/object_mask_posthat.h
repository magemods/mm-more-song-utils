#ifndef OBJECT_MASK_POSTHAT_H
#define OBJECT_MASK_POSTHAT_H 1

extern Vtx object_mask_posthatVtx_000000[];
extern Gfx object_mask_posthat_DL_000290[];
extern u64 object_mask_posthat_TLUT_000488[];
extern u64 object_mask_posthat_Tex_000688[];
extern u64 object_mask_posthat_Tex_000708[];
extern u64 object_mask_posthat_Tex_000B08[];
#endif
