#ifndef OBJECT_GI_MASK14_H
#define OBJECT_GI_MASK14_H 1

extern Vtx object_gi_mask14Vtx_000000[];
extern Gfx gGiGreatFairyMaskLeavesDL[];
extern Gfx gGiGreatFairyMaskFaceDL[];
extern u64 gGiGreatFairyMaskHairTex[];
extern u64 gGiGreatFairyMaskLeafTex[];
extern u64 gGiGreatFairyMaskEyeTex[];
extern u64 gGiGreatFairyMaskMouthTex[];
#endif
