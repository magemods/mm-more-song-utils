#ifndef OBJECT_GI_BOTTLE_H
#define OBJECT_GI_BOTTLE_H 1

extern Vtx object_gi_bottleVtx_000000[];
extern Gfx gGiEmptyBottleCorkDL[];
extern Gfx gGiEmptyBottleGlassDL[];
#endif
