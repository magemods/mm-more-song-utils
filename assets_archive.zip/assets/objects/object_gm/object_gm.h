#ifndef OBJECT_GM_H
#define OBJECT_GM_H 1

extern u8 gGmEmptyBlob[];
#endif
