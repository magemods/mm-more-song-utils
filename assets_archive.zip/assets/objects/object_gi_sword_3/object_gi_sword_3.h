#ifndef OBJECT_GI_SWORD_3_H
#define OBJECT_GI_SWORD_3_H 1

extern Vtx object_gi_sword_3Vtx_000000[];
extern Gfx gGiGildedSwordEmptyDL[];
extern Gfx gGiGildedSwordDL[];
extern u64 gGiGildedSwordHiltTex[];
extern u64 gGiGildedSwordSpotTex[];
extern u64 gGiGildedSwordBladePommelTex[];
#endif
