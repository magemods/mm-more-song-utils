#ifndef OBJECT_HARIKO_H
#define OBJECT_HARIKO_H 1

extern Vtx object_harikoVtx_000000[];
extern Gfx gHarikoBodyDL[];
extern Gfx gHarikoFaceDL[];
extern u64 gHarikoBodyTex[];
extern u64 gHarikoFaceTex[];
#endif
