#ifndef OBJECT_GI_MASK13_H
#define OBJECT_GI_MASK13_H 1

extern Vtx object_gi_mask13Vtx_000000[];
extern Gfx gGiCouplesMaskHalfDL[];
extern Gfx gGiCouplesMaskFullDL[];
extern u64 gGiCouplesMaskLeftInscriptionTex[];
extern u64 gGiCouplesMaskRightInscriptionTex[];
extern u64 gGiCouplesMaskBackgroundTex[];
#endif
