#ifndef DAYTELOP_STATIC_H
#define DAYTELOP_STATIC_H 1

extern u64 gDaytelopFirstDayLeftNESTex[];
extern u64 gDaytelopFirstDayRightNESTex[];
extern u64 gDaytelopSecondDayLeftNESTex[];
extern u64 gDaytelopSecondDayRightNESTex[];
extern u64 gDaytelopFinalDayLeftNESTex[];
extern u64 gDaytelopFinalDayRightNESTex[];
extern u64 gDaytelopNewDayLeftNESTex[];
extern u64 gDaytelopNewDayRightNESTex[];
extern u64 gDaytelop72HoursNESTex[];
extern u64 gDaytelop48HoursNESTex[];
extern u64 gDaytelop24HoursNESTex[];
#endif
