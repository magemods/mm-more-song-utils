#ifndef GER_DAYTELOP_STATIC_H
#define GER_DAYTELOP_STATIC_H 1

extern u64 gDaytelopFirstDayLeftGERTex[];
extern u64 gDaytelopFirstDayRightGERTex[];
extern u64 gDaytelopSecondDayLeftGERTex[];
extern u64 gDaytelopSecondDayRightGERTex[];
extern u64 gDaytelopFinalDayLeftGERTex[];
extern u64 gDaytelopFinalDayRightGERTex[];
extern u64 gDaytelopNewDayLeftGERTex[];
extern u64 gDaytelopNewDayRightGERTex[];
extern u64 gDaytelop72HoursGERTex[];
extern u64 gDaytelop48HoursGERTex[];
extern u64 gDaytelop24HoursGERTex[];
#endif
