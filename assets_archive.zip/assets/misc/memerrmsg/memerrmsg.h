#ifndef MEMERRMSG_H
#define MEMERRMSG_H 1

extern u64 gExpansionPakNotInstalledErrorTex[];
extern u64 gSeeInstructionBookletErrorTex[];
#endif
