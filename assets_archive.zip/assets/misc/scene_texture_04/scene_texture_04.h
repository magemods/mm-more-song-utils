#ifndef SCENE_TEXTURE_04_H
#define SCENE_TEXTURE_04_H 1

extern u64 scene_texture_04_Tex_000000[];
extern u64 scene_texture_04_Tex_001000[];
extern u64 scene_texture_04_Tex_001800[];
extern u64 scene_texture_04_Tex_002000[];
extern u64 scene_texture_04_Tex_002800[];
extern u64 scene_texture_04_Tex_003000[];
extern u64 scene_texture_04_Tex_003800[];
extern u64 scene_texture_04_Tex_004000[];
extern u64 scene_texture_04_Tex_004200[];
extern u64 scene_texture_04_Tex_004A00[];
#endif
