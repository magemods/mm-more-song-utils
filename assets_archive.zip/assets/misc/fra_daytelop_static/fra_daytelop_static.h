#ifndef FRA_DAYTELOP_STATIC_H
#define FRA_DAYTELOP_STATIC_H 1

extern u64 gDaytelopFirstDayLeftFRATex[];
extern u64 gDaytelopFirstDayRightFRATex[];
extern u64 gDaytelopSecondDayLeftFRATex[];
extern u64 gDaytelopSecondDayRightFRATex[];
extern u64 gDaytelopFinalDayLeftFRATex[];
extern u64 gDaytelopFinalDayRightFRATex[];
extern u64 gDaytelopNewDayLeftFRATex[];
extern u64 gDaytelopNewDayRightFRATex[];
extern u64 gDaytelop72HoursFRATex[];
extern u64 gDaytelop48HoursFRATex[];
extern u64 gDaytelop24HoursFRATex[];
#endif
