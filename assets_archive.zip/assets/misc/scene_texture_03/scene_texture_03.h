#ifndef SCENE_TEXTURE_03_H
#define SCENE_TEXTURE_03_H 1

extern u8 scene_texture_03_Blob_002D40[];
#endif
