#ifndef STORY_STATIC_H
#define STORY_STATIC_H 1

extern u64 gStoryMaskFestivalTex[];
extern u64 gStoryGiantsLeavingTex[];
extern u64 gStoryMaskFestivalTLUT[];
extern u64 gStoryGiantsLeavingTLUT[];
#endif
