#ifndef SCENE_TEXTURE_02_H
#define SCENE_TEXTURE_02_H 1

extern u64 scene_texture_02_Tex_000000[];
extern u64 scene_texture_02_Tex_000400[];
extern u64 scene_texture_02_Tex_000600[];
extern u64 scene_texture_02_Tex_000700[];
extern u64 scene_texture_02_Tex_000B00[];
extern u64 scene_texture_02_Tex_000F00[];
extern u64 scene_texture_02_Tex_001300[];
extern u64 scene_texture_02_Tex_001700[];
extern u64 scene_texture_02_Tex_001800[];
extern u64 scene_texture_02_Tex_001C00[];
#endif
