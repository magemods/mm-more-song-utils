#ifndef SCENE_TEXTURE_08_H
#define SCENE_TEXTURE_08_H 1

extern u64 scene_texture_08_Tex_000000[];
extern u64 scene_texture_08_Tex_000800[];
extern u64 scene_texture_08_Tex_001000[];
extern u64 scene_texture_08_Tex_001800[];
extern u64 scene_texture_08_Tex_002000[];
extern u64 scene_texture_08_Tex_002800[];
extern u64 scene_texture_08_Tex_003000[];
extern u64 scene_texture_08_Tex_003400[];
extern u64 scene_texture_08_Tex_003C00[];
extern u64 scene_texture_08_Tex_004000[];
extern u64 scene_texture_08_Tex_004800[];
extern u64 scene_texture_08_Tex_005000[];
extern u64 scene_texture_08_Tex_005800[];
extern u64 scene_texture_08_Tex_006000[];
extern u64 scene_texture_08_Tex_006800[];
extern u64 scene_texture_08_Tex_007000[];
extern u64 scene_texture_08_Tex_007800[];
#endif
