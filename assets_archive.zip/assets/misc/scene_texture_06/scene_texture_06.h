#ifndef SCENE_TEXTURE_06_H
#define SCENE_TEXTURE_06_H 1

extern u64 scene_texture_06_Tex_000000[];
extern u64 scene_texture_06_Tex_000400[];
extern u64 scene_texture_06_TLUT_000C00[];
extern u64 scene_texture_06_Tex_000C20[];
extern u64 scene_texture_06_TLUT_001420[];
extern u64 scene_texture_06_Tex_001440[];
extern u64 scene_texture_06_TLUT_001C40[];
extern u64 scene_texture_06_Tex_001C60[];
extern u64 scene_texture_06_Tex_002460[];
extern u64 scene_texture_06_Tex_002C60[];
extern u64 scene_texture_06_Tex_003460[];
extern u64 scene_texture_06_Tex_003C60[];
extern u64 scene_texture_06_Tex_004460[];
extern u64 scene_texture_06_Tex_004C60[];
#endif
