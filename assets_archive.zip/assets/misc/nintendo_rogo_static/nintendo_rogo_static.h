#ifndef NINTENDO_ROGO_STATIC_H
#define NINTENDO_ROGO_STATIC_H 1

extern u64 gNintendo64LogoTextTex[];
extern u64 gNintendo64LogoTextShineTex[];
extern Vtx nintendo_rogo_staticVtx_001C00[];
extern Gfx gNintendo64LogoNDL[];
extern u64 gNintendo64LogoNShineTex[];
#endif
