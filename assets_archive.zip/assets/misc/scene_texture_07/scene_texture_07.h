#ifndef SCENE_TEXTURE_07_H
#define SCENE_TEXTURE_07_H 1

extern u8 scene_texture_07_Blob_000[];
#endif
