#ifndef SCENE_TEXTURE_01_H
#define SCENE_TEXTURE_01_H 1

extern u64 scene_texture_01_Tex_000000[];
extern u64 scene_texture_01_Tex_000100[];
extern u64 scene_texture_01_Tex_000900[];
extern u64 scene_texture_01_Tex_000D00[];
extern u64 scene_texture_01_Tex_001100[];
extern u64 scene_texture_01_Tex_001200[];
extern u64 scene_texture_01_Tex_001400[];
extern u64 scene_texture_01_Tex_001800[];
extern u64 scene_texture_01_Tex_001900[];
extern u64 scene_texture_01_Tex_001A00[];
extern u64 scene_texture_01_Tex_001E00[];
extern u64 scene_texture_01_Tex_002200[];
extern u64 scene_texture_01_Tex_002300[];
extern u64 scene_texture_01_Tex_002500[];
extern u64 scene_texture_01_Tex_002900[];
extern u64 scene_texture_01_Tex_002D00[];
extern u64 scene_texture_01_Tex_002D40[];
extern u64 scene_texture_01_Tex_002E40[];
extern u64 scene_texture_01_Tex_003040[];
extern u64 scene_texture_01_Tex_003240[];
extern u64 scene_texture_01_Tex_003280[];
extern u64 scene_texture_01_Tex_003680[];
extern u64 scene_texture_01_Tex_003A80[];
extern u64 scene_texture_01_Tex_003C80[];
extern u64 scene_texture_01_Tex_004080[];
extern u64 scene_texture_01_Tex_004480[];
extern u64 scene_texture_01_Tex_004580[];
extern u64 scene_texture_01_Tex_004600[];
extern u64 scene_texture_01_Tex_004700[];
extern u64 scene_texture_01_Tex_004800[];
extern u64 scene_texture_01_Tex_004C00[];
#endif
