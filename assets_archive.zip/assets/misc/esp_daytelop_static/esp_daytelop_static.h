#ifndef ESP_DAYTELOP_STATIC_H
#define ESP_DAYTELOP_STATIC_H 1

extern u64 gDaytelopFirstDayLeftESPTex[];
extern u64 gDaytelopFirstDayRightESPTex[];
extern u64 gDaytelopSecondDayLeftESPTex[];
extern u64 gDaytelopSecondDayRightESPTex[];
extern u64 gDaytelopFinalDayLeftESPTex[];
extern u64 gDaytelopFinalDayRightESPTex[];
extern u64 gDaytelopNewDayLeftESPTex[];
extern u64 gDaytelopNewDayRightESPTex[];
extern u64 gDaytelop72HoursESPTex[];
extern u64 gDaytelop48HoursESPTex[];
extern u64 gDaytelop24HoursESPTex[];
#endif
