#ifndef D2_FINE_PAL_STATIC_H
#define D2_FINE_PAL_STATIC_H 1

extern u64 gSkyboxTLUT[];
#endif
