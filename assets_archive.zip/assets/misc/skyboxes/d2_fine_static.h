#ifndef D2_FINE_STATIC_H
#define D2_FINE_STATIC_H 1

extern u64 gSkyboxClear1Tex[];
extern u64 gSkyboxClear2Tex[];
extern u64 gSkyboxClear3Tex[];
extern u64 gSkyboxClear4Tex[];
extern u64 gSkyboxClear5Tex[];
#endif
