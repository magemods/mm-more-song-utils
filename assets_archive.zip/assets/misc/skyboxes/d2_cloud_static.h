#ifndef D2_CLOUD_STATIC_H
#define D2_CLOUD_STATIC_H 1

extern u64 gSkyboxCloudy1Tex[];
extern u64 gSkyboxCloudy2Tex[];
extern u64 gSkyboxCloudy3Tex[];
extern u64 gSkyboxCloudy4Tex[];
extern u64 gSkyboxCloudy5Tex[];
#endif
