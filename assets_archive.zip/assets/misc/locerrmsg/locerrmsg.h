#ifndef LOCERRMSG_H
#define LOCERRMSG_H 1

extern u64 gNotDesignedForSystemErrorTex[];
#endif
